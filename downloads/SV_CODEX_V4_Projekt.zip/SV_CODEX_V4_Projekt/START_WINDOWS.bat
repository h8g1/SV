@echo off
cd /d "%~dp0"
if not exist "dist\index.html" (
  echo Build fehlt. Bitte zuerst npm ci und npm run build ausfuehren.
  pause
  exit /b 1
)
where py >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:4173
  py -3 -m http.server 4173 --bind 127.0.0.1 --directory dist
  exit /b
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:4173
  python -m http.server 4173 --bind 127.0.0.1 --directory dist
  exit /b
)
where node >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:4173
  node tools\serve.mjs
  exit /b
)
echo Bitte Python 3 oder Node.js installieren. Der fertige Build benoetigt kein npm und kein Internet.
pause
