import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

// All spatial relationships are a designed process model, not SV premises.
const V = (a) => new THREE.Vector3(...a);
const M = (color, roughness=.7, metalness=0) => new THREE.MeshStandardMaterial({color,roughness,metalness});
const palette={ivory:0xf3eee5,oak:0xb6956d,ink:0x26383b,sage:0x83998d,red:0xc72d40,linen:0xd4c7b3};

function box(parent, size, pos, material, radius=.025) {
  const geometry=radius>0?new RoundedBoxGeometry(...size,2,Math.min(radius,Math.min(...size)/2)):new THREE.BoxGeometry(...size);
  const o=new THREE.Mesh(geometry,material);o.position.set(...pos);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;
}
function cylinder(parent, top,bottom,height,pos,mat,segments=20) {
 const o=new THREE.Mesh(new THREE.CylinderGeometry(top,bottom,height,segments),mat);o.position.set(...pos);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;
}
function line(parent, points, radius, material) {
 const curve=new THREE.CatmullRomCurve3(points.map(V));const o=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(8,points.length*4),radius,6,false),material);o.castShadow=true;parent.add(o);return o;
}
function canvasTexture(draw,size=512) {const c=document.createElement('canvas');c.width=c.height=size;draw(c.getContext('2d'),size);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;return t;}
function woodTexture(){return canvasTexture((c,s)=>{c.fillStyle='#baa180';c.fillRect(0,0,s,s);for(let y=0;y<s;y++){let alpha=.02+.035*(.5+.5*Math.sin(y*.21));c.strokeStyle=`rgba(91,62,35,${alpha})`;c.beginPath();c.moveTo(0,y);for(let x=0;x<=s;x+=8)c.lineTo(x,y+Math.sin(x*.02+y*.006)*1.4);c.stroke()}for(let x=0;x<s;x+=128){c.strokeStyle='rgba(65,46,25,.12)';c.fillRect(x,0,1,s)}})}
function textileTexture(){return canvasTexture((c,s)=>{c.fillStyle='#c7bca8';c.fillRect(0,0,s,s);for(let y=0;y<s;y+=4){c.fillStyle=y%8?'#c0b49d':'#d2c7b2';c.fillRect(0,y,s,1)}for(let x=0;x<s;x+=4){c.fillStyle='rgba(89,75,54,.12)';c.fillRect(x,0,1,s)}})}
function pavingTexture(){return canvasTexture((c,s)=>{c.fillStyle='#c9c6bd';c.fillRect(0,0,s,s);for(let y=0;y<s;y+=64)for(let x=-64;x<s;x+=128){let xx=x+(y%128?64:0);c.strokeStyle='#b6b4ad';c.lineWidth=2;c.strokeRect(xx,y,128,64);c.fillStyle='rgba(255,255,255,.06)';c.fillRect(xx+3,y+3,122,58)}})}
function leafGeo(){const points=[new THREE.Vector2(0,0),new THREE.Vector2(.16,.22),new THREE.Vector2(.19,.48),new THREE.Vector2(0,.77),new THREE.Vector2(-.19,.48),new THREE.Vector2(-.16,.22)];const sh=new THREE.Shape(points);sh.closePath();const g=new THREE.ShapeGeometry(sh,4);const p=g.attributes.position;for(let i=0;i<p.count;i++)p.setZ(i,Math.sin(p.getY(i)*Math.PI/.77)*.085);g.computeVertexNormals();return g;}
function plant(parent,x,z,scale=1,style='floor'){
 const g=new THREE.Group();parent.add(g);g.position.set(x,0,z);g.scale.setScalar(scale);
 const pot=M(style==='desk'?0xd5c9b6:0xe5ddcf,.8),soil=M(0x41382d),leafM=[M(0x385d4d),M(0x4b7057),M(0x688065)];leafM.forEach(m=>m.side=THREE.DoubleSide);
 cylinder(g,.23,.19,.42,[0,.21,0],pot);cylinder(g,.21,.21,.015,[0,.425,0],soil);
 for(let i=0;i<10;i++){const a=i*2.39996;let h=.75+(i%4)*.19;let r=.27+(i%3)*.11;const tip=[Math.cos(a)*r,h,Math.sin(a)*r];line(g,[[0,.4,0],[tip[0]*.3,h*.7,tip[2]*.3],tip],.009,leafM[0]);const l=new THREE.Mesh(leafGeo(),leafM[i%3]);l.position.set(...tip);l.rotation.set(-.3+Math.sin(a)*.4,a,Math.cos(a)*-.5);l.scale.setScalar(.75+(i%3)*.16);g.add(l)}return g;
}
function tree(parent,x,z,scale=1){
 const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(scale);parent.add(g);
 const bark=M(0x7c6b57), leaves=[M(0x668071),M(0x809585),M(0x506d60)];leaves.forEach(m=>m.side=THREE.DoubleSide);
 line(g,[[0,0,0],[.05,1.1,0],[-.04,2.2,.06],[.02,3.2,0]],.085,bark);
 for(let i=0;i<9;i++){const a=i*2.39996;let h=1.8+(i%3)*.5,r=.75+(i%2)*.3;const b=[Math.cos(a)*r,h+.5,Math.sin(a)*r];line(g,[[0,h-.35,0],[b[0]*.5,h,b[2]*.5],b],.025,bark);for(let j=0;j<12;j++){const q=new THREE.Mesh(leafGeo(),leaves[(i+j)%3]);const a2=j*2.39;q.position.set(b[0]+Math.cos(a2)*.48,b[1]+Math.sin(a2)*.25,b[2]+Math.sin(a2)*.48);q.rotation.set(.6+(j%4)*.5,a2,.35);q.scale.setScalar(.7+(j%3)*.15);q.castShadow=true;g.add(q)}}
 return g;
}
function keyboard(parent,x,y,z){const body=M(0xe6e4dd),keys=M(0xeeeeea);box(parent,[.43,.021,.15],[x,y,z],body,.01);for(let r=0;r<4;r++)for(let c=0;c<12;c++)box(parent,[.027,.009,.024],[x-.19+c*.034,y+.016,z-.055+r*.033],keys,.004);box(parent,[.12,.009,.024],[x,y+.016,z+.044],keys,.005)}
function bookshelf(parent,x,z,width,wood,ink){
 const g=new THREE.Group();g.position.set(x,0,z);parent.add(g);box(g,[width,1.65,.35],[0,.85,0],wood,.025);box(g,[width-.08,1.54,.06],[0,.86,-.16],M(0xe5d9c6),.01);for(const h of [.2,.65,1.12,1.62])box(g,[width,.045,.36],[0,h,0],wood,.01);
 const colors=[0xf0e9de,0x9aa79e,0x454e53,0xc09d88,0xc4b9a8];for(let row=0;row<3;row++){for(let i=0;i<7;i++){let xx=-width/2+.14+i*.145;if(xx>width/2-.1)break;const b=box(g,[.08+(i%2)*.02,.24+(i%3)*.035,.22],[xx,.22+row*.47+.145,.015],M(colors[(row+i)%colors.length]),.006);if(i===5)b.rotation.z=.14;box(g,[.049,.008,.002],[xx,.26+row*.47,.127],ink,.001)}}
 return g;
}
function deskLamp(parent,x,z,ink){const metal=M(0xbca689,.4,.6);cylinder(parent,.105,.12,.025,[x,.65,z],ink);line(parent,[[x,.665,z],[x,1.025,z],[x+.16,1.215,z]],.014,metal);const shade=cylinder(parent,.12,.08,.12,[x+.17,1.195,z],ink);shade.rotation.z=.35;const bulb=M(0xffedd1,.4);bulb.emissive=new THREE.Color(0xffdd9a);bulb.emissiveIntensity=.5;cylinder(parent,.075,.075,.004,[x+.19,1.135,z],bulb)}

export async function createWorld(scene){
 const base=import.meta.env.BASE_URL;
 const loader=new GLTFLoader();
 const [deskAsset,chairAsset]=await Promise.all([loader.loadAsync(base+'models/desk.glb'),loader.loadAsync(base+'models/chair.glb')]);
 const root=new THREE.Group();root.name='Schematic SV process world';scene.add(root);
 const wood=M(palette.oak,.72);wood.map=woodTexture();wood.map.wrapS=wood.map.wrapT=THREE.RepeatWrapping;
 const ivory=M(palette.ivory),ink=M(palette.ink,.48),oakEdge=M(0x8c7357),metal=M(0xb1b8b2,.35,.75),sage=M(palette.sage),red=M(palette.red),glass=new THREE.MeshPhysicalMaterial({color:0xc4ddd8,roughness:.14,metalness:0,transparent:true,opacity:.15,depthWrite:false,side:THREE.DoubleSide});
 const rug=M(palette.linen,.97);rug.map=textileTexture();rug.map.wrapS=rug.map.wrapT=THREE.RepeatWrapping;rug.map.repeat.set(4,4);
 const paving=M(0xffffff,.94);paving.map=pavingTexture();paving.map.wrapS=paving.map.wrapT=THREE.RepeatWrapping;paving.map.repeat.set(8,8);
 // Monolithic gallery plinth and fine perimeter reveal.
 box(root,[27,.42,19],[-3.8,-.29,.2],M(0xc2b8a6),.14);
 box(root,[26.9,.06,18.9],[-3.8,-.045,.2],M(0xe0d9cd),.04);
 box(root,[13.65,.18,13.2],[0,.08,0],ivory,.06);
 box(root,[13.7,.025,13.25],[0,-.02,0],oakEdge,.012);
 // Main public corridor: stone, brass inlays, no fictional system rooms.
 box(root,[13.15,.023,1.6],[0,.185,0],M(0xd9d4c9),.01);
 for(let x=-6;x<6;x+=1.3)box(root,[.01,.003,1.5],[x,.199,0],M(0xb2a58d,.45,.6),.001);
 box(root,[.45,.23,1.3],[-6.6,.17,0],M(0xc4baaa),.04);
 // Cutaway perimeter, rear architectural wall and deep window embrasures.
 box(root,[13.4,2.8,.16],[0,1.56,-6.4],ivory,.025);
 for(let x=-5.7;x<=5.8;x+=2.3){box(root,[1.84,1.65,.175],[x,1.75,-6.29],glass,.012);for(const dx of [-.95,.95])box(root,[.045,1.75,.13],[x+dx,1.75,-6.19],ink,.006);for(const y of [.88,2.62])box(root,[1.94,.045,.14],[x,y,-6.18],ink,.006);box(root,[1.94,.055,.36],[x,.86,-6.16],wood,.008);box(root,[.035,1.73,.08],[x,1.75,-6.11],ink,.006)}
 for(const x of [-6.6,6.6]){box(root,[.12,.58,12.8],[x,.45,0],ivory,.02);for(let z=-5.7;z<6;z+=2.4){box(root,[.07,2.1,2.25],[x,1.68,z],glass,.005);box(root,[.08,2.56,.055],[x,1.54,z-1.12],ink,.005)}box(root,[.15,.085,12.9],[x,2.94,0],wood,.012)}
 // A central spine and translucent room partitions retain geographic continuity.
 for(const z of [-3.55,3.55])box(root,[.14,.5,5.5],[0,.43,z],ivory,.02);
 for(const z of [-3.55,3.55]){box(root,[.06,2.15,4.5],[0,1.7,z],glass,.008);for(const zz of [z-2.25,z+2.25])box(root,[.07,2.6,.07],[0,1.5,zz],ink,.008);box(root,[.1,.08,4.6],[0,2.83,z],wood,.008)}
 for(const z of [-.84,.84]){
   for(const x of [-4.85,4.85]){box(root,[3.3,.52,.1],[x,.45,z],ivory,.015);box(root,[3.3,1.75,.035],[x,1.58,z],glass,.005);for(const xx of [x-1.63,x+1.63])box(root,[.04,2.25,.06],[xx,1.45,z],metal,.005);box(root,[3.3,.05,.07],[x,2.59,z],metal,.007)}
   // Open doors with small, visible door furniture.
   for(const x of [-2.3,2.3]){const door=box(root,[.9,2.2,.035],[x,1.37,z],glass,.005);door.rotation.y=x<0?.35:-.35;line(root,[[x+.32,1.1,z-.025],[x+.32,1.32,z-.025]],.014,metal)}
 }
 const brandTexture=await new THREE.TextureLoader().loadAsync(base+'brand/sv-logo.png');brandTexture.colorSpace=THREE.SRGBColorSpace;
 const brandWidth=1.18,brandHeight=brandWidth*brandTexture.image.height/brandTexture.image.width;
 const brand=new THREE.Mesh(new THREE.PlaneGeometry(brandWidth,brandHeight),new THREE.MeshBasicMaterial({map:brandTexture,transparent:true,toneMapped:false}));brand.position.set(-6.73,1.8,-2.7);brand.rotation.y=-Math.PI/2;root.add(brand);
 const roomDefs={
  elias:{center:[-3.3,.19,-3.4],label:'Antrag & Fachprüfung',tint:0xe8dfcf},
  bestand:{center:[3.3,.19,-3.4],label:'Bestand & Policierung',tint:0xe0e6dc},
  ali:{center:[-3.3,.19,3.4],label:'Schadenbearbeitung',tint:0xdce3e4},
  cancel:{center:[3.3,.19,3.4],label:'Kündigung & Korrespondenz',tint:0xe9dcd6}
 };
 const rooms={},pickables=[],monitors={},focuses=[];
 for(const [id,d] of Object.entries(roomDefs)){
  const [x,fy,z]=d.center;const g=new THREE.Group();g.position.set(x,fy,z);root.add(g);g.name=`Room ${id}`;
  box(g,[6.35,.02,5.35],[0,0,0],M(d.tint),.02);
  // Real oak parquet, laid in thin continuous slats.
  for(let i=0;i<15;i++)box(g,[6.25,.012,.348],[0,.019,-2.5+i*.35],wood,.002);
  box(g,[3.6,.018,3.2],[-.2,.04,-.05],rug,.02);
  const focus=box(g,[6.2,.01,.035],[0,.045,2.55],M(0xc72d40),.008);focus.material.transparent=true;focus.material.opacity=0;focuses.push({id,obj:focus});
  const desk=deskAsset.scene.clone(true);desk.name='Local GLB desk';desk.position.set(0,0,.35);desk.scale.set(2.2/1.7,1,.85/.8);g.add(desk);
  // Place all equipment in one raised group at the ergonomic native GLB height.
  const equipment=new THREE.Group();equipment.position.y=.1375;g.add(equipment);
  const mx=-.36,mz=.68;
  box(equipment,[.32,.018,.18],[mx,.641,mz],ink,.012);box(equipment,[.04,.19,.045],[mx,.74,mz+.035],metal,.006);
  const mon=box(equipment,[.88,.51,.055],[mx,.99,mz],ink,.025);mon.name=`monitor-${id}`;
  const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=576;const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=4;
  const screen=new THREE.Mesh(new THREE.PlaneGeometry(.824,.455),new THREE.MeshBasicMaterial({map:tex,toneMapped:false}));screen.position.set(mx,.99,mz-.03);screen.rotation.y=Math.PI;equipment.add(screen);screen.userData={room:id,kind:'monitor'};pickables.push(screen);monitors[id]={canvas,tex,screen,last:''};
  keyboard(equipment,0,.65,.08);box(equipment,[.11,.014,.16],[.58,.65,.15],M(0xc7c9c2),.018);
  // A small angled laptop at right adds a second display without system labels.
  if(id==='bestand'||id==='ali'){box(equipment,[.43,.017,.3],[.55,.65,.35],metal,.014);const lid=box(equipment,[.43,.28,.017],[.55,.8,.48],ink,.01);lid.rotation.x=-.15;box(equipment,[.38,.22,.004],[.55,.81,.466],M(0x829c9d),.004)}
  else {for(let j=0;j<3;j++)box(equipment,[.32,.005,.43],[.54+j*.01,.638+j*.009,.36],M(j===2?0xfffdf5:0xd9d1c6),.002);box(equipment,[.035,.01,.22],[.76,.67,.32],red,.003)}
  const seat=chairAsset.scene.clone(true);seat.name='Local GLB office chair';seat.position.set(0,0,-.43);g.add(seat);
  // Desk accessories are behind the hand and face sight line.
  deskLamp(equipment,-.9,.56,ink);cylinder(equipment,.06,.055,.1,[.87,.69,.56],M(0xf8f1e6));const handle=new THREE.Mesh(new THREE.TorusGeometry(.035,.009,6,12),ivory);handle.position.set(.945,.7,.56);equipment.add(handle);
  bookshelf(g,1.95,-2.3,1.1,wood,ink);plant(g,-2.35,-1.9,.95);plant(g,2.4,1.95,.7);
  // Acoustic fabric artwork, intentionally no slogans or floating walls of text.
  if(z<0){box(g,[1.2,.8,.035],[-1.7,1.72,-2.79],wood,.012);box(g,[1.1,.7,.04],[-1.7,1.72,-2.76],M(id==='elias'?0xb4b3a0:0x81958c),.008);for(let q=0;q<6;q++)box(g,[.028,.64,.045],[-2.18+q*.19,1.72,-2.73],M(0xd7cfbc),.005)}
  // Delicate linear pendant suspended from a visible frame, no opaque ceiling.
  box(g,[1.4,.055,.15],[0,2.52,.2],ink,.022);const diff=M(0xfff3db,.4);diff.emissive=new THREE.Color(0xffebc7);diff.emissiveIntensity=.55;box(g,[1.3,.015,.12],[0,2.48,.2],diff,.006);for(const xx of [-.5,.5])line(g,[[xx,2.55,.2],[xx,2.85,.2]],.004,ink);
  rooms[id]={id,label:d.label,center:[x,.19,z],character:[x,.19,z-.43],monitor:[x+mx,1.3175,z+mz],camera:[x+2.65,2.45,z+3.25],target:[x,1.18,z-.45],systemCamera:[x+.5,1.6,z-1.1],systemTarget:[x+mx,1.3175,z+mz],group:g};
  // invisible logical room floor target for free exploration raycasting
  const hit=new THREE.Mesh(new THREE.PlaneGeometry(5.8,4.9),new THREE.MeshBasicMaterial({visible:false}));hit.rotation.x=-Math.PI/2;hit.position.set(x,.23,z);hit.userData={room:id,kind:'room'};root.add(hit);pickables.push(hit);
 }
 // Input/scan station is infrastructure, not an invented SV department.
 const input=new THREE.Group();input.position.set(-7.7,0,-1);root.add(input);box(input,[1.6,.73,.8],[0,.365,0],ivory,.045);box(input,[1.7,.055,.9],[0,.76,0],wood,.025);box(input,[.63,.23,.46],[0,.9,0],ink,.025);box(input,[.55,.025,.36],[0,1.025,0],M(0xc3c7bf),.012);box(input,[.4,.02,.22],[0,1.05,-.04],M(0xfcf7ed),.003);for(let i=0;i<4;i++)box(input,[.38,.006,.27],[.47,.805+i*.006,.04],M(0xfaf5ed),.002);plant(input,0,-1.2,.8);
 rooms.input={id:'input',label:'Eingangskanäle',center:[-7.7,0,-1],character:[-7.7,0,-1.65],monitor:[-7.7,1,-1],camera:[-5.5,2,-.1],target:[-7.7,.9,-1]};
 // Exterior: sidewalk, single local street, tactile materials and selective city detail.
 box(root,[8.6,.07,17.4],[-12.1,.01,.3],paving,.02);
 const road=M(0x667371,.97);box(root,[5.25,.018,17.3],[-12.7,.06,.3],road,.02);
 for(const x of [-15.4,-9.95])box(root,[.14,.13,17.2],[x,.12,.3],M(0xe4ded2),.018);
 for(let z=-7;z<8;z+=2.4)box(root,[.09,.004,.92],[-12.7,.075,z],M(0xe4e4d9),.002);
 for(let j=0;j<6;j++)box(root,[1.9,.004,.23],[-12.7,.08,-5.8+j*.47],M(0xefebe2),.003);
 for(const z of [-7,0,7.4]){tree(root,-8.7,z,.77);box(root,[1.2,.08,1.2],[-8.7,.05,z],M(0xb8ba9a),.05)}
 for(const z of [-6.5,7.4]){tree(root,-16.15,z,.9);line(root,[[-15.7,0,z],[-15.7,2.6,z],[-15.2,2.8,z]],.035,ink);box(root,[.43,.06,.2],[-15.18,2.78,z],ink,.025)}
 // Street bench and bollards provide scale without decorative clutter.
 for(const z of [-2.2,5.8]){for(let k=0;k<4;k++)box(root,[1.2,.04,.07],[-8.8,.49,z+k*.1],wood,.01);for(const x of [-9.25,-8.35])box(root,[.035,.47,.35],[x,.25,z+.15],ink,.005)}
 for(let z=-5;z<=7;z+=3)cylinder(root,.045,.055,.6,[-9.75,.32,z],ink);
 // Distant architectural silhouettes kept modest and behind the active action.
 const skyline=new THREE.Group();root.add(skyline);
 for(const [x,z,w,h,depth,color] of [[-14,-9,3.5,4,2,0xb8b4af],[-8.3,-9.1,3.2,3.2,2,0xc6b9a6],[1,-9.4,4,4.6,2,0xbcc7c0],[7.5,-8.6,2.7,3.6,2,0xc5b7b0]]){box(skyline,[w,h,depth],[x,h/2,z],M(color),.04);for(let xx=-w/2+.35;xx<w/2;xx+=.7)for(let yy=.7;yy<h-.1;yy+=.8)box(skyline,[.36,.45,.02],[x+xx,yy,z+depth/2+.02],M(0x657c7c,.38),.005);box(skyline,[w+.12,.08,depth+.12],[x,h+.04,z],ivory,.015)}
 rooms.outdoor={id:'outdoor',label:'Kundenwelt · Kfz-Schaden',center:[-12,0,4],character:[-9,.14,4.4],monitor:[-9,1.3,4.7],camera:[-11.2,2.5,8.5],target:[-11,.95,4.3],systemCamera:[-9.8,1.75,5.5],systemTarget:[-9,1.3,4.4]};
 rooms.overview={id:'overview',label:'Prozesswelt',center:[-3,0,0],character:[0,0,0],monitor:[0,1,0],camera:[18,19,25],target:[-3.8,0,.3]};
 // Soft daylight is a world invariant. Parent may tune exposure rather than stack lights.
 const hemi=new THREE.HemisphereLight(0xf3f7ff,0x8b8478,2.1);scene.add(hemi);
 const sun=new THREE.DirectionalLight(0xffe5c7,3.4);sun.position.set(-5,14,7);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-20,right:15,top:14,bottom:-14,near:.1,far:45});sun.shadow.normalBias=.025;sun.shadow.bias=-.0002;sun.shadow.radius=3;sun.target.position.set(-3,0,0);scene.add(sun,sun.target);
 const fill=new THREE.DirectionalLight(0xd8e7ff,1.3);fill.position.set(8,7,-9);scene.add(fill);
 const backgroundGround=new THREE.Mesh(new THREE.PlaneGeometry(250,250),M(0xe6ddd0,.95));backgroundGround.rotation.x=-Math.PI/2;backgroundGround.position.y=-.53;backgroundGround.receiveShadow=true;scene.add(backgroundGround);
 const focusState={room:null};
 function setMonitor(roomId,system='ICIS',action='Vorgang prüfen',status='IST',progress=0){
  const m=monitors[roomId];if(!m)return;const stage=Math.floor(Math.max(0,Math.min(1,progress))*12);let key=[system,action,status,stage].join('|');if(m.last===key)return;m.last=key;
  const c=m.canvas.getContext('2d'),w=1024,h=576;c.fillStyle='#f7f8f4';c.fillRect(0,0,w,h);c.fillStyle='#253f40';c.fillRect(0,0,w,62);c.fillStyle='#ffffff';c.font='600 27px Arial';c.fillText(system||'Arbeitsansicht',34,41);c.fillStyle='#a9c0b8';c.font='16px Arial';c.fillText('DEMONSTRATION',768,38);
  c.fillStyle='#edf0e9';c.fillRect(0,62,190,h-62);c.fillStyle='#bdc7bc';for(let i=0;i<5;i++){c.fillRect(27,110+i*58,120,9)}c.fillStyle='#d9e0d5';c.fillRect(17,84,157,34);c.fillStyle='#293d3b';c.font='600 28px Arial';c.fillText(action.slice(0,42),225,116);c.font='18px Arial';c.fillStyle='#718177';c.fillText(status,225,151);
  for(let row=0;row<4;row++){c.fillStyle='#e3e8df';c.fillRect(225,197+row*61,190,9);c.fillStyle='#e9ece5';c.fillRect(225,218+row*61,530-row*49,14);c.strokeStyle='#e0e5dc';c.beginPath();c.moveTo(225,253+row*61);c.lineTo(949,253+row*61);c.stroke()}
  c.fillStyle='#bccabe';c.fillRect(225,488,658,7);c.fillStyle=status.includes('geplant')||status.includes('SOLL')?'#ad876b':'#577f6d';c.fillRect(225,488,658*(.1+stage/12*.9),7);c.fillStyle='#fff';c.fillRect(824,516,137,37);c.fillStyle='#597363';c.font='16px Arial';c.fillText('Vorgang',849,540);m.tex.needsUpdate=true;
 }
 for(const id of Object.keys(monitors))setMonitor(id,'ICIS','Arbeitsansicht · schematisch','Demonstration',0);
 function update(time,context={}){
  const active=context.room??context.sequence?.room??focusState.room;
  for(const f of focuses)f.obj.material.opacity=f.id===active?.68:0;
  if(active&&context.system!==undefined)setMonitor(active,context.system,context.title??'Vorgang prüfen',context.status??'IST',context.progress??0);
 }
 // Batch fixed opaque geometry by material, keeping interactive screens/highlights separate.
 // This preserves the authored scene while reducing CPU draw submission on presentation laptops.
 root.updateMatrixWorld(true);
 const batches=new Map(),kept=new Set(focuses.map(f=>f.obj));
 root.traverse(o=>{if(!o.isMesh||kept.has(o)||!o.material.isMeshStandardMaterial||o.material.transparent)return;let b=batches.get(o.material.uuid);if(!b){b={material:o.material,objects:[],geometry:[]};batches.set(o.material.uuid,b)}const transformed=o.geometry.clone();transformed.applyMatrix4(o.matrixWorld);for(const name of Object.keys(transformed.attributes))if(!['position','normal','uv'].includes(name))transformed.deleteAttribute(name);if(!transformed.attributes.normal)transformed.computeVertexNormals();if(!transformed.attributes.uv)transformed.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(transformed.attributes.position.count*2),2));b.objects.push(o);b.geometry.push(transformed.index?transformed.toNonIndexed():transformed)});
 for(const b of batches.values()){const merged=mergeGeometries(b.geometry,false);if(!merged)continue;const mesh=new THREE.Mesh(merged,b.material);mesh.name='Static architectural batch';mesh.castShadow=true;mesh.receiveShadow=true;for(const o of b.objects)o.removeFromParent();for(const g of b.geometry)g.dispose();root.add(mesh)}
 return {root,rooms,pickables,monitors,update,setMonitor,setFocus:(room)=>{focusState.room=room},lights:{hemi,sun,fill},outdoorCarPosition:[-12,.08,4],staticBatchCount:batches.size};
}
