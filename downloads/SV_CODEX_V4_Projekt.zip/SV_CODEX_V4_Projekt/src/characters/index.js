import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const assetUrl=p=>`${import.meta.env.BASE_URL}${p}`;
export async function loadCharacters(scene,rooms,onProgress=()=>{}){
 const loader=new GLTFLoader();const records={};
 for(const [i,name]of ['elias','ali','customer','cancellation'].entries()){
  const gltf=await loader.loadAsync(assetUrl(`models/${name}.glb`));
  const root=gltf.scene;root.name=name;scene.add(root);
  root.traverse(n=>{if(n.isMesh){n.castShadow=false;n.receiveShadow=true;n.frustumCulled=true;}});
  const mixer=new THREE.AnimationMixer(root);const actions={};gltf.animations.forEach(clip=>{actions[clip.name]=mixer.clipAction(clip)});
  records[name]={root,mixer,actions,clips:gltf.animations,active:null};onProgress(40+i*10);
 }
 const car=await loader.loadAsync(assetUrl('models/car.glb'));car.scene.position.set(-12,.08,4);car.scene.rotation.y=Math.PI/2;car.scene.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true}});scene.add(car.scene);
 const defaults={elias:'elias',ali:'ali',customer:'outdoor',cancellation:'cancel'};
 function pose(record,clip,time){if(!record.actions[clip])clip='idle';if(record.active!==clip){record.mixer.stopAllAction();record.actions[clip]?.reset().setEffectiveWeight(1).play();record.active=clip;}record.mixer.setTime(time);}
 function update(seq,time){
  for(const [name,r]of Object.entries(records)){
   const roomId=name==='elias'&&['bestand'].includes(seq.room)?'bestand':defaults[name];const room=rooms[roomId];
   r.root.position.set(...room.character);r.root.rotation.y=0;
   const active=name===seq.actor;
   r.root.visible=seq.room==='overview'||active||time<6.5;
   if(!r.root.visible)continue;
   if(name==='elias'&&seq.action==='transfer'&&seq.room==='bestand'){
    const start=rooms.elias.character,end=rooms.bestand.character;
    const path=new THREE.CatmullRomCurve3([new THREE.Vector3(...start),new THREE.Vector3(-2.3,.19,-2),new THREE.Vector3(-2.3,.19,0),new THREE.Vector3(2.3,.19,0),new THREE.Vector3(2.3,.19,-2),new THREE.Vector3(...end)],false,'centripetal');
    const u=THREE.MathUtils.smoothstep((time-1)/8,0,1);
    r.root.position.copy(path.getPoint(u));
    const tangent=path.getTangent(Math.max(.001,Math.min(.999,u)));
    const w=THREE.MathUtils.smoothstep(time,0,1)*(1-THREE.MathUtils.smoothstep(time,9,10));
    r.root.rotation.y=Math.atan2(tangent.x,tangent.z)*w;
    if(r.active!=='transfer'){r.mixer.stopAllAction();r.actions.work.reset().play();r.actions.walk.reset().play();r.active='transfer'}
    r.actions.work.setEffectiveWeight(1-w);r.actions.walk.setEffectiveWeight(w);r.mixer.setTime(time);
    continue;
   }
   let clip=name==='customer'?'phone':name==='cancellation'?'idle':'work';
   pose(r,clip,active?time:1.8);
   // A separate cancellation visitor is visible; she never replaces Ali/Elias.
   if(name==='customer')r.root.rotation.y=-.6;
   if(name==='cancellation'){r.root.position.z+=.5;r.root.position.x+=1.2;r.root.rotation.y=-.45;}
  }
 }
 return {records,car:car.scene,update};
}
