import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../public/content');
const json = async name => JSON.parse(await readFile(resolve(root, name), 'utf8'));
// RFC-style quoted fields, including semicolons and line breaks in speaker notes.
function csv(text) {
  const rows = []; let row = [], value = '', quoted = false;
  text = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') { value += '"'; i++; }
      else quoted = !quoted;
    } else if (!quoted && c === ';') { row.push(value); value = ''; }
    else if (!quoted && c === '\n') {
      row.push(value.replace(/\r$/, '')); rows.push(row); row = []; value = '';
    } else value += c;
  }
  if (value || row.length) { row.push(value); rows.push(row); }
  assert.equal(quoted, false, 'Unterminated CSV field');
  const keys = rows.shift();
  return rows.filter(r => r.some(Boolean)).map(r => Object.fromEntries(keys.map((key, i) => [key, r[i]])));
}

const [steps, sequences, originalSteps, manifest] = await Promise.all([
  json('steps.json'), json('sequences.json'), json('original_steps.json'), json('manifest.json')
]);
const original = csv(await readFile(resolve(root, 'original_matrix.csv'), 'utf8'));
const mapping = csv(await readFile(resolve(root, 'content_mapping.csv'), 'utf8'));
assert.equal(steps.length, 85); assert.equal(original.length, 85); assert.equal(mapping.length, 85);
assert.equal(new Set(steps.map(s => s.id)).size, 85);
const mappedIds = sequences.flatMap(s => s.stepIds);
assert.equal(mappedIds.length, 85, 'Every source step mapped exactly once');
assert.equal(new Set(mappedIds).size, 85);
for (let i = 0; i < steps.length; i++) {
  const step = steps[i], source = original[i];
  assert.deepEqual(step.original, source, `Original CSV row ${i + 1}`);
  for (const key of manifest.sourceColumns) assert.equal(mapping[i][key], source[key], `Mapping original ${step.id} ${key}`);
  assert.equal(step.originalNote, source.Originalnotiz);
  assert.equal(step.originalRawText, originalSteps[i].rawText);
  assert.equal(step.sourceNote, originalSteps[i].sourceNote);
  assert.equal(step.id, originalSteps[i].id);
  assert.equal(step.note.length > 0, true, `Speaker note ${step.id}`);
  assert.equal(step.title.length > 0, true, `Title ${step.id}`);
  assert.equal(/\b(?:iKIS|IKIS|ICES)\b/.test(step.title + step.subtitle + step.note + step.rawText), false, `Display spelling ${step.id}`);
  assert.equal(mappedIds.includes(step.id), true);
  assert.equal(sequences.find(s => s.id === step.sequenceId)?.stepIds.includes(step.id), true);
  assert.equal(mapping[i]['Neue-Sequenz-ID'], step.sequenceId);
  for (const source of step.sources) await access(resolve(root, '..', source.path));
}
for (const [chapter, count] of Object.entries(manifest.chapterCounts)) {
  assert.equal(steps.filter(s => s.chapter === Number(chapter)).length, count);
}
assert.equal(steps.find(s => s.id === '07.05').status, 'umgesetzt');
assert.equal(steps.find(s => s.id === '08.07').status, 'geplant');
assert.equal(steps.find(s => s.id === '09.15').status, 'SOLL');
assert.equal(steps.find(s => s.id === '08.12').status, 'offen');
console.log(JSON.stringify({ result: 'passed', preservedSourceSteps: steps.length, originalColumns: manifest.sourceColumns.length, sequences: sequences.length, chapterCounts: manifest.chapterCounts, localSources: 'all present', displaySpelling: 'ICIS', cases: ['source fields unchanged', 'speaker notes retained', 'legacy raw text retained', 'unique sequence mapping', 'status guardrails', 'source paths exist'] }, null, 2));
