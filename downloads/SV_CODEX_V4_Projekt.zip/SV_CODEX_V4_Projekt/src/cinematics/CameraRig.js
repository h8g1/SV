import * as THREE from 'three';
const v=a=>new THREE.Vector3(...a);
export const smooth=t=>{t=THREE.MathUtils.clamp(t,0,1);return t*t*(3-2*t)};
const blend=(a,b,t)=>v(a).lerp(v(b),smooth(t)).toArray();
export class CameraRig {
 constructor(camera,rooms,reduced=false){this.camera=camera;this.rooms=rooms;this.reduced=reduced;this.lastRoom='overview';this.entry=null;this.target=v(rooms.overview.target);this.sequence=null;}
 shot(seq,time){
  const r=this.rooms[seq.room]||this.rooms.overview;
  const q=this.reduced?.65:Math.max(0,Math.min(1,time/seq.duration));
  if(seq.room==='overview')return {position:blend([19,20,26],[15.2,17.8,23.5],q),target:r.target};
  if(seq.room==='outdoor'){
   if(seq.id==='prolog')return {position:blend([-6,28,22],r.camera,smooth(q*1.6)),target:blend([-11,0,3],r.target,smooth(q*1.4))};
   if(seq.action==='automatic')return {position:blend(r.camera,r.systemCamera,q),target:blend(r.target,r.systemTarget,q)};
   return {position:blend(r.camera,[r.camera[0]-.9,r.camera[1]-.15,r.camera[2]-.8],q),target:r.target};
  }
  if(seq.room==='input')return {position:blend(r.camera,[-6.3,1.65,.2],q),target:r.target};
  const c=r.character;
  const front=[c[0]+1.65,c[1]+1.5,c[2]+2.35];
  const frontTarget=[c[0]-.05,c[1]+1.05,c[2]+.05];
  if(['system','manual','automatic'].includes(seq.action)){
   const f=smooth((q-.2)/.4);
   const detail=[r.center[0]+.65,1.65,r.center[2]-.55];const pos=blend(front,detail,f);pos[1]+=Math.sin(f*Math.PI)*.6;return {position:pos,target:blend(frontTarget,r.systemTarget,f)};
  }
  return {position:blend(r.camera,front,smooth(q*.9)),target:blend(r.target,frontTarget,smooth(q*.9))};
 }
 enter(seq,previous,canonical=false){
  const start=canonical?this.shot(previous||{room:'overview',duration:10},previous?.duration||0):{position:this.camera.position.toArray(),target:this.target.toArray()};
  const roomChanged=previous?.room!==seq.room;
  const duration=canonical&&previous?.id===seq.id?0:this.reduced?.3:seq.action==='transfer'?10:roomChanged?6.5:2.1;
  this.entry={start,duration,roomChanged};this.sequence=seq;
 }
 render(seq,time){
  let s=this.shot(seq,time);
  const e=this.entry;
  if(e&&time<e.duration){
   const a=smooth(time/e.duration);
   if(seq.action==='transfer'&&!this.reduced){
    const first={position:[-.5,8.7,8.2],target:[0,.6,-2.5]},second={position:[3.5,8,7.2],target:[.5,.6,-2]};
    if(time<3)s={position:blend(e.start.position,first.position,time/3),target:blend(e.start.target,first.target,time/3)};
    else if(time<6.5)s={position:blend(first.position,second.position,(time-3)/3.5),target:blend(first.target,second.target,(time-3)/3.5)};
    else s={position:blend(second.position,s.position,(time-6.5)/3.5),target:blend(second.target,s.target,(time-6.5)/3.5)};
   }else if(seq.room==='outdoor'&&e.roomChanged&&!this.reduced){
    const wide={position:[-11.2,5,13],target:[-10.9,.95,4.4]};
    if(time<3)s={position:blend(e.start.position,wide.position,time/3),target:blend(e.start.target,wide.target,time/3)};
    else s={position:blend(wide.position,s.position,(time-3)/(e.duration-3)),target:blend(wide.target,s.target,(time-3)/(e.duration-3))};
   }else if(e.roomChanged&&!this.reduced){
    const start=v(e.start.position),end=v(s.position);
    const middle=start.clone().lerp(end,.5);middle.y=Math.max(5.4,Math.min(15,Math.max(start.y,end.y)+2));
    // A lifted quadratic path exposes the corridor between two workplaces.
    const pos=start.clone().multiplyScalar((1-a)**2).add(middle.multiplyScalar(2*(1-a)*a)).add(end.multiplyScalar(a*a));
    s={position:pos.toArray(),target:blend(e.start.target,s.target,a)};
   }else{s={position:blend(e.start.position,s.position,a),target:blend(e.start.target,s.target,a)}}
  }
  // Portrait view preserves the whole action rather than cropping to a face or desk.
  if(this.camera.aspect<1){const target=v(s.target);s.position=v(s.position).sub(target).multiplyScalar(Math.min(3,1/this.camera.aspect)).add(target).toArray();}
  this.camera.position.set(...s.position);this.target.set(...s.target);this.camera.lookAt(this.target);this.camera.updateMatrixWorld();
 }
}
