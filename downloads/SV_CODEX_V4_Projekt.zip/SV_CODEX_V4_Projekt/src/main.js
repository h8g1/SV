import './ui/style.css';
import * as THREE from 'three';
import {createWorld} from './world/index.js';
import {CameraRig,smooth} from './cinematics/CameraRig.js';
import {loadCharacters} from './characters/index.js';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const base=import.meta.env.BASE_URL;
const get=async name=>{const r=await fetch(`${base}content/${name}.json`);if(!r.ok)throw new Error(`Inhalt ${name}: ${r.status}`);return r.json()};
const [steps,sequences,manifest,processMap]=await Promise.all(['steps','sequences','manifest','process-map'].map(get));
let activeSequences=sequences,index=0,time=0,playing=false,mode='tour',lastFrame=performance.now(),renderer,world,characters,camera,rig,scene;
let noWebGL=false,exploring=false,rafId;const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const names={elias:'Elias',ali:'Ali',customer:'Kfz-Kunde',cancellation:'Kündigungskundin'};
const chapterNames={0:'PROLOG · DER MOMENT',4:'04 · ANTRAG & FACHPRÜFUNG',5:'05 · POLICIERUNG & BESTAND',6:'06 · EINORDNUNG ELIAS',7:'07 · SCHADENMELDUNG',8:'08 · SCHADENBEARBEITUNG',9:'09 · KÜNDIGUNG · EIGENER ZWEIG',10:'10 · GEMEINSAMES FAZIT'};
const current=()=>activeSequences[index];
const stats={frames:0,frameTimes:[],errors:[],assetErrors:[]};
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,3200)}
function setPlay(value){playing=value;$('play').innerHTML=value?'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M7 5v10M13 5v10"/></svg>':'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m7 4 9 6-9 6Z" class="filled"/></svg>';$('play').setAttribute('aria-label',value?'Pausieren':'Abspielen');lastFrame=performance.now();}
function updateCaption(){const s=current();$('scene-title').textContent=s.title;$('scene-subtitle').textContent=s.subtitle;$('chapter-label').textContent=chapterNames[s.chapter];$('status').textContent=s.status;$('status').dataset.status=s.status;$('flow').textContent=s.flow;$('actor-tag').textContent=s.room==='cancel'&&s.system?'Interne Bearbeitung':names[s.actor]||'Arbeitsbereich';$('system-tag').textContent=s.system;$('active-tag').hidden=!s.system;$('scene-number').textContent=`${String(index+1).padStart(2,'0')} — ${activeSequences.length}`;$('mode-label').textContent=exploring?'FREIE ERKUNDUNG':mode==='tour'?'GEFÜHRTE REISE':`QUALITÄTSSEQUENZ ${mode==='pilot-a'?'A':'B'}`;$('prev').disabled=index===0;$('next').disabled=index===activeSequences.length-1;if(mode==='tour')$('chapter').value=s.chapter;}
function enter(i,{canonical=false,seconds=0}={}){
 const previous=current();index=Math.max(0,Math.min(i,activeSequences.length-1));time=Math.max(0,Math.min(seconds,current().duration));
 if(rig){const prev=canonical?activeSequences[Math.max(0,index-1)]:previous;rig.enter(current(),prev,canonical);}
 updateCaption();render();
}
function render(){
 const s=current();$('progress-fill').style.width=`${time/s.duration*100}%`;$('scrub').value=time/s.duration*1000;
 const clock=t=>`${Math.floor(t/60)}:${String(Math.floor(t%60)).padStart(2,'0')}`;$('clock').textContent=`${clock(time)} / ${clock(s.duration)}`;
 if(!renderer)return;
 rig.render(s,time);characters?.update(s,reduced?1.8:time);
 world.update(time,{room:s.room,system:s.system,title:s.action==='manual'?'Rückfrage formulieren':s.action==='automatic'?'Daten übernommen':s.title,status:s.status,progress:time/s.duration});
 updatePulse(s,time);renderer.render(scene,camera);
}
let pulse,line,pulseMaterial,phoneScreen,phoneCanvas,phoneTex,clouds,lightning;
function makeFlow(){
 pulseMaterial=new THREE.MeshStandardMaterial({color:0x47826c,emissive:0x47826c,emissiveIntensity:.5,roughness:.35});
 pulse=new THREE.Mesh(new THREE.OctahedronGeometry(.055),pulseMaterial);scene.add(pulse);
 const c=document.createElement('canvas');c.width=360;c.height=660;phoneCanvas=c;phoneTex=new THREE.CanvasTexture(c);phoneTex.colorSpace=THREE.SRGBColorSpace;
 phoneScreen=new THREE.Mesh(new THREE.PlaneGeometry(.062,.115),new THREE.MeshBasicMaterial({map:phoneTex,side:THREE.DoubleSide}));phoneScreen.name='Digital damage form';
 characters.records.customer.root.traverse(n=>{if(n.isMesh){const mats=Array.isArray(n.material)?n.material:[n.material];mats.forEach(m=>{if(m.name==='Phone display'){m.map=phoneTex;m.color.set(0xffffff);m.emissive.set(0x667766);m.emissiveIntensity=.3;m.needsUpdate=true}})}});
 clouds=new THREE.Group();scene.add(clouds);
 const cloudCanvas=document.createElement('canvas');cloudCanvas.width=512;cloudCanvas.height=256;const ctx=cloudCanvas.getContext('2d');
 for(let i=0;i<12;i++){const x=50+(i*97)%420,y=90+Math.sin(i*2.4)*30;const gradient=ctx.createRadialGradient(x,y,4,x,y,88);gradient.addColorStop(0,'rgba(174,139,144,.6)');gradient.addColorStop(1,'rgba(174,139,144,0)');ctx.fillStyle=gradient;ctx.fillRect(x-88,y-88,176,176)}
 const cloudTex=new THREE.CanvasTexture(cloudCanvas);cloudTex.colorSpace=THREE.SRGBColorSpace;
 for(let i=0;i<5;i++){const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:cloudTex,transparent:true,depthWrite:false,opacity:.8}));sprite.position.set(-12+i*3,11+(i%2)*3,8-i*3);sprite.scale.set(18,9,1);clouds.add(sprite)}
 const lightningPoints=[[-12,15,3],[-11.7,14.4,3],[-12.1,13.8,3],[-11.6,13,3]].map(a=>new THREE.Vector3(...a));
 lightning=new THREE.Line(new THREE.BufferGeometry().setFromPoints(lightningPoints),new THREE.LineBasicMaterial({color:0xffe2e5,transparent:true,opacity:.7}));scene.add(lightning);
}
function updatePulse(s,t){
 if(!pulse)return;clouds.visible=s.id==='prolog'&&t<10;clouds.children.forEach(c=>c.material.opacity=Math.max(0,1-t/10)*.8);lightning.visible=!reduced&&s.id==='prolog'&&t>2.2&&t<2.45;const active=['manual','automatic'].includes(s.action)||(s.action==='transfer'&&s.id==='antrag-uebergabe');pulse.visible=active;
 if(active){
  const room=world.rooms[s.room];const p=room.monitor||room.target;const u=reduced?.65:smooth((t%5)/5);
  const pts=s.id==='antrag-uebergabe'?[
   new THREE.Vector3(-3.66,1.3,-2.72),new THREE.Vector3(-2.2,1.25,0),new THREE.Vector3(2.2,1.25,0),new THREE.Vector3(2.94,1.3,-2.72)
  ]:[new THREE.Vector3(p[0]-.4,p[1],p[2]),new THREE.Vector3(p[0],p[1]+.28,p[2]),new THREE.Vector3(p[0]+.5,p[1],p[2])];
  const curve=new THREE.CatmullRomCurve3(pts);pulse.position.copy(curve.getPoint(u));pulseMaterial.color.set(s.action==='manual'?0xb78548:0x47826c);pulseMaterial.emissive.copy(pulseMaterial.color);
  if(line?.userData.action!==s.id){if(line){line.geometry.dispose();line.material.dispose();scene.remove(line)}line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(curve.getPoints(80)),new THREE.LineDashedMaterial({color:s.action==='manual'?0xb78548:0x729687,transparent:true,opacity:.55,dashSize:s.action==='manual'?.08:.3,gapSize:s.action==='manual'?.12:.035}));line.computeLineDistances();line.userData.action=s.id;scene.add(line)}
 }if(line)line.visible=active;
 // The handset's form is local, demonstrative and carries no actual personal data.
 if(phoneScreen&&characters){
  const c=phoneCanvas.getContext('2d');c.fillStyle='#f7f6f0';c.fillRect(0,0,360,660);c.fillStyle='#d52c3a';c.fillRect(0,0,360,90);c.fillStyle='white';c.font='bold 27px Arial';c.fillText('Schaden melden',22,55);c.fillStyle='#7c9685';c.fillRect(22,116,316,180);c.fillStyle='#dbe3d9';for(let i=0;i<3;i++)c.fillRect(22,330+i*56,300-i*35,25);c.fillStyle='#426c55';c.fillRect(22,545,316,65);c.fillStyle='white';c.font='23px Arial';c.fillText(t>6?'Meldung erfasst':'Foto hinzufügen',65,585);phoneTex.needsUpdate=true;
 }
}
function setMode(next){mode=next;activeSequences=next==='tour'?sequences:manifest.pilots[next==='pilot-a'?'A':'B'].map(id=>sequences.find(s=>s.id===id));exploring=false;$('room-nav').hidden=true;enter(0);$('chapter').value=next==='tour'?current().chapter:next;}
function showOverview(){setPlay(false);exploring=true;$('room-nav').hidden=false;mode='tour';activeSequences=sequences;enter(sequences.findIndex(s=>s.id==='overview'));$('scene-title').textContent='Wo der Vorgang weitergeht.';$('scene-subtitle').textContent='Wähle einen Arbeitsbereich, um die Reise dort fortzusetzen.';}
function chooseRoom(room){const candidates=sequences.filter(s=>s.room===room);const s=candidates[0];if(!s)return;mode='tour';activeSequences=sequences;enter(sequences.indexOf(s));setPlay(false);}
function openDialog(id){setPlay(false);if(!$ (id).open)$(id).showModal();}
function renderSteps(){
 const query=$('search').value.toLocaleLowerCase('de');const chapter=$('detail-chapter').value;
 const filtered=steps.filter(s=>(chapter==='all'||String(s.chapter)===chapter)&&`${s.id} ${s.title} ${s.subtitle} ${s.note} ${s.rawText}`.toLocaleLowerCase('de').includes(query));
 $('step-list').innerHTML=filtered.length?filtered.map(s=>`<details class="step" data-step="${s.id}"><summary><span class="step-id">${s.id}</span><h3>${esc(s.title)}</h3><span class="status" data-status="${esc(s.status)}">${esc(s.status)}</span></summary><p>${esc(s.subtitle)}</p><h4>Sprechernotiz</h4><p>${esc(s.note)}</p><h4>Vollständiger Inhalt</h4><p>${esc(s.rawText)}</p><div class="caveat">${esc(s.statusCaveat)} ${s.evidenceNotes.map(esc).join(' ')}</div><h4>Quellen</h4><div class="source-links">${s.sources.map(source=>`<a target="_blank" rel="noopener" href="${base}${esc(source.path)}">${esc(source.label)} ↗</a>`).join('')}</div><details class="original"><summary>Unveränderte Originalfassung & Herkunft</summary><p>${esc(s.original.Originaltitel)} · ${esc(s.original.Originaluntertitel)}</p><p>${esc(s.originalNote)}</p><p>${esc(s.originalRawText)}</p><p>Datei: ${esc(s.original.Datei)} · Schritt ${s.sourceStep} · Sequenz ${esc(s.sequenceId)}</p></details><button class="jump" data-sequence="${esc(s.sequenceId)}">In der Reise öffnen ↗</button></details>`).join(''):'<p class="empty">Keine passenden Schritte.</p>';
}
function renderExpert(){
 const paths=[
 {name:'Antrag & Bestand',parts:['Antrag','Fachprüfung','Bestand'],note:'Standardfall und manueller Klärfall sind Alternativen. ICIS am Arbeitsplatz; Outlook für belegte Rückfragen.'},
 {name:'Online-Schaden',parts:['Kfz-Kunde','Onlineformular','ICIS','Ali'],note:'Bereits umgesetzt: automatische Übernahme der Online-Daten nach ICIS. PDF-Abtippen beschreibt den historischen Zustand.'},
 {name:'Kündigung',parts:['Anderer Vertragsfall','Brief / E-Mail','Postkorb / KSR','ICIS'],note:'Eigenständiger Zweig aus dem Vertragsbestand. Kein Folgeschritt eines Schadens. Technische Übergaben und KSR-Tiefe bleiben zu prüfen.'},
 {name:'Zielbilder',parts:['Aufgabenpool · geplant','Kündigungsportal · SOLL'],note:'Geplante Umstellung und Analysevorschlag werden nicht als vorhandene Standardfunktionen dargestellt.'}
 ];
 $('expert-content').innerHTML=`<p class="expert-intro">${esc(processMap.disclaimer)} Die Räume ordnen Funktionen. Sie behaupten weder reale Teamnähe noch eine technische Schnittstellenarchitektur.</p>${paths.map(p=>`<section class="process-row"><h3>${p.name}</h3><div class="process-path">${p.parts.map((n,i)=>`${i?'<i>→</i>':''}<span>${n}</span>`).join('')}</div><p>${p.note}</p></section>`).join('')}<div class="legend">${Object.keys(manifest.statusLegend).map(s=>`<span class="status" data-status="${s}">${s}</span>`).join('')}</div><details class="source-section"><summary>Systeme · fachliche Rolle und Grenzen (${processMap.systems.length})</summary>${processMap.systems.map(s=>`<p><strong>${esc(s.name)}</strong> · ${esc(s.status)}<br>${esc(s.role)}<br><small>${esc(s.caveat)}</small></p>`).join('')}</details><details class="source-section"><summary>Datenwege · Evidenz und offene Anschlüsse (${processMap.flows.length})</summary>${processMap.flows.map(f=>`<p><strong>${esc(f.from)} → ${esc(f.to)}</strong> · ${esc(f.status)} · ${f.type==='automatic'?'automatisch':f.type==='manual'?'manuell':'fachlich / schematisch'}<br>${esc(f.label)}<br><small>${esc(f.caveat)} Quellen: ${f.sourceIds.join(', ')}</small></p>`).join('')}</details><details class="source-section"><summary>Statusdefinitionen</summary>${Object.entries(manifest.statusLegend).map(([s,d])=>`<p><strong>${s}</strong> · ${esc(d)}</p>`).join('')}</details><p class="panel-help">Alle fachlichen Details und Quellen: „Notizen“. Die Originalschreibweisen bleiben dort zu Prüfzwecken erhalten; die Präsentation verwendet ICIS.</p>`;
}
function controls(){
 $('play').onclick=()=>{if(time>=current().duration)enter(index);setPlay(!playing)};
 $('next').onclick=()=>enter(index+1);$('prev').onclick=()=>enter(index-1);$('replay').onclick=()=>enter(index,{canonical:true});
 $('overview').onclick=showOverview;$('explore').onclick=()=>{if(exploring){exploring=false;$('room-nav').hidden=true;updateCaption()}else showOverview()};
 $('chapter').onchange=e=>{if(e.target.value.startsWith('pilot')){setMode(e.target.value);return}if(mode!=='tour'){mode='tour';activeSequences=sequences}exploring=false;$('room-nav').hidden=true;enter(sequences.findIndex(s=>String(s.chapter)===e.target.value));};
 $('notes').onclick=()=>{renderSteps();openDialog('details')};$('fallback-notes').onclick=()=>{renderSteps();openDialog('details')};$('map').onclick=()=>openDialog('expert');
 $('search').oninput=renderSteps;$('detail-chapter').onchange=renderSteps;
 $('step-list').onclick=e=>{const b=e.target.closest('[data-sequence]');if(b){$('details').close();mode='tour';activeSequences=sequences;enter(sequences.findIndex(s=>s.id===b.dataset.sequence));}};
 document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
 document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
 $('scrub').oninput=e=>{time=Number(e.target.value)/1000*current().duration;render()};
 $('quality').onchange=()=>{if(!renderer)return;const q=$('quality').value;renderer.setPixelRatio(q==='high'?Math.min(devicePixelRatio,2):q==='low'?.7:1);renderer.shadowMap.enabled=q!=='low';renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.needsUpdate=true;render()};
 $('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast('Vollbild über das Browsermenü öffnen.')}};
 document.addEventListener('keydown',e=>{if(e.target.matches('input,select,textarea')||document.querySelector('dialog[open]'))return;if(['Space','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='Space')$('play').click();if(e.code==='ArrowRight')$('next').click();if(e.code==='ArrowLeft')$('prev').click();if(e.key.toLowerCase()==='g')showOverview();if(e.key.toLowerCase()==='r')$('replay').click();if(e.key.toLowerCase()==='n')$('notes').click();if(e.key.toLowerCase()==='m')$('map').click();if(e.key.toLowerCase()==='f')$('fullscreen').click();});
}
controls();setPlay(false);renderSteps();renderExpert();
try{
 renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});renderer.setPixelRatio(1);renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.85;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 $('stage').appendChild(renderer.domElement);scene=new THREE.Scene();scene.background=new THREE.Color(0xf1ece3);scene.fog=new THREE.Fog(0xf1ece3,48,95);camera=new THREE.PerspectiveCamera(38,innerWidth/innerHeight,.08,220);camera.position.set(18,19,25);
 $('load-status').textContent='Die Prozesswelt entsteht …';world=await createWorld(scene);$('load-progress').value=35;
 rig=new CameraRig(camera,world.rooms,reduced);characters=await loadCharacters(scene,world.rooms,n=>{$('load-progress').value=n});makeFlow();renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;
 for(const r of Object.values(world.rooms)){if(r.id==='overview')continue;const b=document.createElement('button');b.textContent=r.label;b.dataset.room=r.id;const small=document.createElement('small');small.textContent=r.id==='cancel'?'EIGENSTÄNDIGER VERTRAGSWEG':'ARBEITSBEREICH ERKUNDEN';b.append(small);b.onclick=()=>chooseRoom(r.id);$('room-nav').append(b)}
 const raycaster=new THREE.Raycaster();renderer.domElement.addEventListener('click',e=>{if(!exploring)return;raycaster.setFromCamera(new THREE.Vector2(e.clientX/innerWidth*2-1,-e.clientY/innerHeight*2+1),camera);const hit=raycaster.intersectObjects(world.pickables,false)[0];if(hit)chooseRoom(hit.object.userData.room)});
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();setPlay(false);$('fallback').hidden=false;stats.errors.push('WebGL context lost')});
 window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);render()});
 enter(0,{canonical:true});
}catch(error){noWebGL=true;stats.assetErrors.push(String(error));console.error(error);$('fallback').hidden=false;$('load-status').textContent='Die fachliche Ansicht ist verfügbar.';}
document.querySelectorAll('nav button span').forEach(s=>s.innerHTML='<svg viewBox="0 0 12 12" width="9" height="9" aria-hidden="true"><path d="M2 10 10 2M3 2h7v7" fill="none" stroke="currentColor" stroke-width="1.2"/></svg>');
$('load-progress').value=100;$('loading').classList.add('finished');
function frame(now){const dt=Math.min((now-lastFrame)/1000,.1);lastFrame=now;if(playing){time+=dt*Number($('pace').value);if(time>current().duration){if(index<activeSequences.length-1)enter(index+1);else{time=current().duration;setPlay(false)}}}
 if(playing||stats.frames<2)render();stats.frames++;if(playing&&stats.frameTimes.length<2000)stats.frameTimes.push(dt*1000);rafId=requestAnimationFrame(frame);}
rafId=requestAnimationFrame(frame);
window.__SV={ready:true,get sequences(){return activeSequences},allSequences:sequences,steps,manifest,world,camera,renderer,characters,stats,
 state:()=>({index,time,playing,mode,sequenceId:current().id,room:current().room,noWebGL,exploring,reducedMotion:reduced}),
 seek:(i,seconds=0)=>{setPlay(false);enter(i,{canonical:true,seconds})},select:id=>{if(mode!=='tour'){mode='tour';activeSequences=sequences}const i=sequences.findIndex(s=>s.id===id);if(i>=0)enter(i)},
 play:()=>setPlay(true),pause:()=>setPlay(false),setMode,render,
 cameraState:()=>({position:camera?.position.toArray(),target:rig?.target.toArray()}),
 dispose:()=>{cancelAnimationFrame(rafId);scene?.traverse(n=>{n.geometry?.dispose();if(Array.isArray(n.material))n.material.forEach(m=>m.dispose());else n.material?.dispose()});renderer?.dispose();}
};
