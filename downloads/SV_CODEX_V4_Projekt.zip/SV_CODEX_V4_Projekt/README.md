# SV · Eine Reise durch den Vorgang

Ausführbare Three.js-Anwendung zur Customer Journey, Kapitel 4–10. Eine zusammenhängende schematische Cutaway-Welt verbindet Kundenfall, Antrag, Bestand, Schaden und den eigenständigen Kündigungszweig. **Kein tatsächlicher SV-Grundriss; alle Systemoberflächen sind Demonstrationen.** Nick ist nicht enthalten.

**Abnahmestand:** Fachmodell und Anwendung sind ausführbar. Das Premium-Charaktergate ist **nicht bestanden**: die mitgelieferten originalen, geriggten Modelle sind prozedurale Näherungen, keine professionell ausgearbeiteten Modelle in der Qualität der Referenzen. Auch das 30-FPS-Ziel ist in der getesteten Cloud-Softwaregrafik nicht erreicht. Details und tatsächliche Messergebnisse: [Testbericht](docs/TESTBERICHT.md), [Assetgrenzen](docs/ASSETS.md). Deshalb keine Behauptung einer vollständigen V4-Abnahme.

## Präsentation starten — ohne npm und ohne Internet

Im ZIP liegt `dist/` als fertiger Build mit allen lokalen Assets.

- **Windows:** `START_WINDOWS.bat` doppelklicken. Benötigt Python 3 oder Node.js. Der Starter öffnet den Browser und startet den lokalen Server.
- **macOS/Linux:** `./START_UNIX.sh`, dann die im Terminal genannte lokale Adresse im Browser öffnen.
- **Plattformunabhängig mit Node.js:** `node tools/serve.mjs`.
- **Alternativ mit Python 3:** `python -m http.server 4173 --bind 127.0.0.1 --directory dist`.

Die lokale Adresse lautet `http://localhost:4173`. Nicht per Doppelklick auf `index.html` öffnen: glTF- und Inhaltsabrufe brauchen HTTP. Der Server läuft ausschließlich lokal; Strg+C beendet ihn. Der Browser braucht WebGL2. Bei Ausfall bleibt die vollständige fachliche Ansicht zugänglich.

## Entwicklung

Node.js 22.12+ oder 24 verwenden. Im vorhandenen Checkout arbeiten; eine zusätzliche Git-Worktree ist nicht erforderlich.

```sh
npm ci --no-audit --no-fund
npm run dev
npm run build
npm run preview -- --port 4173
```

`package-lock.json` fixiert die Abhängigkeiten. Rollup ist auf eine tatsächlich abrufbare Version festgelegt. Laufzeit-Assets sind lokal; Netzwerk ist nur zur erstmaligen npm-Installation erforderlich. Blender 4.3.2 ist nur für eine Neuerzeugung der Modelle nötig, nicht zum Vorführen.

## Bedienung

Die Reise startet pausiert im Prolog. Play startet die deterministische Zeitleiste. Der Zeitregler spult innerhalb der aktuellen Szene; die Kapitelwahl springt zu den Kapiteln oder zu den beiden zusammenhängenden Qualitätssequenzen A/B. Übersicht und Erkundung nutzen dieselbe Welt; Bereiche lassen sich per Schaltfläche oder im Gebäudeblick direkt anklicken. „Gebäude“ führt zurück zur Orientierung.

| Taste | Aktion |
|---|---|
| Leertaste | Play / Pause |
| ← / → | Vorherige / nächste Szene |
| R | Aktuelle Szene erneut |
| G | Gebäudeübersicht und Raumwahl |
| N | Originalschritte, Notizen und Quellen |
| M | Optionale System-/Prozesslandkarte |
| F | Vollbild |
| Escape | Dialog schließen |

Tempo und Grafikqualität lassen sich unten einstellen. „Sparsam“ reduziert Auflösung und Schatten. `prefers-reduced-motion` reduziert Kamerabewegung und friert Figurenposen ein. Die Erkundung bietet geführte Raumfahrten und direkte Bereichswahl, keinen frei fliegenden First-Person-Modus.

## Fachliche Vollständigkeit

`public/content/steps.json` enthält **85/85** Schritte, unveränderte Matrixfelder, Originalnotizen/Rohtexte, korrigierte Anzeigetexte, Quellen und Sequenz-IDs. `public/content/content_mapping.csv` enthält die maschinenlesbare 1:1-Zuordnung zu 25 fachlichen Filmsequenzen; Prolog und Orientierung ergänzen sie zu insgesamt 27 Sequenzen.

Originalverteilung: Kapitel 4=8, 5=8, 6=11, 7=12, 8=13, 9=16, 10=17. Historische Schreibweisen bleiben nur in ausdrücklich bezeichneten Originalauszügen erhalten; die Anzeige verwendet ICIS. Automatische Online-Schadenübernahme: umgesetzt. Aufgabenpool: geplant/Umstellung. Digitales Kündigungsportal: SOLL. Kündigung: eigener Vertragszweig, keine automatische Schadenfolge.

Lokale Fachquellen einschließlich der fünf Original-HTMLs liegen unter `public/content/sources/`. Quellenkritik und Versionsabweichungen stehen in [CONTENT_AUDIT.md](docs/CONTENT_AUDIT.md). Keine erfundenen Schnittstellen oder Effizienzkennzahlen.

## Prüfen

```sh
npm run test:content
node src/content/verify.mjs
npm run build
# Separates Terminal: npm run preview -- --port 4173
python tests/browser_test.py --base-url http://127.0.0.1:4173 --output screenshots --report docs/browser-report.json
```

Der Browser-Test benötigt Python Playwright und Chromium; der mitgelieferte Bericht stammt aus einer tatsächlichen Ausführung, nicht aus einem simulierten Browser. Screenshots liegen in `screenshots/`. [Screenshotübersicht](docs/SCREENSHOTS.html) stellt Browseraufnahmen und die vier gezielt verwendeten Charakterreferenzen nebeneinander dar. Messwerte, fehlgeschlagene Prüfungen und Grenzen sind im Testbericht ausgewiesen.

## Projektstruktur

- `src/world/`: zusammenhängende Architektur, Möbel-GLBs, Monitore, PBR-Materialien und Licht
- `src/characters/`: GLTFLoader, echte Skins, AnimationMixer und Rollenidentität
- `src/cinematics/`: zeitabhängige Kamerarigs, kontrollierte Raumübergänge und reduzierte Bewegung
- `src/main.js`, `src/ui/`: Timeline, geführte Tour, Erkundung, Notizen, Expertenansicht und Fallback
- `public/models/`: vier Charakter-GLBs, Fahrzeug, Tisch, Stuhl, technisches Modellmanifest
- `public/content/`: 85 Schritte, Mapping, Statuslegende und mitgelieferte Originalquellen
- `public/references/`, `public/brand/`: alle neun Nutzerreferenzen und unverändertes Original-Logo
- `tools/`: lokale Serverhilfe und reproduzierbare Blender-Generatoren
- `tests/`, `docs/`, `screenshots/`: reproduzierbare Prüfungen, ehrlicher Abnahmestand und Nachweise

Die Bilder sind Stilreferenzen und keine Porträtnachweise realer Mitarbeitender. Markenrechte am SV-Logo verbleiben beim Rechteinhaber. Bibliothekslizenzen und Assetherkunft: [LICENSES.md](docs/LICENSES.md).
