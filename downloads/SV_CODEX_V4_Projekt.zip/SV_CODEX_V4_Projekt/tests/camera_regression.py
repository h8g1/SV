"""Targeted final-build regression after camera/corridor-only changes.
Preserves original functional run boundary and refreshes actual 3D screenshots.
"""
import asyncio
import hashlib
import json
import math
import statistics
import time
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]


async def main():
    report_path=ROOT/'docs/browser-report.json'
    report=json.loads(report_path.read_text())
    revision={'startedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope':'Camera entry/framing, portrait distance and physical corridor gap only; application content and controls unchanged.','checks':[],'screenshots':[],'pageErrors':[]}
    def check(name,passed,evidence=None):revision['checks'].append({'name':name,'passed':bool(passed),'evidence':evidence})
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
        page=await browser.new_page(viewport={'width':1366,'height':768})
        page.on('pageerror',lambda e:revision['pageErrors'].append(str(e)))
        response=await page.goto(report['baseURL'],wait_until='networkidle',timeout=120000)
        revision['entrySHA256']=hashlib.sha256(await response.body()).hexdigest()
        revision['entryScript']=await page.locator('script[type="module"]').get_attribute('src')
        check('Final camera revision equals delivered production build',revision['entrySHA256']==hashlib.sha256((ROOT/'dist/index.html').read_bytes()).hexdigest(),revision['entryScript'])
        await page.wait_for_function('window.__SV && window.__SV.ready',timeout=120000)
        await page.evaluate('window.__SV.pause()')
        sequences=await page.evaluate('window.__SV.allSequences')
        async def goto(id,seconds):
            idx=next(i for i,s in enumerate(sequences) if s['id']==id)
            # Flush each rendered sample so rapid seeks cannot leave a long
            # SwiftShader command queue ahead of the next screenshot.
            await page.evaluate('([i,t])=>{window.__SV.seek(i,t);window.__SV.renderer.getContext().finish()}',[idx,seconds])
            await page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
        async def shot(name):
            await page.screenshot(path=str(ROOT/f'screenshots/{name}.png'),animations='disabled')
            revision['screenshots'].append(f'screenshots/{name}.png')
        shots=[('prolog',2,'01_prolog_1366'),('overview',5,'02_gebaeude_1366'),('antrag-pruefung',4,'03_elias_arbeitsplatz_1366'),('antrag-pruefung',12,'04_elias_system_1366'),('antrag-rueckfrage',9,'05_manuelle_rueckfrage_1366'),('antrag-uebergabe',0,'06_raumwechsel_anfang_1366'),('antrag-uebergabe',5,'06_raumwechsel_mitte_1366'),('antrag-uebergabe',11,'06_raumwechsel_ziel_1366'),('schaden-ereignis',5,'07_kfz_kunde_smartphone_1366'),('schaden-online',10,'08_automatische_uebernahme_1366'),('schaden-aufnahme',4,'09_ali_arbeitsplatz_1366'),('schaden-aufnahme',11,'10_ali_system_1366'),('kuendigung-eingang',7,'11_kuendigung_separater_fall_1366')]
        for id,t,name in shots:await goto(id,t);await shot(name)
        # Evaluate half-second points on the exact deterministic camera path.
        poses=[]
        for n in range(21):
            await goto('antrag-uebergabe',n*.5)
            poses.append(await page.evaluate('window.__SV.camera.position.toArray()'))
        deltas=[math.dist(a,b) for a,b in zip(poses,poses[1:])]
        check('Final transfer path finite and continuous at 0.5s timeline samples',all(math.isfinite(v) for xyz in poses for v in xyz) and max(deltas)<8,{'positions':poses,'maxDistancePerHalfSecond':max(deltas)})
        await goto('antrag-uebergabe',5)
        line_state='''()=>window.__SV.world.root.parent.children.filter(n=>n.isLine&&n.material?.isLineDashedMaterial).map(n=>({id:n.userData.action,visible:n.visible}))'''
        lines=await page.evaluate(line_state)
        check('Only the sourced Elias handover shows corridor flow',any(x['visible'] and x['id']=='antrag-uebergabe' for x in lines),lines)
        for id in ['schaden-zuweisung','schaden-pool']:
            await goto(id,11)
            lines=await page.evaluate(line_state)
            check(id+' has no unrelated physical data line',not any(x['visible'] for x in lines),lines)
        # Use independently loaded viewport contexts for photographic evidence.
        # A fresh page also isolates 1920 capture from SwiftShader compositor
        # state after the rapid seek stress samples above.
        await page.close()
        page=await browser.new_page(viewport={'width':1920,'height':1080})
        page.on('pageerror',lambda e:revision['pageErrors'].append(str(e)))
        await page.goto(report['baseURL'],wait_until='networkidle',timeout=120000)
        await page.wait_for_function('window.__SV && window.__SV.ready',timeout=120000)
        for id,t,name in [('antrag-pruefung',4,'14_elias_1920'),('schaden-aufnahme',4,'15_ali_1920'),('schaden-ereignis',5,'16_kfz_1920')]:await goto(id,t);await shot(name)
        await page.close()
        page=await browser.new_page(viewport={'width':390,'height':844})
        page.on('pageerror',lambda e:revision['pageErrors'].append(str(e)))
        await page.goto(report['baseURL'],wait_until='networkidle',timeout=120000)
        await page.wait_for_function('window.__SV && window.__SV.ready',timeout=120000)
        await goto('antrag-pruefung',1);await shot('17_mobile_390')
        await goto('schaden-aufnahme',6);await shot('21_mobile_ali')
        metrics=await page.evaluate('({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth})')
        check('Final portrait camera build has no horizontal overflow',metrics['documentWidth']<=metrics['viewport']+1,metrics)
        await page.close()
        page=await browser.new_page(viewport={'width':1366,'height':768})
        page.on('pageerror',lambda e:revision['pageErrors'].append(str(e)))
        await page.goto(report['baseURL'],wait_until='networkidle',timeout=120000)
        await page.wait_for_function('window.__SV && window.__SV.ready',timeout=120000)
        await goto('antrag-pruefung',0)
        await page.evaluate('window.__SV.play()')
        timing=await page.evaluate('''()=>new Promise(resolve=>{const d=[];let start,last;function f(t){if(start===undefined){start=last=t;}else{d.push(t-last);last=t;}if(t-start<5000)requestAnimationFrame(f);else resolve(d);}requestAnimationFrame(f);})''')
        await page.evaluate('window.__SV.pause()')
        median=statistics.median(timing);p95=sorted(timing)[min(len(timing)-1,int(len(timing)*.95))]
        performance={'viewport':'1366x768','quality':'medium','pace':'1','durationSeconds':sum(timing)/1000,'renderedIntervals':len(timing),'medianFrameMs':median,'p95FrameMs':p95,'meanFPS':len(timing)/(sum(timing)/1000),'medianFPS':1000/median,'framesOver100ms':sum(x>100 for x in timing),'target30FPSMet':median<=33.34,'limitation':'Cloud headless SwiftShader software renderer; physical presentation laptop not tested.'}
        revision['performance']=performance
        revision['renderInfo']=await page.evaluate('window.__SV.renderer.info.render')
        check('Final camera revision has no JavaScript exceptions',not revision['pageErrors'],revision['pageErrors'])
        await browser.close()
    revision['completedUTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    report['cameraRevision']=revision
    report['previousBuildPerformance']=report['performance']
    report['performance']=performance
    report['screenshots']=list(dict.fromkeys(report['screenshots']+revision['screenshots']))
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({'script':revision['entryScript'],'checks':revision['checks'],'performance':performance},ensure_ascii=False,indent=2))
    return 0 if all(c['passed'] for c in revision['checks']) else 1


if __name__=='__main__':raise SystemExit(asyncio.run(main()))
