"""Supplementary keyboard, 85-step UI and pilot tests on the same production build.
Run after browser_test.py; appends real checks to its report and refreshes the
10-second room-flight screenshots at the actual start, midpoint and destination.
"""
import asyncio
import hashlib
import json
import time
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]


async def main():
    report_path=ROOT/'docs/browser-report.json'
    report=json.loads(report_path.read_text())
    previous_start=next((i for i,c in enumerate(report['checks']) if c['name'].startswith('Supplement uses ')),None)
    if previous_start is not None:
        report.setdefault('priorSupplementAttempts',[]).append({
            'completedUTC':report.get('supplementCompletedUTC'),
            'checks':report['checks'][previous_start:],
            'diagnosis':('First pilot completion check used a fixed 1.5s wait, shorter than observed 2.483s software-renderer p95 frame. Replaced with bounded wait for actual player completion.' if any(not c['passed'] for c in report['checks'][previous_start:]) else 'Revalidation after camera-only build revision; previous successful checks retained.')
        })
        report['checks']=report['checks'][:previous_start]
        report['screenshots']=list(dict.fromkeys(report['screenshots']))
    report['supplementStartedUTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    def check(name,passed,evidence=None):
        report['checks'].append({'name':name,'passed':bool(passed),'evidence':evidence})
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
        page=await browser.new_page(viewport={'width':1366,'height':768})
        response=await page.goto(report['baseURL'],wait_until='networkidle',timeout=120000)
        sha=hashlib.sha256(await response.body()).hexdigest()
        prior=report.get('cameraRevision',{}).get('entrySHA256') or next(x['evidence']['servedSHA256'] for x in report['checks'] if x['name']=='Served entry equals current production build')
        check('Supplement uses recorded production build',sha==prior,sha)
        await page.wait_for_function('window.__SV && window.__SV.ready',timeout=120000)
        sequences=await page.evaluate('window.__SV.allSequences')
        idx=next(i for i,s in enumerate(sequences) if s['id']=='antrag-uebergabe')
        poses=[]
        for name,seconds in [('anfang',0),('mitte',5),('ziel',11)]:
            await page.evaluate('([i,t])=>window.__SV.seek(i,t)',[idx,seconds])
            await page.wait_for_timeout(250)
            poses.append({'time':seconds,'camera':await page.evaluate('window.__SV.camera.position.toArray()'),'actor':await page.evaluate('window.__SV.characters.records.elias.root.position.toArray()')})
            await page.screenshot(path=str(ROOT/f'screenshots/06_raumwechsel_{name}_1366.png'),animations='disabled')
        report['roomTransferActual10SecondPath']=poses
        check('Actor traverses corridor during continuous camera flight',abs(poses[1]['actor'][2])<1 and poses[0]['actor'][0]<0 and poses[2]['actor'][0]>0,poses)
        cancel_idx=next(i for i,s in enumerate(sequences) if s['chapter']==9)
        await page.evaluate('(i)=>window.__SV.seek(i,7)',cancel_idx)
        label=await page.locator('#actor-tag').inner_text()
        check('Cancellation internal systems are not assigned to customer',label=='Interne Bearbeitung',label)
        for id,t,name in [('kuendigung-antwort',4,'23_cancellation_character'),('kuendigung-eingang',2,'24_cancellation_entry'),('kuendigung-pruefung',4,'25_cancellation_review')]:
            i=next(i for i,s in enumerate(sequences) if s['id']==id)
            await page.evaluate('([i,t])=>{window.__SV.seek(i,t);window.__SV.renderer.getContext().finish()}',[i,t])
            await page.screenshot(path=str(ROOT/f'screenshots/{name}.png'),animations='disabled')
            report['screenshots'].append(f'screenshots/{name}.png')
        # Focus the presentation itself before testing documented keyboard shortcuts.
        idx=next(i for i,s in enumerate(sequences) if s['id']=='antrag-pruefung')
        await page.evaluate('(i)=>{window.__SV.seek(i,4);document.activeElement.blur()}',idx)
        await page.keyboard.press('ArrowRight')
        a=await page.evaluate('window.__SV.state()')
        await page.keyboard.press('ArrowLeft')
        b=await page.evaluate('window.__SV.state()')
        check('Arrow-key scene navigation',a['index']==idx+1 and b['index']==idx,{'next':a,'back':b})
        await page.keyboard.press('Space');a=await page.evaluate('window.__SV.state()')
        await page.keyboard.press('Space');b=await page.evaluate('window.__SV.state()')
        check('Space toggles playback and pause',a['playing'] and not b['playing'])
        await page.keyboard.press('r');check('R repeats current scene',(await page.evaluate('window.__SV.state()'))['time']<.2)
        await page.keyboard.press('n');check('N opens speaker notes',await page.locator('#details').is_visible())
        await page.locator('#detail-chapter').select_option('9')
        check('UI exposes all 16 cancellation source steps',await page.locator('#step-list > details.step').count()==16)
        await page.locator('#detail-chapter').select_option('all')
        await page.locator('#search').fill('ICIS')
        count=await page.locator('#step-list > details.step').count()
        check('Source search returns relevant content',0<count<85,count)
        await page.locator('#search').fill('')
        check('UI exposes all 85 original steps',await page.locator('#step-list > details.step').count()==85)
        first=page.locator('#step-list > details.step').first
        await first.locator('> summary').click()
        target=await first.locator('[data-sequence]').get_attribute('data-sequence')
        await first.locator('[data-sequence]').click()
        check('Source-to-film mapping jump works',(await page.evaluate('window.__SV.state()'))['sequenceId']==target)
        await page.evaluate('document.activeElement.blur()')
        await page.keyboard.press('m');check('M opens expert map',await page.locator('#expert').is_visible())
        await page.keyboard.press('Escape');check('Escape dismisses expert map',not await page.locator('#expert').is_visible())
        for mode,key in [('pilot-a','A'),('pilot-b','B')]:
            await page.locator('#chapter').select_option(mode)
            ids=await page.evaluate('window.__SV.sequences.map(s=>s.id)')
            expected=await page.evaluate('(k)=>window.__SV.manifest.pilots[k]',key)
            check('Pilot '+key+' selects exact documented sequence chain',ids==expected,ids)
            last=await page.evaluate('window.__SV.sequences.length-1')
            duration=await page.evaluate('(i)=>window.__SV.sequences[i].duration',last)
            await page.evaluate('([i,t])=>{window.__SV.seek(i,t-.01);window.__SV.play()}',[last,duration])
            await page.wait_for_function('!window.__SV.state().playing',polling=100,timeout=15000)
            st=await page.evaluate('window.__SV.state()')
            check('Pilot '+key+' ends cleanly',not st['playing'] and st['index']==last,st)
        await page.locator('#chapter').select_option('7')
        check('Chapter selection exits pilot mode',(await page.evaluate('window.__SV.state()'))['mode']=='tour' and await page.evaluate('window.__SV.sequences.length')==27)
        ali_idx=next(i for i,s in enumerate(sequences) if s['id']=='schaden-aufnahme')
        await page.evaluate('(i)=>window.__SV.seek(i,6)',ali_idx)
        await page.set_viewport_size({'width':390,'height':844})
        metrics=await page.evaluate('({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth})')
        check('Final mobile layout fits viewport',metrics['documentWidth']<=metrics['viewport']+1,metrics)
        await page.screenshot(path=str(ROOT/'screenshots/21_mobile_ali.png'),animations='disabled')
        report['screenshots'].append('screenshots/21_mobile_ali.png')
        await page.locator('#notes').click()
        await page.screenshot(path=str(ROOT/'screenshots/20_mobile_notes.png'),animations='disabled')
        report['screenshots'].append('screenshots/20_mobile_notes.png')
        await browser.close()
    report['supplementCompletedUTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    report['screenshots']=list(dict.fromkeys(report['screenshots']))
    report['functionalPassed']=all(x['passed'] for x in report['checks'])
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({'checks':len(report['checks']),'passed':sum(x['passed'] for x in report['checks']),'failed':[x for x in report['checks'] if not x['passed']]},ensure_ascii=False,indent=2))
    return 0 if report['functionalPassed'] else 1


if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
