"""Actual Chromium QA against the built local application; no image generation.

Usage: python tests/browser_test.py --base-url http://127.0.0.1:4173
Requires the Python Playwright package and Chromium (or --chromium path).
"""
import argparse
import asyncio
import hashlib
import json
import math
import os
import platform
import statistics
import time
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]


async def run(args):
    output = ROOT / args.output
    output.mkdir(parents=True, exist_ok=True)
    report = {
        "runStartedUTC": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        "baseURL": args.base_url,
        "buildUnderTest": "Vite production preview (caller must build first)",
        "browser": {}, "checks": [], "screenshots": [], "pageErrors": [],
        "consoleErrors": [], "failedRequests": [], "externalRequests": [],
        "visualAcceptance": {"status": "MANUAL_REVIEW_REQUIRED", "reason": "Screenshots and functional assertions do not establish reference likeness, natural animation or premium model quality."},
    }

    def check(name, passed, evidence=None):
        report['checks'].append({"name": name, "passed": bool(passed), "evidence": evidence})

    async with async_playwright() as p:
        launch_args = ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']
        browser = await p.chromium.launch(executable_path=args.chromium, headless=True, args=launch_args)
        report['browser'] = {"version": browser.version, "executable": args.chromium, "headless": True,
                             "rendererMode": "ANGLE SwiftShader software rendering (cloud container)",
                             "platform": platform.platform(), "CPUlogical": os.cpu_count(),
                             "launchArguments": launch_args}
        context = await browser.new_context(viewport={"width": 1366, "height": 768}, device_scale_factor=1)
        page = await context.new_page()
        page.on('pageerror', lambda e: report['pageErrors'].append(str(e)))
        page.on('console', lambda m: report['consoleErrors'].append(m.text) if m.type == 'error' else None)
        page.on('requestfailed', lambda r: report['failedRequests'].append({"url":r.url,"failure":r.failure}))
        def request(r):
            if not r.url.startswith((args.base_url, 'data:', 'blob:')):
                report['externalRequests'].append(r.url)
        page.on('request', request)
        await page.route('**/*', lambda route: route.continue_() if route.request.url.startswith((args.base_url,'data:','blob:')) else route.abort())
        response = await page.goto(args.base_url, wait_until='networkidle', timeout=120000)
        check('Production entry HTTP 200', response.status == 200, response.status)
        served_hash=hashlib.sha256((await response.body())).hexdigest()
        built_hash=hashlib.sha256((ROOT/'dist/index.html').read_bytes()).hexdigest()
        check('Served entry equals current production build',served_hash==built_hash,{"servedSHA256":served_hash,"buildSHA256":built_hash})
        await page.wait_for_function('window.__SV && window.__SV.ready', timeout=120000)
        await page.wait_for_timeout(1000)
        await page.evaluate('window.__SV.pause()')
        sequences = await page.evaluate('window.__SV.sequences')
        check('All cinematic content loaded', len(sequences) >= 20, len(sequences))
        check('85 steps loaded by runtime', await page.evaluate('window.__SV.steps.length') == 85)
        rigs=await page.evaluate('''()=>Object.fromEntries(Object.entries(window.__SV.characters.records).map(([name,r])=>{
          let skins=0,bones=0;r.root.traverse(n=>{if(n.isSkinnedMesh)skins++;if(n.isBone)bones++;});
          return [name,{skinnedMeshes:skins,bones,clips:r.clips.map(c=>c.name)}];
        }))''')
        check('Four actual GLB character rigs and animation clips loaded',len(rigs)==4 and all(r['skinnedMeshes']>0 and r['bones']>0 and len(r['clips'])>0 for r in rigs.values()),rigs)

        async def state():
            return await page.evaluate('window.__SV.state()')

        async def goto(seq_id, seconds=0):
            idx = next(i for i,s in enumerate(sequences) if s['id'] == seq_id)
            await page.evaluate('([i,t])=>{window.__SV.pause();window.__SV.seek(i,t)}', [idx,seconds])
            await page.wait_for_timeout(300)
            return idx

        async def shot(name):
            target = output / (name+'.png')
            await page.screenshot(path=str(target), full_page=False, animations='disabled')
            report['screenshots'].append(str(target.relative_to(ROOT)))

        for actor,scene_id in [('elias','antrag-pruefung'),('ali','schaden-aufnahme'),('customer','schaden-ereignis')]:
            bone_poses=[]
            for sample in [.2,1.1]:
                await goto(scene_id,sample)
                bone_poses.append(await page.evaluate('''name=>{
                    const out=[];window.__SV.characters.records[name].root.traverse(n=>{
                        if(n.isBone)out.push(...n.position.toArray(),...n.quaternion.toArray());
                    });return out;
                }''',actor))
            changed=sum(abs(a-b)>1e-5 for a,b in zip(*bone_poses))
            check(actor+' skeleton actually animates at timeline positions',changed>0,{"changedTransformComponents":changed})

        await goto('prolog',2)
        await shot('01_prolog_1366')
        await goto('overview',5)
        await shot('02_gebaeude_1366')
        await goto('antrag-pruefung',4)
        await shot('03_elias_arbeitsplatz_1366')
        await goto('antrag-pruefung',12)
        await shot('04_elias_system_1366')
        await goto('antrag-rueckfrage',9)
        await shot('05_manuelle_rueckfrage_1366')

        # The same continuous timeline at three points, not three independently staged scenes.
        transfer = next(s for s in sequences if s['id']=='antrag-uebergabe')
        poses=[]
        # CameraRig transfer flight lasts 10s; capture its actual midpoint.
        flight_duration=min(10,transfer['duration'])
        for label,t in [('anfang',0),('mitte',flight_duration/2),('ziel',min(transfer['duration'],flight_duration+1))]:
            await goto('antrag-uebergabe',t)
            poses.append({"time":t,"position":await page.evaluate('window.__SV.camera.position.toArray()')})
            await shot('06_raumwechsel_'+label+'_1366')
        check('Transfer has distinct intermediate camera positions', len({tuple(p['position']) for p in poses}) == 3, poses)
        await goto('antrag-uebergabe',0)
        await page.evaluate('window.__SV.play()')
        live=[]
        for _ in range(18):
            live.append({"wallTime":time.monotonic(),"position":await page.evaluate('window.__SV.camera.position.toArray()')})
            await page.wait_for_timeout(200)
        await page.evaluate('window.__SV.pause()')
        deltas=[math.dist(a['position'],b['position']) for a,b in zip(live,live[1:])]
        check('Live camera transition stays finite and continuous at 200ms samples', all(math.isfinite(x) for x in deltas) and max(deltas,default=0)<4, {"maxDistancePerSample":max(deltas,default=0),"samples":live})

        await goto('schaden-ereignis',5)
        await shot('07_kfz_kunde_smartphone_1366')
        await goto('schaden-online',10)
        await shot('08_automatische_uebernahme_1366')
        await goto('schaden-aufnahme',4)
        await shot('09_ali_arbeitsplatz_1366')
        await goto('schaden-aufnahme',11)
        await shot('10_ali_system_1366')
        cancel = next(s for s in sequences if s['chapter']==9)
        await goto(cancel['id'],7)
        await shot('11_kuendigung_separater_fall_1366')

        # Exercise real controls as well as the deterministic screenshot interface.
        await goto('antrag-pruefung',4)
        await page.locator('#play').click()
        await page.wait_for_timeout(500)
        playing=await state()
        await page.locator('#play').click()
        paused=await state()
        await page.wait_for_timeout(400)
        later=await state()
        check('Play / pause controls', playing.get('playing') is True and paused.get('playing') is False, {"playing":playing,"paused":paused})
        check('Pause freezes timeline', abs(later.get('time',0)-paused.get('time',0))<.08, {"before":paused,"after":later})
        before=await state()
        await page.locator('#next').click(); after=await state()
        check('Next control', after.get('index')==before.get('index')+1, after)
        await page.locator('#prev').click(); back=await state()
        check('Previous control', back.get('index')==before.get('index'), back)
        await page.locator('#replay').click(); replay=await state()
        check('Replay starts scene near zero', replay.get('time',999)<.5, replay)
        await page.evaluate('window.__SV.pause()')

        async def close_panels():
            close = page.locator('[data-close]:visible')
            for _ in range(await close.count()):
                if await close.count(): await close.first.click()

        await page.locator('#notes').click()
        check('Speaker notes open', await page.locator('[data-close]:visible').count()>0)
        await shot('12_sprecherdetails_1366')
        await close_panels()
        await page.locator('#map').click()
        check('Expert map opens on request', await page.locator('[data-close]:visible').count()>0)
        await shot('13_expertenkarte_1366')
        await close_panels()
        await page.locator('#chapter').select_option('7')
        check('Chapter selection selects chapter 7', sequences[(await state())['index']]['chapter']==7, await state())
        await page.evaluate('window.__SV.pause()')
        await page.locator('#overview').click()
        await page.wait_for_timeout(500)
        check('Overview control keeps valid camera', await page.evaluate('window.__SV.camera.position.toArray().every(Number.isFinite)'))
        if (await state()).get('exploring'):
            await page.locator('#explore').click()
        await page.locator('#explore').click()
        await page.wait_for_timeout(500)
        explore=await state()
        check('Free exploration enabled', explore.get('mode')=='explore' or explore.get('exploring') is True, explore)
        room_btn = page.locator('[data-room="ali"]:visible')
        if await room_btn.count():
            await room_btn.first.click()
            check('Direct room selection', True, await state())
        else:
            check('Direct room selection', False, 'No visible [data-room="ali"] control in explore mode')
        await page.locator('#explore').click()
        returned=await state()
        check('Return to guided tour', returned.get('mode')!='explore' and not returned.get('exploring',False),returned)

        for selector in ['#quality','#pace']:
            options=await page.locator(selector+' option').evaluate_all('(els)=>els.map(x=>x.value)')
            if len(options)>1:
                await page.locator(selector).select_option(options[-1])
                await page.locator(selector).select_option(options[0])
                check(selector+' setting changes', True, options)
            else: check(selector+' setting changes', False, options)
        try:
            await page.locator('#fullscreen').click()
            await page.wait_for_timeout(200)
            enabled=await page.evaluate('!!document.fullscreenElement')
            check('Fullscreen control', enabled, {"fullscreenEnabled":await page.evaluate('document.fullscreenEnabled')})
            if enabled: await page.evaluate('document.exitFullscreen()')
        except Exception as exc: check('Fullscreen control',False,str(exc))

        # No overlapping animation loops or increasing GPU allocations on rapid selection.
        memory0=await page.evaluate('window.__SV.renderer.info.memory')
        ids=['antrag-pruefung','schaden-online',cancel['id'],'antrag-uebergabe','schaden-aufnahme']
        for _ in range(4):
            for seq_id in ids:
                await page.evaluate('(id)=>window.__SV.select(id)',seq_id)
        await page.wait_for_timeout(800)
        await page.evaluate('window.__SV.pause()')
        memory1=await page.evaluate('window.__SV.renderer.info.memory')
        check('Rapid navigation preserves finite camera',await page.evaluate('window.__SV.camera.position.toArray().every(Number.isFinite)'))
        check('Rapid navigation does not grow geometry allocations', memory1['geometries']<=memory0['geometries']+5, {"before":memory0,"after":memory1})

        await goto('antrag-pruefung',4)
        await page.set_viewport_size({"width":1920,"height":1080})
        await shot('14_elias_1920')
        await goto('schaden-aufnahme',4)
        await shot('15_ali_1920')
        await goto('schaden-ereignis',5)
        await shot('16_kfz_1920')
        # Actual RAF timing while the application is playing; no fixed FPS claim.
        await page.set_viewport_size({"width":1366,"height":768})
        await page.locator('#quality').select_option('medium')
        await page.locator('#pace').select_option('1')
        await goto('antrag-pruefung',0)
        await page.evaluate('window.__SV.play()')
        timing=await page.evaluate('''()=>new Promise(resolve=>{
          const deltas=[];let start,last;
          function frame(now){if(start===undefined){start=last=now;}else{deltas.push(now-last);last=now;}
            if(now-start<5000)requestAnimationFrame(frame);else resolve(deltas);}
          requestAnimationFrame(frame);
        })''')
        await page.evaluate('window.__SV.pause()')
        sorted_t=sorted(timing)
        p95=sorted_t[min(len(sorted_t)-1,int(len(sorted_t)*.95))]
        median=statistics.median(timing)
        report['performance']={"viewport":"1366x768","quality":await page.locator('#quality').input_value(),"pace":await page.locator('#pace').input_value(),"durationSeconds":sum(timing)/1000,"renderedIntervals":len(timing),
                               "medianFrameMs":median,"p95FrameMs":p95,"meanFPS":len(timing)/(sum(timing)/1000),
                               "medianFPS":1000/median,"framesOver100ms":sum(x>100 for x in timing),
                               "target30FPSMet":median<=33.34,
                               "limitation":"Cloud headless software rendering, not physical presentation laptop; cannot establish laptop performance."}
        await page.set_viewport_size({"width":390,"height":844})
        await shot('17_mobile_390')
        check('Mobile has no horizontal overflow',await page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        check('No external runtime requests', not report['externalRequests'], report['externalRequests'])
        check('No page JavaScript exceptions', not report['pageErrors'], report['pageErrors'])
        check('No browser console errors', not report['consoleErrors'], report['consoleErrors'])
        check('No failed runtime asset requests', not report['failedRequests'], report['failedRequests'])
        await context.close()

        reduced=await browser.new_context(viewport={"width":1366,"height":768}, reduced_motion='reduce')
        reduced_page=await reduced.new_page()
        await reduced_page.goto(args.base_url,wait_until='networkidle',timeout=120000)
        await reduced_page.wait_for_function('window.__SV && window.__SV.ready',timeout=120000)
        await reduced_page.evaluate('window.__SV.pause()')
        check('Reduced motion preference detected',await reduced_page.evaluate('matchMedia("(prefers-reduced-motion: reduce)").matches'))
        await reduced_page.screenshot(path=str(output/'18_reduced_motion.png'))
        report['screenshots'].append(str((output/'18_reduced_motion.png').relative_to(ROOT)))
        await reduced.close()
        await browser.close()

        no_gl=await p.chromium.launch(executable_path=args.chromium,headless=True,args=['--no-sandbox','--disable-webgl'])
        fallback=await no_gl.new_page(viewport={"width":1366,"height":768})
        await fallback.goto(args.base_url,wait_until='networkidle',timeout=120000)
        await fallback.wait_for_timeout(1500)
        text=await fallback.locator('body').inner_text()
        check('WebGL-disabled content fallback',bool(('WebGL' in text or '3D-Darstellung' in text) and '85' in text),text[:700])
        await fallback.locator('#fallback-notes').click()
        check('WebGL-disabled speaker notes remain accessible',await fallback.locator('#details').is_visible() and '04.01' in await fallback.locator('#step-list').inner_text())
        await fallback.screenshot(path=str(output/'19_webgl_fallback.png'))
        report['screenshots'].append(str((output/'19_webgl_fallback.png').relative_to(ROOT)))
        await no_gl.close()

    report['runCompletedUTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    report['functionalPassed']=all(x['passed'] for x in report['checks'])
    report_path=ROOT/args.report
    report_path.parent.mkdir(parents=True,exist_ok=True)
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({"report":str(report_path),"checks":len(report['checks']),"passed":sum(x['passed'] for x in report['checks']),"failed":[x for x in report['checks'] if not x['passed']],"performance":report.get('performance')},ensure_ascii=False,indent=2))
    return 0 if report['functionalPassed'] else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--base-url',default='http://127.0.0.1:4173')
    parser.add_argument('--chromium',default='/usr/bin/chromium')
    parser.add_argument('--output',default='screenshots')
    parser.add_argument('--report',default='docs/browser-report.json')
    args=parser.parse_args()
    raise SystemExit(asyncio.run(run(args)))
