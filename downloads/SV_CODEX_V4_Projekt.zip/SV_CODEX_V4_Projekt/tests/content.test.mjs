import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const content = path.join(root, 'public/content');
const json = name => JSON.parse(readFileSync(path.join(content, name), 'utf8'));
// Quoted semicolon fields and literal line breaks are supported independently of app code.
function csv(text) {
  const rows = []; let row = [], field = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') { field += '"'; i++; }
      else quoted = !quoted;
    } else if (!quoted && c === ';') { row.push(field); field = ''; }
    else if (!quoted && (c === '\n' || c === '\r')) {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field); if (row.some(Boolean)) rows.push(row); row = []; field = '';
    } else field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  assert.equal(quoted, false, 'CSV must have balanced quotation marks');
  const keys = rows.shift().map(x => x.replace(/^\uFEFF/, ''));
  return rows.map(values => Object.fromEntries(keys.map((key, i) => [key, values[i] ?? ''])));
}
const sourceBytes = readFileSync(path.join(content, 'original_matrix.csv'));
const source = csv(sourceBytes.toString('utf8'));
const mapping = csv(readFileSync(path.join(content, 'content_mapping.csv'), 'utf8'));
const steps = json('steps.json');
const legacy = json('original_steps.json');
const sequences = json('sequences.json');
const manifest = json('manifest.json');
const counts = {4:8,5:8,6:11,7:12,8:13,9:16,10:17};
assert.equal(source.length, 85); assert.equal(steps.length, 85); assert.equal(mapping.length, 85);
assert.equal(new Set(steps.map(s => s.id)).size, 85);
assert.equal(createHash('sha256').update(sourceBytes).digest('hex'), manifest.sourceMatrixSHA256);
const expectedIds = [];
for (const [chapter,count] of Object.entries(counts)) {
  assert.equal(steps.filter(s => s.chapter === +chapter).length, count);
  for (let n=1;n<=count;n++) expectedIds.push(`${chapter.padStart(2,'0')}.${String(n).padStart(2,'0')}`);
}
assert.deepEqual(steps.map(s=>s.id),expectedIds);
const statusSet = new Set(['IST','umgesetzt','geplant','SOLL','offen','Modellierung']);
const assigned = sequences.flatMap(s => s.stepIds);
assert.equal(assigned.length,85); assert.equal(new Set(assigned).size,85);
assert.deepEqual([...assigned].sort(), [...expectedIds].sort());
for (const s of steps) {
  const id = s.id;
  const row = source.find(r => +r.Kapitel === s.chapter && +r.Quellschritt === s.sourceStep);
  const mapped = mapping.find(r => r['Original-ID'] === id);
  const old = legacy.find(x => x.id === id);
  assert.ok(row && mapped && old, `${id}: source, legacy and mapping rows exist`);
  assert.deepEqual(s.original,row,`${id}: every original CSV field retained verbatim`);
  for (const [key,val] of Object.entries(row)) assert.equal(mapped[key],val,`${id}: mapping preserves ${key}`);
  assert.equal(s.originalNote,row.Originalnotiz,`${id}: speaker note retained`);
  assert.equal(s.originalRawText,old.rawText,`${id}: full legacy source text retained`);
  assert.equal(s.sourceNote,old.sourceNote,`${id}: legacy speaker source retained`);
  assert.ok(s.note.trim(),`${id}: readable note present`);
  assert.ok(statusSet.has(s.status),`${id}: explicit evidence status`);
  assert.equal(mapped['Neue-Sequenz-ID'],s.sequenceId);
  const seq = sequences.find(x=>x.id===s.sequenceId);
  assert.ok(seq?.stepIds.includes(id),`${id}: bidirectional sequence mapping`);
  assert.ok(s.sourcePath && existsSync(path.join(root,'public',s.sourcePath)),`${id}: actual local original source`);
  for (const src of s.sources) assert.ok(existsSync(path.join(root,'public',src.path)),`${id}: source ${src.path} exists`);
  assert.ok(!/\b(?:iKIS|ICES)\b/i.test(`${s.title} ${s.subtitle} ${s.note}`),`${id}: normalized display uses ICIS`);
}
for (const seq of sequences) {
  assert.ok(statusSet.has(seq.status),`${seq.id}: evidence status`);
  assert.ok(seq.duration > 0 && seq.duration <= 60,`${seq.id}: intentional duration`);
  assert.ok(!/\b(?:iKIS|ICES)\b/i.test(`${seq.title} ${seq.subtitle} ${seq.system}`));
}
const online = sequences.find(s=>s.id==='schaden-online');
assert.equal(online.status,'umgesetzt','Automatic online data capture is already implemented');
assert.ok(/ICIS/.test(online.system+' '+online.subtitle+' '+online.flow));
const pools = sequences.filter(s=>/pool/i.test(s.id));
assert.ok(pools.length && pools.every(s=>['geplant','offen'].includes(s.status)),'Task pool remains planned/in transition');
const portals = sequences.filter(s=>s.chapter===9 && /portal|self.service/i.test(s.id+' '+s.title+' '+s.subtitle+' '+s.flow));
assert.ok(portals.length && portals.every(s=>s.status==='SOLL'),'Cancellation self service is a proposal');
assert.ok(sequences.some(s=>s.chapter===9 && /separat|eigen|ander/i.test(s.subtitle+' '+s.title)),'Cancellation is a separate case');
console.log(JSON.stringify({passed:true,originalSteps:85,verbatimFields:680,chapters:counts,sequences:sequences.length,uniqueAssignments:assigned.length,checks:['source SHA-256','all source fields verbatim','speaker notes and legacy full text','actual local sources','ICIS normalization','status semantics','85 unique sequence mappings']},null,2));
