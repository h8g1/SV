# Räumliche Gestaltung und API

`src/world/index.js` erzeugt eine zusammenhängende Three.js-Welt. Die Architektur ist ein **schematisches funktionales Prozessmodell, kein realer SV-Grundriss**. Vier Arbeitsbereiche teilen sich eine zentrale Verkehrszone. Eingangskanal und Kundenwelt liegen am selben Miniaturstandort. ICIS, Outlook und Postkorb sind Arbeitsmittel an Monitoren und keine Zimmer.

Die Gestaltung kombiniert warme Eiche, gewebte Teppiche, salbeifarbene Akzente, anthrazitfarbenes Metall, Glas und Tageslicht. Schreibtische enthalten Tastaturen mit einzelnen Tasten, Maus, Dokumente, Lampe, Tasse und einen sauber gerahmten Monitor. Regale, Topfpflanzen, Türbeschläge, Fensterrahmen, Straßenpflaster, Bäume, Bänke und Straßenmarkierungen geben Maßstab. Monitordarstellungen sind ausdrücklich **Demonstrationen, keine echten ICIS-Oberflächen**. Pro Monitor erscheint nur das aktuell relevante System.

## Schnittstelle

```js
const world = await createWorld(scene);
world.setFocus('elias');
world.setMonitor('elias', 'ICIS', 'Antrag prüfen', 'IST', 0.5);
world.update(time, {room:'elias', system:'ICIS', title:'Antrag prüfen', status:'IST', progress:0.5});
```

`world.rooms` enthält `center`, `character`, `monitor`, `camera`, `target`, bei Arbeitsplätzen auch `systemCamera` und `systemTarget`, jeweils als Array `[x,y,z]`. Raumzentren sind Elias `[-3.3,.19,-3.4]`, Bestand `[3.3,.19,-3.4]`, Ali `[-3.3,.19,3.4]`, Kündigung `[3.3,.19,3.4]`. Kfz-Kunde steht bei `[-10,.08,4.5]`, das separat geladene Fahrzeug bei `[-12,.08,4]`. `overview` umfasst die gesamte Welt. `pickables` enthält Raumflächen und Monitore für Raycasting.

Figuren blicken standardmäßig nach +Z. Die Arbeitsplatzfigur steht/sitzt bei `center.z-.43`; dieselbe Position gilt für den Stuhl. Der Monitor ist leicht links der Figur angeordnet und seine Bildschirmseite blickt nach -Z. Arbeitsplatzkameras befinden sich schräg vor der Figur bei +Z, Systemkameras hinter ihrer Schulter bei -Z. Die Oberkante des Schreibtischs liegt auf etwa .95m Welt-Y (= Fußboden .19 + native GLB-Höhe .76). Die Sitzhöhe des lokalen Stuhls liegt bei etwa .69m Welt-Y. Tastaturzentrum x=Raumzentrum, z=Raumzentrum+.08, y≈.9775; die Figur sitzt .51m hinter der Tastatur. Monitorzentrum y=1.3175. Die Schreibpose ist damit auf Tisch, Stuhl und Tastatur abgestimmt.

## Herkunft und Grenzen

Architektur, Möbel, Pflanzen und Straßenelemente sind eigens für dieses Projekt erzeugte Geometrie. Texturen entstehen deterministisch lokal im Browser und benötigen kein Netzwerk. Beleuchtung besteht aus Hemisphere-, Sonnen- und Fülllicht; der Sonnenwurf nutzt eine 2048²-Schattenkarte. Es sind keine realen Fotos, Raumpläne oder externen HDRIs eingebaut.

Diese Architektur ist keine Behauptung eines beschafften Premium-Möbelpakets. Die tatsächlich geladenen lokalen Dateien `public/models/desk.glb` und `public/models/chair.glb` bilden Schreibtisch und Bürostuhl in allen vier Arbeitsbereichen. Sie werden einmal über den offiziellen GLTFLoader geladen und wiederverwendet. Das Original-Logo wird ausschließlich aus `/brand/sv-logo.png` auf ein kleines Fassadenschild übernommen. Separat geladene GLB-Figuren und Fahrzeuge werden vom Anwendungscode eingesetzt. Ein durch Browseraufnahmen zu beurteilender visueller Qualitätsmaßstab bleibt von der technischen Funktion getrennt.
