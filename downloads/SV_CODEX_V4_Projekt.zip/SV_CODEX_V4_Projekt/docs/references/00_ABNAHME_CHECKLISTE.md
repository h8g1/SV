# ABNAHME / TEST-PFLICHTEN – SV CODEX V4

Vor jeder Aussage „fertig“ muss eine konkrete Datei/Screenshot/Browser-Prüfung genannt werden.

## Fachliche Abnahme

- [ ] 85/85 Schritte aus CSV vollständig im Contentmodell; pro Schritt Original-Kapitel, Index, Text, Sprechernotiz, Quelle und neue Sequenz-ID
- [ ] alle fünf verbindlichen Originalquellen gelesen
- [ ] getrennte IST / bereits umgesetzt / geplant / SOLL / offen / modellierte Hypothese
- [ ] ICIS statt iKIS/ICES, keine erfundene neue Anwendung
- [ ] Online-Schaden: historische PDF-Doppeleingabe vs. bereits umgesetzte automatische ICIS-Übernahme korrekt
- [ ] Aufgabenpool: geplant/Umstellung statt flächendeckend eingeführt
- [ ] Kündigung eigenständiger Zweig und digitale Kündigung im Portal nur SOLL
- [ ] Gebäude als schematisches Organisationsmodell gekennzeichnet, keine behauptete echte Raumstruktur

## Film-/3D-Qualität

- [ ] echter WebGL-/Three.js-Rundgang, kein Video/Foto-Ersatz
- [ ] echte hochwertige, rigged Figurenmodelle Ali, Elias, Kfz-Kunde und Kündigungskundin (jeweils belegte tatsächlich verwendete Dateinamen)
- [ ] keine primitiven Kapsel-/Kugel-Gliedmaßen als finale Figuren
- [ ] echte geladene Modelldateien für hochwertiges Fahrzeug und Büroausstattung
- [ ] natürliche nachvollziehbare Interaktion: Tippen, Blick auf Bildschirm, Smartphone, Schrittbewegungen
- [ ] Bewegung in tatsächlichem Browser beurteilt, nicht nur aus Code abgeleitet
- [ ] Kamera fährt räumlich sinnvoll zwischen mindestens zwei erkennbaren Arbeitsbereichen
- [ ] Gebäudeblick, Arbeitsbereich, Detail-Systemansicht funktional verknüpft
- [ ] Übergabe manuell vs. automatisch klar und ohne Systemerfindung unterschieden
- [ ] Bild hat genug Details, aber keine dekorative Überfüllung
- [ ] fachlicher Schwerpunkt in jedem Filmbeat eindeutig

## UI und Tests

- [ ] nur 1 kurze Überschrift / höchstens 1 kurzer Satz pro Filmbeat
- [ ] nur aktive Systeme sichtbar, globaler Überblick optional
- [ ] Browser-Screenshots: 1366x768 und 1920x1080; keine Textüberlagerungen/Gesichtsverdeckung
- [ ] Start/Pause/Fortsetzen/Replay/Weiter/Zurück/Kapitelwahl/Vollbild geprüft
- [ ] Schnellnavigation ohne hängende Tween-Animationen, defekte Kamerapositionen und JS-Errors
- [ ] freie Erkundung, direkte Raumwahl und zurück zur Tour geprüft
- [ ] Browser-Testbericht mit Frames/Performance (Ziel typischerweise >=30 FPS, Testgerät nennen)
- [ ] keine externen Runtime-Netzwerkabhängigkeiten bei Offline-Präsentation (falls als Anforderung erfüllt)
- [ ] Asset-Quellen/-Lizenzen/-Attributionen dokumentiert; tatsächlich mitgeliefert

Wenn die Premium-Modelle nicht verfügbar sind: **nicht bestanden**, ehrlicher Bericht mit konkreter fehlender Modell-/Rig-/Animationsabhängigkeit, keine stille Substitution durch Primitive.
