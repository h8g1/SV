# Fachlicher Nachweis · V4

## Ergebnis und überprüfbare Dateien

`public/content/steps.json` erhält alle **85 Schritte** mit Titel, Untertitel, Sprechertext, Quellverweis und neuer Sequenz-ID. Verteilung: Kapitel 4 = 8, 5 = 8, 6 = 11, 7 = 12, 8 = 13, 9 = 16, 10 = 17. `sequences.json` bündelt sie in 25 fachliche Sequenzen; Prolog und orientierender Gebäudeblick kommen ohne zusätzliche oder doppelte Quellenzuordnung hinzu. Jeder Ausgangsschritt ist genau einer fachlichen Sequenz zugeordnet.

`public/content/content_mapping.csv` enthält sämtliche acht Originalspalten unverändert und zusätzliche Spalten für Original-ID, neue Sequenz, Notizpfad, lokale Quelle, Status und Anzeigetext. Das unveränderte Ausgangsdokument liegt als `original_matrix.csv` bei. `original_steps.json` bewahrt zusätzlich den Datenbestand des vorherigen Prototyps. Originalnotiz, alter Rohtext und alter zusätzlicher Sprechertext bleiben in jedem neuen Datensatz ausdrücklich getrennt von der normalisierten Anzeige erhalten. Das JSON-Feld `original` enthält die komplette ursprüngliche CSV-Zeile.

Prüfbefehl im Projektverzeichnis: `node src/content/verify.mjs`. Er vergleicht alle Originalspalten, sämtliche alten Rohtexte und Quellnotizen, zählt alle Kapitel und prüft die eindeutige Zuordnung und vorhandenen lokalen Quellpfade. Er prüft außerdem die fachlich entscheidenden Statuskennzeichnungen. Der Befehl überprüft Datenintegrität; er ersetzt keine fachliche Freigabe oder visuelle Browserabnahme.

## Vollständig gelesene fachliche Ausgangsquellen

Die fünf verbindlichen HTML-Dateien wurden vollständig eingelesen; die sichtbaren Inhalte und alle Titel-, Untertitel- und Notizarrays wurden ausgewertet. Die Arrays sind ohne eingebettete Bilddaten zusätzlich in `original_source_extracts.json` enthalten. Alle fünf HTMLs sowie die vier mitgelieferten abgeleiteten Präsentationsfassungen liegen unverändert unter `public/content/sources/`.

| Verbindliches Original | Umfang im Original | Verhältnis zur 85er-Matrix |
| --- | ---: | --- |
| `04-06_Elias_Antrag_Bestand.html` | 27 Schritte | Kapitel 4–6, 8 + 8 + 11; ältere Schreibweise iKIS |
| `07_Schadenmeldung.html` | 9 Schritte | Früheres Untersuchungsmodell; spätere abgeleitete Fassung/Matrix enthält 12 Schritte und Ali-Interview |
| `08_Schadenbearbeitung.html` | 9 Schritte | Früheres Untersuchungsmodell; spätere abgeleitete Fassung/Matrix enthält 13 Schritte und Poolvergleich |
| `09_Kuendigung.html` | 10 Schritte | Spätere abgeleitete Fassung/Matrix enthält 16 Schritte und zusätzliche Interviewbefunde |
| `10_Fazit.html` | 10 Schritte | Spätere abgeleitete Fassung/Matrix enthält 17 Schritte mit fortgeschriebener Auswertung |

Die 85er-Matrix benennt den Elias-Titel `Elias_Gesamtpraesentation_Teil_4-6_v10_ohne_neue_Animationen.html`. Eine Datei exakt dieses Namens liegt im Paket nicht vor. Die mitgelieferte verbindliche Elias-Datei trägt im Titel eine ältere Versionsangabe und besitzt dieselben 27 Titel/inhaltlichen Grundschritte. Der ursprüngliche Dateiverweis bleibt unverändert erhalten; `sourcePath` verweist transparent auf die tatsächlich mitgelieferte Datei. Das ist eine dokumentierte Herkunftslücke und keine Behauptung identischer Dateiversionen.

Die vier abgeleiteten HTMLs wurden zusätzlich über ihre `data-name`- und `data-note`-Attribute vollständig gegen die Matrix verglichen: **58/58 Titel und Sprechertexte stimmen exakt überein** (12 + 13 + 16 + 17). Der ausgelesene Vergleichsbestand liegt in `derived_source_extracts.json`.

## Konflikte und vorsichtige Fortschreibung

Die frühen Schaden-Originale nennen unter anderem ein Wasserbeispiel und erklären zahlreiche Details noch für unerhoben. Die spätere Matrix und die abgeleiteten Fassungen dokumentieren das ergänzte Ali-Interview und ein Kfz-Kaskobeispiel. Die neue Inszenierung verwendet dieses spätere exemplarische Kfz-Ereignis, ohne eine Deckung oder universelle Dokumentenpflicht zu behaupten. Die frühen Zweifel werden als historische Originalquellen erhalten. Sie werden nicht als aktueller Stand über die spätere Evidenz gelegt.

Der Nutzer hat die Schreibweise **ICIS** ausdrücklich vorgegeben. Anzeige, Sprechertexte und Systemdarstellung verwenden sie einheitlich. Die abweichenden Originalformen bleiben ausschließlich in unverändert gekennzeichneten Quelldaten erhalten. Zwei alte Elias-Notizen, die aus der damals ungeklärten Schreibweise zwei womöglich verschiedene Produkte ableiteten, erhalten eine explizit dokumentierte Anzeigekorrektur. Daraus wird keine technische Gleichheit bislang unbestätigter Schnittstellen abgeleitet.

Die Statuswerte sind als Hauptkennzeichnung zu verstehen; ein einzelner Schritt kann daneben offene technische Details enthalten. Diese bleiben im Sprechertext und `evidenceNotes` sichtbar. **IST** bedeutet im Projektinterview berichtet oder öffentlich belegt, nicht durch unabhängigen technischen Audit bestätigt. **Umgesetzt** hebt insbesondere die aktuelle automatische Übernahme der Online-Schadenformulardaten hervor. **Geplant** kennzeichnet Aufgabenpool/Umstellung. **SOLL** kennzeichnet Vorschläge. **Offen** kennzeichnet ungeklärte Technik oder Einführung. **Modellierung** beschreibt die inszenierte Prozesswelt.

## Übernahme aus den beiden Konzept-HTMLs

**A – V3 Rundgang:** ausgewertet wurden die elf Hauptszenen, die zusätzliche 23-Stationen-Datensammlung sowie die Kamerapositionen und Interaktionen. Übernommen werden die Logik von Gebäudeübersicht, Arbeitsplatz, Monitoransicht, Replay, Notizen und freier Erkundung. Die elf Hauptszenen sind kein Ersatz für die 85 Quellschritte. Die alten Kugelfiguren und eingeblendeten Kartensammlungen sind keine Qualitätsreferenz.

**B – Systemlandschaft/Raumstruktur:** ausgewertet wurden Rollen/Räume (`ad`, `vis`, `ts`, `pol`, `fb`, `ksr`, `sa`, `sb`, `kb`, `scan`), Systeme, externe Akteure und die Flussdefinitionen. Verwendet wird die fachliche Trennung von Kundenkontakt, Dokumenteneingang, Fachrolle, Arbeitsmittel und technischem Kontext. Die Darstellung übernimmt keine angeblich echten SV-Raumpositionen, unbestätigten Teamnamen oder Systemräume. Nick und seine ungeklärten Außendienstsysteme werden jetzt nicht ausgebaut.

| Neue Prozesswelt | Fachlicher Bezug aus B | Arbeitsmittel / Grenze |
| --- | --- | --- |
| Kundenwelt außerhalb | Kunde / Meldekanäle | Smartphone und Onlineformular; gleicher Kfz-Kunde in Prolog und Kapitel 7 |
| Eingang | Scan, Inputmanagement | Prozess-/Infrastrukturstation, keine behauptete echte Abteilung |
| Elias / Fachprüfung | TS als Interviewkürzel, Langname offen | ICIS, Postkorb; Outlook bei belegter Rückfrage |
| Bestand / Policierung | `pol`, `fb`, Standardanliegen | ICIS; technische Policierung und Zustellung offen |
| Ali / Schadenbearbeitung | `sa`, `sb` als Fachrollen | ICIS und Postkorb; offizielle Abteilungsnamen offen |
| Kündigung / Korrespondenz | `kb`, KSR, Scan | Eigener Vertragszweig; Textsystemname im Ali-Kontext offen |
| Expertenansicht | System-/Prozesslandkarte | Fachliche Beziehungen, keine erfundenen APIs oder realen Grundrisse |

`process-map.json` liefert eine auf Nachfrage verwendbare System- und Flussliste mit Einzelfallgrenzen und Quellschritt-IDs. Eine fachliche Übergabe ist dort ausdrücklich nicht gleichbedeutend mit einer technisch bestätigten automatischen Schnittstelle.

## Fachliche Grenzen, die weiterhin gelten

- Online-Schaden: früher PDF und manuelles Abschreiben; inzwischen automatische Übernahme nach ICIS laut Ali. Diese Verbesserung gilt nicht pauschal für freie E-Mails, Briefe oder jeden Meldekanal.
- Aufgabenpool: geplant beziehungsweise in Umstellung, Einführungsstand offen; keine behauptete gemessene Zeitersparnis.
- Schadenentscheidung, Freigaben, Auszahlung, Ablage und technischer Abschluss: nicht ausreichend erhoben. Die Inszenierung darf hierzu keine echte Maske oder verpflichtenden SV-Entscheidungsbaum behaupten.
- Kündigung: eigenständiger Vertragsweg mit anderer Kundin. Ein Schaden führt nicht automatisch zur Kündigung. Interviewaussagen zu Kanälen sind keine allgemeine Rechtsauskunft.
- Scan/OCR: in späterer Interviewauswertung genannt; genaue Reihenfolge und technische Umsetzung offen. KSR-Langform und abschließende Zuständigkeit sind nicht bestätigt.
- Individuelle Korrespondenz: M-Text bei Elias genannt, Produktbezeichnung im Ali-Kontext widersprüchlich. Ein Programmwechsel beweist keine Doppeleingabe.
- Digitales Kündigungsportal: SOLL-Vorschlag, keine bestätigte aktuelle Standardfunktion.
- SAP/DWH und BiPRO/GDV: nur dokumentierter Kontext; keine erfundenen internen Datenleitungen. Keine realen SV-Grundrisse, Dauerwerte, Kosten oder Effizienzkennzahlen.
