# Modelle, Herkunft und tatsächlicher Qualitätsstand

Die vier Charaktere sind **neu erzeugte, prozedural modellierte 3D-Näherungen**. Sie sind keine importierten Premium-Charaktere und **erfüllen das visuelle Charakter-Qualitätsgate des V4-Auftrags nicht**. Insbesondere Gesichtsmodellierung, Haarvolumen, Stoffoberflächen, Hauttexturen und natürliche Gestik erreichen die mitgelieferten Referenzporträts nicht. Ein funktionierendes Rig oder eine fehlerfreie GLB-Datei beweist keine gestalterische Abnahme.

| Datei | Verbindliche Referenz | Tatsächlich enthalten |
|---|---|---|
| `public/models/elias.glb` | 01 Mitarbeiter Antrag/Bestand | Dunkler Anzug, Hemdkragen, modellierte Revers, rote Krawatte, braunes Haar, Gesicht, Hände mit Einzelfingern |
| `public/models/ali.glb` | 02 Mitarbeiter Schadenbearbeitung | Dunkler Pullover, Hemdeinsatz/Kragen, Brille, eigenes wiederverwendetes Charaktermodell |
| `public/models/customer.glb` | 05 Kunde Kfz-Schaden | Olivfarbenes Oberteil, Jeans, dezenter Bart, Smartphone als mitbewegtes Handobjekt |
| `public/models/cancellation.glb` | 09 Kündigung/Vertragsänderung | Terrakotta-Cardigan, silberhelles Bob-Haar, Brille; eigenständige Kundin |

Alle vier Dateien enthalten einen tatsächlichen Skin mit **18 Deformationsgelenken**, eine verbundene Mesh-Dateistruktur mit 12–14 Materialprimitiven und die vier tatsächlichen Clips `idle`, `work`, `phone`, `walk`. Die Clips wurden durch Bone-Keyframes erstellt, nicht durch das Bewegen eines Charakterbildes. Körper und Kleidung wurden aus geschlossenen geglätteten Ringflächen mit geformten Querschnitten erstellt, Gesichtszüge und Finger als eigene Geometrie. Die Körper sind keine fertigen Kugel-/Zylinder-Platzhalter und keine 2D-Flächen. Gleichwohl ersetzt die prozedurale Näherung kein professionelles Character-Sculpting. Die einzelnen Oberflächen sind nicht durchgehend anatomisch verschweißt; keine Blendshapes oder lippensynchrone Mimik vorhanden.

Koordinaten nach glTF-Export: Y oben, Vorderseite +Z, Füße auf Y=0, stehende Höhe ca. 1,87 m. `work` stellt eine sitzende Arbeitspose mit Hüftabsenkung um 0,42 m bereit; Arbeitsplatz/Stuhl müssen zu dieser Position gesetzt werden. `phone` hebt die Hand mit Smartphone weich von Hüft- zu Brusthöhe, hält kurz und senkt sie wieder. Nach der tatsächlichen Browser-Sichtkontrolle wurden vier gekrümmte Greiffinger samt gegenüberliegendem Daumen modelliert und eine Weltorientierungs-Kompensation am Handgelenk eingebaut: Das Telefon bleibt hochkant, Display zum Kunden und rückwärtige Kamera nach außen. Ein fein animiertes Fingerrig und präzise fotografische Zielausrichtung benötigen weiterhin manuelle Animationsnachbearbeitung. `walk` ist ein stationärer Gehzyklus, keine Root-Motion-Strecke. Die kurzen Idle-/Arbeitszyklen sind bewusst ruhig, aber nicht Motion-Capture-Qualität.

## Herkunft und Nutzungsbasis

Geometrie, Rig, Animationen und PBR-Farbmaterialien wurden für dieses Projekt mit `tools/create_assets.py` in Blender 4.3.2 erstellt. Keine fremden Modellbibliotheken, keine übernommenen Rig-/Animationsdateien, keine externen Texturdownloads. Der Generator und die erzeugten GLBs werden vollständig mitgeliefert. Es bestehen daher keine zusätzlichen Drittanbieter-Attributionspflichten für diese neu erzeugte Geometrie. Die vom Nutzer gelieferten Charakterbilder dienen nur als Rollen-/Stilreferenz und werden nicht als vermeintliche 3D-Figuren auf Planes gerendert. Das SV-Original-Logo stammt unverändert aus dem gelieferten Paket; es wird nicht nachgezeichnet. Markenrechte verbleiben beim Rechteinhaber.

Die Modelle der Fahrzeuge und Büromöbel und deren Grenzen sind in `docs/PROPS.md` dokumentiert.

## Tatsächlich geprüfte verfügbare Alternativen

Am 28.10.2026 wurden über die vorhandene HTTPS-Verbindung **die tatsächlichen offiziellen Three.js-Beispiel-GLBs** temporär heruntergeladen und ihre JSON-Metadaten ausgelesen. Die Dateien sind nicht Bestandteil der Auslieferung und werden nicht in der Anwendung geladen.

| Alternative / offizielle Quelle | Tatsächliche Prüfung | Warum nicht übernommen |
|---|---|---|
| [Soldier.glb](https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/models/gltf/Soldier.glb), [Beispiel mit Herkunftsangabe](https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/webgl_animation_skinning_blending.html) | GLB eingelesen: zwei Skins, Meshes `vanguard_Mesh` / `vanguard_visor`; Clips `Idle`, `Run`, `TPose`, `Walk`. In Blender tatsächlich importiert und gerendert. Das offizielle Beispiel nennt Mixamo als Modellquelle. | Sichtprüfung zeigt einen vollständig gepanzerten Science-Fiction-Soldaten mit Helm/Visier. Er kann Elias, Ali oder die Kunden weder in Gesicht noch Kleidung vertreten. Keine Arbeitsplatz- oder Smartphoneanimation enthalten. Aus der allgemeinen Three.js-Code-Lizenz wurde ausdrücklich keine pauschale Freigabe dieses Fremdmodells abgeleitet; keine zusätzliche Modelldistribution vorgenommen. |
| [RobotExpressive.glb](https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/models/gltf/RobotExpressive/RobotExpressive.glb), [offizielles Modell-README](https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/models/gltf/RobotExpressive/README.md) | GLB eingelesen: zwei Skins und 14 Clips (`Dance`, `Death`, `Idle`, `Jump`, `No`, `Punch`, `Running`, `Sitting`, `Standing`, `ThumbsUp`, `Walking`, `WalkJump`, `Wave`, `Yes`). README tatsächlich gelesen: Tomás Laulhé/Quaternius, **CC0 1.0**, Modifikationen Don McCurdy (Morph Targets, Konvertierung, Materialbereinigung). | Lizenz nutzbar und Animationen vorhanden, aber Roboterstil statt der ausdrücklich geforderten menschlichen Rollen. Keine tatsächliche Tipp-/Fotografierhandlung; damit kein geeigneter Ersatz für die vier Charakterreferenzen. |

SHA-256 der tatsächlich geprüften GLBs: Soldier `dfb230fc1f942f259dd00281a1186953ad602fc5d69067ce63e24b2aa439736b`; RobotExpressive `047f5e5fb3bb6d378bd1df16ca6137f2a596c99b3a1b5690b4020c05aaf6f319`. Diese Alternativprüfung belegt verfügbare technische Rigs, **keine** Verfügbarkeit passender hochwertiger menschlicher Modelle mit den vier erforderlichen Identitäten. Die im Projekt verwendeten eigenen Näherungen bleiben daher ausdrücklich unter dem visuellen Abnahmeziel.

## Reproduktion und Prüfung

Vom Projektverzeichnis: `blender -b -t 2 --python tools/create_assets.py`. Der Generator benötigt nur Blender samt eingebautem glTF-Exporter. Er überschreibt ausschließlich seine vier erzeugten Charakter-GLBs. Der glTF-Export enthält lokale Daten ohne externe Runtime-URLs.

Die GLB-Header und JSON-Chunks wurden tatsächlich eingelesen: alle vier Dateien weisen genau einen Skin mit 18 Joints und die vier oben genannten Clips auf. Zusammengefügte Meshes reduzieren die Anzahl der Draw Calls gegenüber separaten Gesichtsteilen. Ein zusätzlicher Blender-Roundtrip und ein Render von Elias dienten zur Sichtkontrolle der Geometrie; **dieser Render ist kein Browser-Screenshot und kein Nachweis für das Bestehen des Qualitätsgates**. Die Browsernachweise liegen separat im Testbericht/Screenshotverzeichnis.

## Genauer offener Asset-Bedarf

1. Vier professionell modellierte, zueinander stilistisch passende, rechtlich nutzbare Character-GLBs in der Ästhetik der Referenzen 01/02/05/09, mit anatomisch sauberer Topologie, UVs, Haut-/Haar-/Stofftexturen und kontrollierten LODs.
2. Hautning-/Rig-Nachbearbeitung mit Finger-/Gesichtsrig, Sitzkontakt und Foot-/Hand-IK für Schreibtisch, Tastatur und Smartphone.
3. Natürlich animierte Clips für Blick zum Monitor, Tippen, präzises Greifen und Fotografieren mit dem Telefon, Hinsetzen/Aufstehen und Gehen, inklusive Übergängen; Animationen müssen zur konkreten Körperproportion passen.
4. Künstlerische Abnahme in beiden geforderten Browserauflösungen mit direktem Vergleich zu den Nutzerreferenzen. Ohne diese Arbeiten bleibt das visuelle Charaktergate offen bzw. nicht bestanden. Die Anwendung darf daher als technisch ausführbar, nicht als vollständig visuell abgenommen bezeichnet werden.
