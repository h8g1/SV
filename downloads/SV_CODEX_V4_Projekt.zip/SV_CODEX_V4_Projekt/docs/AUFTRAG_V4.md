# SV SPARKASSENVERSICHERUNG – CODEX MASTER-AUFTRAG V4
## Cinematic 3D Customer Journey: räumlich verständlich, hochwertig animiert, clean, fachlich vollständig

**Projekt:** DHBW · Customer Journey im Versicherungsvertrieb
**Umfang:** vorerst Elias (Kapitel 4–6) und Ali (Kapitel 7–9) sowie gemeinsames Fazit (Kapitel 10); Nick erst später.
**Zielmedium:** **lauffähige interaktive HTML-/WebGL-Anwendung**, die sich wie ein hochwertiger Mini-Animationsfilm anfühlt. **Kein Video als Ersatz, keine Folien-Slideshow.**

## 0. Lies dies zuerst: Welche Vorlage wofür?

Im Paket findest du zwei unterschiedliche, bewusst **nicht 1:1 zu kopierende** Architekturvorlagen:

- `01_KONZEPT_REFERENZEN/A_V3_Rundgang_3D.html`: **Hauptreferenz für Erlebnis und Ablauf**. Übernimm die Idee des geführten 3D-Rundgangs, der Stationsnavigation, der Kamera- und Monitorperspektive, des Gebäudebezugs, der interaktiven Erkundung und der Prozesshandlungen. **Nicht** das bisherige primitive Modell-, Animations- und Layoutniveau.
- `01_KONZEPT_REFERENZEN/B_Systemlandschaft_und_Raumstruktur.html`: **Hauptreferenz für Fachstruktur und räumliche Systemlogik**. Extrahiere Arbeitsbereiche/Fachrollen, Kundenkontaktpunkte, Anwendungen, Datenflüsse, Medienbrüche, Zustandskennzeichnungen, zusätzliche System-/Prozesslandkarten und Quellenbezüge. **Nicht** die visuelle Überladung oder eine behauptete echte SV-Gebäudestruktur.
- `02_FACHQUELLEN/01_Verbindliche_Originale`: die ursprünglich untersuchten HTML-Quellen für Kapitel 4–10. Fachliche Ausgangsbasis.
- `02_FACHQUELLEN/02_Abgeleitete_Praesentationsversionen`: ausführlich gestaltete Quellfassungen, auf die sich die beigefügte 85-Zeilen-Quellenmatrix namentlich bezieht. Diese Fassungen zum Abgleich von Vortragstexten und Quellschritten verwenden. Bei Abweichungen anhand der Originale/Interviews überprüfen; Unklarheiten ausweisen.
- `03_ALTER_TECHNISCHER_STAND`: früheres Qualitätsgate mit ausführbarer Technik, 85-Schritte-Altbestand und Browseraufnahmen. **Nur als Code-/Datenbasis und Negativbeispiel**. Es fehlen hochwertige Figuren; das bisherige Fahrzeug/Material-/Bürodesign ist NICHT abgenommen.
- `04_CHARAKTERE_UND_BRANDING`: neun einzeln benannte visuelle Figurenreferenzen, Kollage, Rollenverteilung und SV-Originalgrafik. **Bilder sind keine geriggten 3D-Modelle.**
- `05_QUELLENMATRIX_UND_PLANUNG`: 85 Zeilen mit Originalinhalt sowie vorhandenes Storyboard; Prüf- und Strukturhinweise.
- `06_INTERVIEW_MATERIAL`: ergänzende Materialien zu Ali. Nur tatsächlich gestützte Aussagen übernehmen; Interviewunsicherheiten nicht zu Gewissheiten umschreiben.

**Vorrang bei Konflikten:** dokumentierte fachliche Evidenz > alte Präsentationsannahme > kreative Ausgestaltung. Für die visuelle Neukonzeption gilt dieser neue V4-Auftrag vorrangig vor älteren Work-/V2-Prompts.

## 1. WIR WOLLEN EINE NEUE QUALITÄTSSTUFE – NICHT V3 MIT ANDEREN FARBEN

Ich möchte die bestehende Grundidee **deutlich transformiert** sehen:

1. Eine zusammenhängende, wunderschön gestaltete **3D-Miniatur-/Animationsfilmwelt** mit Außenbereich, Gebäude, unterschiedlichen Arbeitsräumen, plausiblen Wegen und hochwertigen Ausstattungselementen.
2. **Echte animierte Figuren** im Stil meiner neun Referenzen (leicht realistische, freundliche 3D-Cartoonästhetik): korrekte Körperproportionen, zusammenhängende Geometrie, Haare, Kleidung, glaubwürdige Hände/Finger, Mimik und Bewegungen.
3. Eine **Kamerareise mit räumlich nachvollziehbaren Übergängen**: Vogelperspektive → Gebäude/Cutaway → Arbeitsplatz → Monitor/aktiver Vorgang → nächster Prozessort. Nicht eine Reihe unverbundener Szenen, die nur hart wechseln.
4. **Verständliche IT-Systemlandschaft:** sichtbar wird immer nur das System, der Arbeitsbereich und der Datenfluss, den der Zuschauer gerade verstehen muss. Komplexe Gesamtübersicht nur auf Wunsch.
5. **Cleanes UI**: große freie Bildfläche, sehr wenige Worte, ruhige Gestaltung, viel negative space, dezentes SV-Rot, Original-Logo, typografische Hierarchie. Keine riesigen Überschriften über Gesichtern, keine permanente Seitenleiste voller Text, keine zehn Systemlabels auf einmal.
6. **Filmische Animation in Echtzeit-WebGL**, nicht statische Hintergründe, 2D-Pappfiguren, gerenderte Videos oder Fotos auf Flächen als vermeintlich fertige 3D-Szenen.

Der Maßstab ist nicht „läuft ohne JavaScript-Fehler“, sondern **sieht visuell erkennbar nach einer sorgfältig art-directed Animationsfilm-Web-App aus**. Falls High-End-Assets mit den verfügbaren Werkzeugen nicht beschafft/erstellt werden können, melde den exakten Blocker. Behaupte keine hochwertige Figur, wenn nur ein Platzhalter eingebaut ist.

## 2. ERST DESIGN UND RAUMLOGIK, DANN MODELLE UND MOTION

Erstelle aus beiden HTML-Referenzen eine **gestalterisch NEU aufgebaute, aber fachlich rückverfolgbare** System-/Raumarchitektur.

Räumliche Bereiche als **schematische, funktionale Prozesswelt** (niemals als realer SV-Grundriss behaupten):

- Kundenwelt / beispielhafte Kfz-Schadensituation außerhalb des SV-Gebäudes
- Eingangskanal / Eingangspost, digitale Meldung, Scanstrecke (jeweils ein Prozess-/Infrastrukturbereich, nicht zwingend ein als echte Abteilung belegter Raum)
- Elias: Antragseingang und Fachprüfung
- Elias: Policierung / Bestandsverwaltung / Vertragsänderungen
- Ali: Schadenannahme bzw. Übergabe
- Ali: Schadenbearbeitung und Abschluss
- Kündigung/Korrespondenz inklusive KSR nur soweit die Quellen die Rolle tragen
- Übergreifende Systemebene als **digitale Ebene / Expertenansicht**, nicht als riesiges physisches Büro oder Raum für „ICIS“

Entwirf für die Nutzerführung eine zusammenhängende Gebäudewelt: elegant unterscheidbare Bürobereiche, Flure, Fenster, Türen/Glaswände, Material- und Lichtkonzept. Durch Cutaway-Kamera oder vorübergehende Wandtransparenz kann die Kamera Räume ungehindert zeigen. Eine schöne, räumlich klare Architektur ist wichtiger als ein riesiger komplizierter Grundriss. Nutze keine künstlich exakt wirkenden Team-/Abteilungsbezeichnungen ohne fachlichen Beleg.

**Systeme sind Arbeitsmittel, keine Gebäude:** ICIS erscheint an einem relevanten Bildschirm; Outlook/Office bei der Kommunikation; elektronischer Postkorb bei Dokumentation/Verteilung; Onlineformular bei der Kundin/dem Kunden; Scan/OCR als Eingangsschritt; weitere Systeme nur wenn in Quellen belegt und aktuell relevant. Sind Namen, Anschlüsse oder die Wirkweise unsicher, sichtbar mit „schematisch/zu prüfen“ kennzeichnen statt automatisch-technische Schnittstellen zu erfinden.

## 3. FILMISCHER AUFBAU MIT KLARER STORY

### Prolog (Atmosphäre statt Effektspektakel)

Beginne oben im Himmel: dezent rötliche, glaubwürdig wolkige Gewitterstimmung, einzelne zurückhaltende Blitze. Die Kamera sinkt weich in eine hochwertige kleine Stadt mit Bäumen, Gebäuden und Verkehr. Sie findet ein beschädigtes Auto. Der Kunde (Ref. 05) steigt nicht künstlich aus einem Berichtsheft heraus, sondern sieht sich den Schaden an, nimmt sein Handy, fotografiert und beginnt eine **realistisch anmutende digitale Schadenmeldung**. Nur kurz zeigen, dass ein Vorgang entsteht. Danach dramaturgisch sauber: **„Rückblick: Der Vertrag wird bearbeitet“** – Einstieg bei Elias. Später kehrt die Geschichte zum Schaden zurück. Keine falsche fachliche Reihenfolge suggerieren.

### Elias / Kapitel 4–6

Antrag trifft digital/manuell entsprechend der Quelle ein → sorgfältiger Kameraflug in Elias’ Raum → Antrag prüfen → **systemgestützter Standardfall vs. fachlicher Klärfall als nachvollziehbare Verzweigung** → im Klärfall Outlook/Rückfrage/Postkorb und Wartezeit verständlich zeigen → Policierung und Bestand/Änderungen → kurze, kontextuelle Systemübergaben. Keine falsche Behauptung, jeder Antrag werde exakt gleich behandelt.

### Ali / Kapitel 7–8

Wieder zum Unfall und zur Kundensituation → Schadenmeldung über konkreten gewählten Kanal → **bereits implementierte automatische Onlineformular-Datenübernahme nach ICIS** hervorheben (nicht den früheren PDF-Abtipp-Medienbruch als aktuellen Ablauf zeigen) → Übergabe zum passenden Schadenarbeitsplatz → Deckungsprüfung, Unterlagen, eventuell weitere Klärung und Abschluss. Die **geplante/im Wandel befindliche Aufgabenpool-Bearbeitung** deutlich vom IST absetzen.

### Ali / Kapitel 9

**Separater Abzweig** vom Vertragsbestand zur Kündigung: Kündigungswunsch einer anderen Kundin (Ref. 09) → Eingang per Brief/E-Mail → Scan-/Postkorb-/KSR-/ICIS-Bearbeitung nur in belegter, quellensicherer Tiefe → mögliche Sonderfälle, z. B. Sicherungsgläubiger bei entsprechend betroffener Gebäudeversicherung → Korrespondenz/Bestätigung. Digitales Kundenportal für Kündigung ist **SOLL/Vorschlag, keine real vorhandene Standardfunktion**. Schaden führt nicht automatisch zur Kündigung.

### Kapitel 10 / Fazit

Ruhiger Kamera-Rückflug: ausgewählte Teile des Gebäudes werden sichtbar, während die wesentlichen Prozesswege **nacheinander** aufleuchten (kein Netz aus 30 Linien). Fasse übergreifende Schnittstellen, bereits umgesetzte Verbesserung, offene Fragen und Verbesserungsoptionen klar getrennt zusammen.

**Der Film muss nicht 85 überlange Einzelszenen enthalten.** Bündele fachlich passende Originalschritte in sinnvoll inszenierte Filmsequenzen; stelle dennoch **alle 85 Ausgangsschritte** einschließlich Sprechernotizen, Quellenbezügen und Status vollständig über optionale Kapitel-/Detailansichten bereit. Stelle eine maschinenlesbare 1:1-Mappingtabelle her: Original-Kapitel + Schritt → Filmsequenz → Notiz/Quelle.

## 4. DAS IST MIR AM WICHTIGSTEN: SAUBERE ANIMIERTE RAUMWECHSEL

Die räumliche Reise soll immer einen **Ursache-Wirkung-Faden** haben:

1. In Nah-/Halbtotalen sieht man den Mitarbeiter und genau **eine** Tätigkeit.
2. Die Kamera geht bei Bedarf auf den Bildschirm oder ein Dokument. Der relevante Systemname erscheint klein.
3. Die Übergabe wird durch **einen** dezenteren visuellen Informationsimpuls/Übertragungsweg erklärt: nur der aktuell aktive Pfad, eindeutig manuell oder automatisch gekennzeichnet.
4. Die Kamera löst sich vom Arbeitsplatz, fährt ruhig durch den Raum oder zoomt kontrolliert in eine architektonische Übersicht.
5. Der neue Arbeitsbereich wird kurz als räumliches Ziel hervorgehoben; dann Zoom/Fahrt in den nächsten Raum.
6. Das vorige Overlay verschwindet; im neuen Raum beginnt die nächste Handlung. Die Welt bleibt stilistisch, geometrisch und erzählerisch konsistent.

Keine harten Teleports als Standard. Keine zufälligen Orbit-Kameras, keine extremen Fisheye-Perspektiven und keine permanent schwebenden Datenpakete. Bei physisch nicht sinnvoll verbundenen Schauplätzen (Kunde draußen ↔ internes Büro) einen motivierten Match Cut / Zoom-out-and-in / dezenten Übergang verwenden; **nicht** ein imaginäres IT-Kabel oder einen direkten Systemtransfer vortäuschen. Definiere Cinematic Camera-Rigs, Kamerapfade mit easing, look-at Targets, Occlusion-Fades, sanfte Szenenübergänge und eine nachvollziehbare räumliche Orientierung.

**Die Übergänge sind funktional:** Nach jedem Wechsel muss der Betrachter beantworten können, woher der Vorgang kommt, wer ihn gerade bearbeitet und wohin er geht. Baue eine sehr kleine und ausblendbare Weganzeige ein (z. B. `Antrag → Fachprüfung → Bestand`), keine permanente globale Datenfluss-Wolke.

## 5. DREI SICHTEBENEN, ZWEI NUTZUNGSMODI

**Sichtebenen**

A. **Gebäudeübersicht / Orientierung**: liebevoll gestaltete isometrische Cutaway-Perspektive, wenige anklickbare Bereiche, jeweils nur aktueller Bereich hervorgehoben. Optional aufklappbare Karte, kein textbasiertes Wimmelbild.

B. **Filmszene / Arbeitsplatz**: primärer Präsentationsmodus. Gute 3D-Figur im Vordergrund, hochwertiger Raum im Hintergrund, konkrete Handlung, ruhiger Kameraweg.

C. **System-/Prozessdetail**: Zoom zu einem 3D-Monitor/Schreibtisch/Smartphone, dort abstrahierte und erkennbar als Demonstration deklarierte UI; nicht behaupten, die Darstellung sei ein tatsächlicher ICIS-Screenshot. Gegebenenfalls darüber ein dezentes 2D-Overlay für lesbare Abläufe. Globale System-/Prozesslandkarte als **optionale Expertenansicht**, im Film niemals gleichzeitig vollständig eingeblendet.

**Nutzungsmodi**

1. **Geführte Tour:** Play/Pause, Vor/Zurück, Szene erneut, Kapitelwahl, Vollbild, Notizen, steuerbarer Rhythmus; während Vorträgen deterministisch und nicht ruckelig.
2. **Freie Erkundung:** Gebäudeübersicht mit anklickbaren Stationen, sanfte Kamerafahrt zu einem Raum, sichtbarer Weg zurück, relevante System-/Dateninformationen per Klick. Gleiche Welt und gleiche Inhaltsdaten wie in der Tour.

## 6. FIGUREN, OBJEKTE, GESTALTUNG – HOCHWERTIG STATT KINDERBAUKASTEN

Die neun Bildern aus `04_CHARAKTERE_UND_BRANDING/Einzelbilder` sind verbindliche **Style- und Rollenreferenzen**:

- `01` Elias (Hauptfigur, Antrag/Bestand; dunkler Anzug/rote Krawatte)
- `02` Ali (Schadenbearbeitung; Brille, dunkler Pullover)
- `05` Kunde bei Kfz-Schaden, **dieselbe Figur bei Prolog und Schadenmeldung**
- `09` Kündigungskundin als **separater** Fall
- `03, 04, 06, 07, 08` nur in fachlich passender Handlung

Beschaffe oder erstelle echte 3D-Assets mit überprüfbarer Lizenz: hochwertige **skinned/rigged** GLB/glTF-Charaktere, passende Clips (Gehen, Sitzen, Telefonieren, Tippen, Handyheben), Mimik soweit umsetzbar, hochwertige Fahrzeuge, Büromöbel, Computer, Architektur, Straßen- und Pflanzenobjekte. Identität der Figuren über Kapitel hinweg konstant halten. Ein Bild auf einer Plane ist kein Character-Asset. Ein aus Kugeln/Zylindern generierter Mensch ist nicht akzeptiert. Eine Figur ohne sichtbare tatsächliche Interaktion gilt nicht als animiert.

Nutze vorhandene, moderne Three.js-/WebGL-Technik mit offiziellem GLTFLoader, AnimationMixer, skinned meshes, PBR, korrekter Licht-/Farbdarstellung, texturierten Materialien und sinnvollen Schatten. Verwende ggf. Blender für Modellanpassungen, falls tatsächlich verfügbar. Wenn hochwertige Figuren und Animationen ohne spezialisierte externe Assets nicht realisierbar sind, **zeige die Grenze explizit** und liefere einen konkreten Asset-Bedarfsplan statt die vorhandenen Spielzeugfiguren als abgenommen zu präsentieren.

Ergänze abwechslungsreiche **relevante** Objekte: Schreibtischlampen, Pflanzen, Regale, Bildschirme, Stühle, Tastatur, Kaffebecher, Türen, Glasflächen, Fenster mit Aussicht, Aktenablagen, glaubwürdige Straßenmarkierungen, Bäume, Autos, dezente Stadtmöbel. Mehr Details, aber selektiv – nicht mehr visuelles Chaos. In Filmkamera-Einstellungen sollen Dekorationen nie die fachliche Handlung verdecken.

**Original-SV-Logo** aus Paket verwenden. Nicht von der KI nachzeichnen lassen, keine kaputten Buchstaben/Logos auf Texturen. Keine unzulässige Nutzung fremder Assets; Quellen/Lizenzen im Paket dokumentieren, keine Fremd-URLs als vermeintlich integrierte Dateien ausgeben.

## 7. CLEANES UI UND BEWEGUNGSRUHE

- Im filmischen Bild **höchstens eine kurze Überschrift und eine kurze Erläuterung**; maximal zwei Systemlabels gleichzeitig, wenn es tatsächlich nötig ist. Weitere Inhalte ausschließlich über Klick/Notizen.
- Controls klein und hochwertig; nur bei Interaktion bzw. am Rand sichtbar, die Hauptaktion nie verdecken.
- Dezente weiße/off-white Flächen, anthrazitfarbene Schrift, sehr sparsames SV-Rot als Akzent; kein dauerhaftes graues, ausgewaschenes Rendering.
- Auch bei 1366×768 gut lesbar, bei 1920×1080 hochwertig und nicht pixelig; Präsentationslaptop als Zielgerät.
- Animationen sollen **souverän statt hektisch** wirken: leichte Beschleunigung/Abbremsung, kein Ruckeln, kein springendes Licht, keine harten Tween-Resets, keine nervöse Kamera und keine sich wiederholenden Roboter-Gesten.
- Bei UI-Interaktionen: Fokuszustände, Tastaturbedienung, reduzierte Bewegung (`prefers-reduced-motion`), übersichtliche mobile Fallbacks; WebGL-Ausfall -> fachliche alternative Ansicht.

## 8. TECHNISCHE REORGANISATION STATT MONOLITHISCHER HTML-DATEI

Wähle eine saubere, reproduzierbare Projektstruktur, z. B. **Vite + TypeScript oder JavaScript + Three.js** mit lokalen Assets. Die Abgabe ist **eine ZIP mit mehreren Dateien**; ein einziges gigantisches Standalone-HTML ist weder erforderlich noch erwünscht. Der eigentliche Vortrag ist browserbasiert.

Empfohlene Module: `world/` (Räume & räumlicher Überblick), `assets/` (GLB/Texture/Logo), `characters/`, `cinematics/` (Timeline, CameraRig, Übergänge), `flows/` (Fachlogik, Evidenzstatus), `content/` (85 Originalschritte/Notizen/Mapping), `ui/` (Navigation, Quellen, Systemkarte), `tests/`.

Nutze echte Zustandsmaschine/Timeline für stabile Navigation: `enter / animate / pause / seek / exit`, mit aufräumbaren Animationen, kein unkontrolliertes Übereinanderstapeln von Timern und RAF-Loops. Gleichmäßige Delta-Zeit, Antialiasing/Optimierung, Loading-Feedback, Asset-Caching, abgestufte Grafikqualität, Präsentationsmodus. Eigene Starter-Datei für Windows plus README mit Befehlen für lokalen Server/Build. Runtime-Inhalte wenn möglich vollständig lokal (kein Internet beim Vortrag erforderlich). Dynamische Asset-Imports/CORS sauber testen. Ressourcenverhalten beim schnellen Kapitelwechsel prüfen.

## 9. FACHLICHE GRENZEN – NICHT ERFINDEN

85 fachliche Ausgangsschritte aus Kapitel 4–10 müssen **textlich/inhaltlich vollständig nachweisbar** erhalten bleiben. Diese Matrix ist der Abnahmebeleg. Sachlich nicht belegte Aussagen als „offen“, „Modellierung“, „Hypothese“, „SOLL“ deklarieren.

- **ICIS** heißt ICIS. Ältere Referenzen enthalten irrtümlich iKIS/ICES; systematisch prüfen und sachlich korrigieren. Keine unabhängigen, unbestätigten Programme daraus erfinden.
- **Online-Schadenmeldung:** vormals PDF + manuelles Übertragen (historischer Medienbruch); **automatische Datenübernahme nach ICIS inzwischen umgesetzt**.
- **Schaden-Aufgabenpool:** in Planung/Umstellung; nicht als flächendeckend eingeführter IST darstellen.
- **Kündigung:** eigener Weg; keine kausale Pflichtfolge eines Kfz-Schadens; digitaler Self-Service als Vorschlag/SOLL.
- **KSR**, SAP, Scan/OCR, Postkorb, Outlook, Textsystem/andere Anwendungen nur mit belegtem Kontext; keine neue automatische Schnittstelle behaupten.
- **Keine bestätigte reale Gebäudearchitektur / räumliche Nähe von Teams** aus dem schematischen 3D-Modell ableiten.
- Interviewgebundene Beispiele nicht zu allgemeinen SV-Regeln verallgemeinern. Keine erfundenen Zeit-, Kosten- oder Effizienzkennzahlen.

## 10. KONKRETE PILOT-ANIMATION ALS QUALITÄTSGATE – DANACH VOLLSTÄNDIGER AUSBAU

Entwickle **zuerst einen durchgehenden, beurteilbaren Ausschnitt**, der folgenden Ablauf zeigt:

**A. Gebäudeübersicht → Elias’ Antragsprüfung → Systemdetail/Rückfrage → kontrollierter Raumwechsel zur Bestandsbearbeitung → Übergabe verständlich hervorgehoben.**

Dieser Pilot muss zeigen: 1) hochwertige Räume, 2) echte Charakteranimation, 3) echte räumliche Kamerafahrt, 4) nur einen aktiven Systemweg, 5) kleine elegante UI und 6) korrekte Fachinformation. Zusätzlich ein kurzer zweiter Ausschnitt **Kfz-Kunde am Schadenfahrzeug → digitale Schadenmeldung → Ali am Arbeitsplatz**, damit auch Outdoor-Stil und Figur 05 nachweisbar sind.

Bei fehlendem Premium-Asset zunächst **tatsächlich verfügbare Alternativen prüfen**, nicht sofort einen primitiven Ersatz als fertigen Erfolg einsetzen. Stelle dem Nutzer keine unnötigen Rückfragen zu Informationen, die im Paket vorliegen.

**Danach**, falls der Qualitätsmaßstab tatsächlich erreicht ist, die Welt und alle Kapitel 4–10 vollständig realisieren. Arbeite so weit wie möglich innerhalb dieses Auftrags bis zur fertigen Anwendung; beende nicht nach Architekturpapier oder einem einzelnen Screenshot. Falls ein Qualitätsgate real nicht besteht, dokumentiere offen, was fertig ist und was nicht, statt falsche Vollständigkeit zu behaupten.

## 11. ZWINGENDE BROWSER- UND VISUAL-QA

Teste in Chrome/Chromium oder Edge **tatsächlich den ausgelieferten Build**. Mindestens folgende Nachweise:

1. Start/Prolog und erster Zoom; Gebäudekamera aus Überblick und in Nahansicht.
2. Drei Zeitpunkte eines **durchgehenden Raumwechsels** (Anfang, mittlere Kameraposition, Ziel).
3. Elias und Ali jeweils in mindestens zwei sauberen Perspektiven, inklusive ihrer sichtbaren Bewegung/Interaktion.
4. Kfz-Kunde mit erkennbarem, glaubwürdigem Fahrzeug und Telefonhandlung.
5. Ein manueller Kommunikationsschritt und ein automatischer Datenfluss, sichtbar unterscheidbar.
6. System- und Prozesslandkarte im Expertenmodus: vollständige Tiefe auf Nachfrage, im Filmmodus **nicht** permanent eingeblendet.
7. Wiedergabe, Pause/Fortsetzen, schneller Kapitelwechsel, Rücksprung, direkte Raumwahl, Vollbild, Quellen/Notizen ohne Fehler.
8. Abgleich **85/85 Originalschritte** mit erhaltenen Notizen, Quellen und korrekter Zuordnung in `content_mapping.csv`.
9. Screenshotprüfung bei 1366×768 und 1920×1080: lesbare UI, keine Textkollisionen, keine verdeckten Gesichter, keine Doppelüberlagerung.
10. Performance auf dokumentierter Hardware/Browser: Ziel flüssige Präsentation (etwa ≥30 FPS unter typischen Testbedingungen), keine ausreißenden Ruckler oder auffällige Kamerasprünge. Misserfolge konkret benennen.

Screenshots sind **echte Browseraufnahmen**, keine separat generierten Designbilder. Ein durch Code gestartetes Programm ist keine visuelle Abnahme; führe einen direkten Screenshot-Vergleich mit den neun Charakterbildern durch. Dokumentiere eingesetzte GLBs inkl. Rig, Clips und Lizenzen. Keine „Bestanden“-Meldung ohne reale Nachweise.

## 12. AUSLIEFERUNG UND ERFOLGSDEFINITION

Liefere ein fertiges ausführbares Projekt als ZIP mit `index.html`/Build, Quellcode, allen benötigten lokalen 3D-Assets, `START_WINDOWS.bat` oder äquivalentem Starter, README, `content_mapping.csv` für 85 Schritte, Asset-/Lizenzmatrix, Browser-Testbericht, Beweis-Screenshots und dokumentierten Limitationen.

**Abnahmekriterien:**

- **Filmwirkung:** Es sieht aus wie eine bewusst komponierte, ruhige Mini-Animationswelt, nicht wie technische Testgeometrie.
- **Raumwechsel:** räumlich nachvollziehbare Kamerafahrt, keine bloße Szenenumschaltung.
- **Systemverständnis:** Wo? Wer? In welchem System? Welche Übergabe? Auf einen Blick verständlich.
- **Detailarmut der UI:** nie alles gleichzeitig, Infos schrittweise/optional.
- **3D-Qualität:** echte hochwertige Modelle, Charaktere, Autos, Räume, Licht und sichtbar funktionierende Bewegungen.
- **Fachtreue:** 85/85 Inhaltsschritte, Status- und Quelleninformationen erhalten; ICIS korrekt.
- **Robustheit:** Steuerung, Raumwahl, Pausen/Sprünge, Browser und Präsentationsbetrieb funktionieren.

**Beginne jetzt sofort mit der Analyse der beiden Konzept-HTML-Dateien und des Altprojekts, erstelle das fachliche Raum-/Datenfluss-Mapping, verbessere die Assets, implementiere den Pilot samt echten Raumwechseln und baue anschließend die vollständige Anwendung aus.**

**Wiederhole nicht die Fehler der Vorversionen: keine Spielzeugfiguren, keine grauen Würfelräume, keine leeren Screenshots, keine überladene Systemkarte, kein Video als Ersatz.**
