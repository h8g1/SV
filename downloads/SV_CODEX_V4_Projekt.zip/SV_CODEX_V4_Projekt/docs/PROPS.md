# Lokale Fahrzeug- und Möbelmodelle

Alle drei Modelle wurden für diese Anwendung durch `tools/create_props.py` in Blender 4.3.2 erzeugt. Sie sind eigenständige, lokale GLB-Dateien ohne externe Texturen oder Downloads. Die erzeugte Geometrie und das Erzeugungsskript dürfen im Rahmen des Projekts verwendet und verändert werden; es wurden keine Fremdmodelle übernommen. Die Three.js- und Blender-Lizenzen gelten separat für die Werkzeuge, nicht als behauptete Fremdmodell-Lizenz.

| Datei | Inhalt | glTF-Meshes | Materialien | Maßstab |
|---|---|---:|---:|---|
| `public/models/car.glb` | Eigenständige stilisierte Limousine: geglättete durchgehende Karosserieflächen, Glas, fünfteilige Felgenspeichen, Reifen, Spiegel, Leuchten, Scheibenwischer, Türfugen, Griffe, dezente Schramme | 1 (8 Material-Primitives) | 8 | Länge ca. 4,5 m; Front +Z |
| `public/models/desk.glb` | Abgerundete Holzplatte, höhenverstellbare Metallstützen, Füße, Kabelwanne, Kabeldurchführungen | 1 (3 Material-Primitives) | 3 | Höhe ca. 0,76 m; Breite 1,7 m |
| `public/models/chair.glb` | Geglättete ergonomisch gebogene Rückenlehne, Sitzpolster, Armlehnen, Gaslift und Fünfsternfuß mit Rollen | 1 (4 Material-Primitives) | 4 | Sitzhöhe ca. 0,50 m |

GLB-Header, Dateilängen, JSON-Chunks und Mesh-/Materialbestände wurden nach dem Export geprüft. Alle Einzelobjekte wurden pro Modell zu einem Mesh zusammengeführt; die Draw Calls entsprechen den 8 / 3 / 4 Material-Primitives statt 108 / 16 / 25 Einzelobjekten. Die lokale Blender-Import-/Renderprüfung dient nur der Asset-Prüfung und ersetzt keine echte Browseraufnahme der Präsentation.

## Ehrliche Qualitätsgrenzen

Es handelt sich um eigens modellierte stilisierte Präsentationsmodelle, **nicht um eingekaufte Premium- oder fotorealistische Assets**. Die Fahrzeugkarosserie besitzt keine physikalisch simulierte Verformung und keinen detaillierten Innenraum; die Scheiben sind dunkel getönt. Der Schaden ist ein bewusst kleiner exemplarischer Stoßfängerkratzer. Die Holz- und Polstermaterialien verwenden PBR-Farb-/Rauheitswerte, keine gescannten Oberflächentexturen. Die Qualität muss im Kontext der Browserkomposition beurteilt werden; eine Premium-Abnahme wird hiermit nicht behauptet.

## Reproduktion

Im Projektverzeichnis mit installiertem Blender:

```sh
blender -b -t 2 --python tools/create_props.py
```

Der Ausgabepfad wird relativ zum Erzeugungsskript ermittelt (`public/models`).
