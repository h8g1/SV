# V4-Abnahmestand — keine vollständige visuelle Freigabe

## Nachweisbar umgesetzt

- Ausführbarer lokaler Produktionsbuild, modularer Three.js-Quellcode, Vite, Lockfile, Windows-/Unix-Starter, alle erforderlichen Runtime-Dateien lokal.
- 85/85 Originalschritte und 680 unveränderte CSV-Feldwerte, ursprüngliche Notizen/Rohtexte, Quellen und eindeutige Filmsequenzzuordnung. Kapitel 4–10 sind fachlich vollständig abrufbar; 27 steuerbare Szenen einschließlich Prolog/Überblick.
- Geführte Qualitätssequenzen A/B, reale zusammenhängende Gebäude-/Außenwelt, Kamerafahrt statt Szenenteleport, sichtbarer geriggter Gehzyklus auf dem schematischen Weg zur Bestandsbearbeitung.
- Vier tatsächlich geladene skinned Charakter-GLBs mit AnimationMixer, lokale Fahrzeug-/Möbel-GLBs, Original-SV-Logo und alle neun gespeicherten Stilreferenzen.
- Play/Pause, Replay, Vor/Zurück, Zeitsuche, Kapitelwahl, Raumwahl, Tastatur, Vollbild, Tempo, Grafikqualität, Sprecher-/Quellenansicht, optionale Expertenübersicht, reduzierte Bewegung und fachlicher WebGL-Fallback. Tatsächliche Prüfergebnisse stehen im Testbericht, nicht in dieser Funktionsliste.
- Online-Schadenübernahme als umgesetzt; Aufgabenpool als geplant/Umstellung; Kündigungsportal als SOLL. Kündigung bleibt ein separater Vertragszweig. Historische Schreibweisen nur in gekennzeichneten Originalauszügen.

## Nicht bestanden / noch nicht vollständig ausgearbeitet

1. **Premium-Charaktergate:** Gesichter, Haare, Stoff-/Hautmaterialien, Topologie und Bewegungsnuancen erreichen die verbindlichen Referenzporträts nicht. Die eigenen geglätteten Mesh-Rigs sind funktionale Näherungen; sie werden nicht als abgenommene hochwertige Charaktere bezeichnet. Exakter Modell-/Rig-/Animationsbedarf und tatsächlich geprüfte Alternativen: `ASSETS.md`.
2. **Natürliches Schauspiel:** Hand-/Tastaturkontakt und der aufrechte Smartphone-Griff wurden verbessert; es gibt keine animierte Gesichtsrig-Mimik, keine vollständige Hand-/Blick-IK und keine filmreife, individuell inszenierte Gestik für alle Kapitel. Ein automatisch sichtbarer Knochen-Transform ist nur ein Technikbeleg.
3. **30-FPS-Ziel:** In der tatsächlich getesteten Cloud-Softwaregrafik klar nicht erreicht; genaue Messwerte und Renderer im Browserbericht. Das Ergebnis ist weder ein Laptop-Test noch eine Freigabe für flüssigen Präsentationsbetrieb. Ein realer Präsentationsrechner mit Hardwarebeschleunigung bleibt ungeprüft.
4. **Vollständige filmische Ausarbeitung:** Die 85 Inhalte und alle Kapitel sind vorhanden und navigierbar; der gesamte Film ist nicht in V4-Zielqualität abgenommen. Der Prolog nutzt eine vereinfachte Wolken-/Gewitterinszenierung ohne ausgearbeiteten animierten Stadtverkehr. Das Fazit ist ein ruhiger Rückblick; eine vollständig ausgearbeitete Inszenierung sämtlicher nacheinander aufleuchtender Wege fehlt. Mehrere inhaltliche Schritte teilen sich bewusst dieselbe Arbeitsplatzanimation.
5. **Kamera-/Architekturqualität:** Die kritischen Raum- und Außenfahrten wurden nach realen Screenshots korrigiert und erneut geprüft. Es gibt keine allgemeine dynamische Occlusion-Fade-Engine; offene Cutaway-Geometrie, Glas und gezielte Kamerapfade vermeiden Hindernisse. Einzelne Lampen oder Haare bleiben an Bildrändern sichtbar. Keine pauschale Behauptung perfekter Bildkomposition.
6. **Physische Interaktion:** Die Welt ist eine Prozessmetapher. Der Schaden ist eine kleine modellierte Schramme, keine Physiksimulation; die Bildschirm-/Formularhandlungen sind Demonstrationen, keine echte ICIS-Verbindung oder produktive Datenübermittlung. Die Kundin hat keinen internen Systemzugriff.
7. **Ungetestete Plattformen:** Windows-BAT liegt bei, wurde aber mangels Windows nicht dort ausgeführt. Chrome/Chromium im Cloud-Linux wurde tatsächlich getestet. Keine Safari-/Edge-/physische GPU- oder frische Snapshot-Wiederherstellungsfreigabe.

## Konsequenz

**Technisch ausführbare Anwendung mit vollständiger Fachbasis; das gestalterische Gesamtziel ist noch nicht erreicht.** Die anschließende Arbeit benötigt professionell ausgearbeitete und passend animierte Charakter-Assets, erneute Art Direction und einen Performance-/Abnahmelauf auf der vorgesehenen Präsentationshardware. Die Lieferung ist ein belastbarer bearbeitbarer Anwendungsstand, keine behauptete finale V4-Qualitätsfreigabe.

Die Cloud-Konfigurationsfelder `install_script` und `start_skill` wurden als Entwurf gespeichert. Das speichert Anweisungen; es veröffentlicht keinen Snapshot und beweist keine Wiederherstellung in einer neuen Aufgabe. Für die Aktivierung muss der Nutzer die Umgebungseinstellungen prüfen/speichern und die Umgebung veröffentlichen.
