# Herkunft und Lizenzen

- **Three.js 0.180.0** einschließlich offiziellem GLTFLoader, AnimationMixer, Geometrie-Helfern: MIT, vollständiger Text in `THREE_LICENSE.txt`.
- **Vite 7.1.12**: Buildwerkzeug, MIT; `VITE_LICENSE.md`. Weitere npm-Abhängigkeiten werden im Lockfile festgelegt; ihre Lizenztexte liegen nach `npm ci` bei den Paketen. Es werden keine npm-Pakete mit einer eigenen behaupteten Projektlizenz umetikettiert.
- **Open Sans Regular**: lokale Schrift aus dem Systempaket, Apache 2.0; Copyright-/Lizenzangaben in `OPEN_SANS_LICENSE.txt`. Der interne CSS-Familienalias ist nur eine Laufzeitbezeichnung; die ausgelieferte Datei heißt korrekt `OpenSans-Regular.ttf`.
- **Charaktere/Fahrzeug/Möbel**: eigens erzeugte Geometrie, Rigs und Clips; keine Fremdmodelle eingebunden. Generatoren liegen unter `tools/`. Herkunft, tatsächlich vorhandene Clips und Qualitätsgrenzen in `ASSETS.md` und `PROPS.md`.
- **Architektur/Texturverfahren**: eigens erzeugte Geometrie und Canvas-Materialien, keine externen Fotos oder Texturarchive.
- **SV-Logo, neun Charakterreferenzen und Fachquellen**: unverändert aus dem vom Nutzer zur Bearbeitung übergebenen Paket. Keine allgemeine Weiterveröffentlichungs- oder Markenlizenz wird behauptet. Rechte bleiben bei den jeweiligen Inhabern. Generierte Logos aus Charakterreferenzen werden nicht als neue SV-Marke verwendet.
- **Geprüfte Alternativen**: Soldier/RobotExpressive wurden beurteilt und verworfen; diese Drittmodelle sind nicht Teil der Lieferung. Keine fremden Modelllizenzen werden auf die eigenen Modelle übertragen.

Das Projekt enthält keinen Lizenzschlüssel, keine Geheimnisse und keine externen Laufzeit-Downloads. Die mitgelieferten historischen HTML-Fachquellen können eigene externe Links besitzen; sie sind Quellenmaterial, keine Abhängigkeiten des 3D-Vortrags.
