#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
  exec python3 -m http.server 4173 --bind 127.0.0.1 --directory dist
fi
exec node tools/serve.mjs
