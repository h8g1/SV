"""Original SV V4 props. Run: blender -b -t 2 --python tools/create_props.py"""
import bpy, math, os
from mathutils import Vector
from pathlib import Path
OUT=str(Path(__file__).resolve().parents[1] / 'public' / 'models')
os.makedirs(OUT,exist_ok=True)
def reset():
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 for d in bpy.data.materials: bpy.data.materials.remove(d)
def mat(name,color,metal=0,rough=.45,alpha=1):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,alpha);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,alpha);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 return m
def finish(ob,m,bevel=0):
 ob.data.materials.append(m)
 if ob.type=='MESH':
  for p in ob.data.polygons:p.use_smooth=True
 if bevel:
  mod=ob.modifiers.new('Machined radii','BEVEL');mod.width=bevel;mod.segments=3
  bpy.context.view_layer.objects.active=ob;bpy.ops.object.modifier_apply(modifier=mod.name)
 return ob
def cube(n,loc,scale,m,b=.02):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,m,b)
def uv(n,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,m)
def cyl(n,loc,r,depth,m,rotation=(0,0,0),verts=32):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=depth,location=loc,rotation=rotation);o=bpy.context.object;o.name=n;return finish(o,m,.008)
def curve(n,pts,r,m):
 cu=bpy.data.curves.new(n,'CURVE');cu.dimensions='3D';cu.resolution_u=12;cu.bevel_depth=r;cu.bevel_resolution=3;s=cu.splines.new('BEZIER');s.bezier_points.add(len(pts)-1)
 for p,co in zip(s.bezier_points,pts):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new(n,cu);bpy.context.collection.objects.link(o);o.data.materials.append(m);return o
def mesh(n,verts,faces,m,sub=0):
 me=bpy.data.meshes.new(n);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);finish(o,m)
 if sub:
  mo=o.modifiers.new('Surface refinement','SUBSURF');mo.levels=sub;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mo.name)
 return o
def export(name):
 # Convert curves and batch all geometry; glTF retains one primitive per material.
 bpy.ops.object.select_all(action='SELECT')
 bpy.context.view_layer.objects.active=next(o for o in bpy.context.scene.objects if o.type in {'MESH','CURVE'})
 bpy.ops.object.convert(target='MESH')
 bpy.ops.object.join()
 bpy.context.object.name=name+' combined geometry'
 bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,name+'.glb'),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_animations=False)
 print('EXPORTED',name)
reset()
paint=mat('Midnight atlantic metallic paint',(.055,.17,.24),.65,.24);glass=mat('Tinted automotive glazing',(.12,.23,.28),.35,.18);black=mat('Rubber and dark trim',(.025,.03,.033),.05,.68);silver=mat('Satin alloy',(.42,.47,.49),.88,.26);chrome=mat('Bright trim',(.7,.74,.75),.9,.17);red=mat('Rear lamps',(.65,.035,.025),.25,.25);lamp=mat('Headlamp optics',(.87,.93,.88),.4,.18);light=mat('Licenseplate',(.9,.91,.86),.1,.4)
# Chassis: rounded nonrectangular loft, direction front -Y.
sections=[(-2.23,.68,.5,.85),(-2.17,.87,.35,.99),(-1.92,.95,.31,1.02),(-1.42,.96,.3,1.07),(-.8,.95,.31,1.08),(0,.96,.31,1.07),(.8,.95,.31,1.02),(1.5,.93,.33,.98),(2,.88,.36,.94),(2.19,.68,.48,.85)]
verts=[]
profile=[(-.76,0),(-.98,.15),(-1,.5),(-.93,.83),(-.7,1),(0,1.04),(.7,1),(.93,.83),(1,.5),(.98,.15),(.76,0),(0,-.01)]
for y,w,lo,hi in sections:
 for x,z in profile:verts.append((x*w,y,lo+z*(hi-lo)))
N=len(profile);faces=[]
for i in range(len(sections)-1):
 for j in range(N):faces.append((i*N+j,i*N+(j+1)%N,(i+1)*N+(j+1)%N,(i+1)*N+j))
faces.extend([tuple(reversed(range(N))),tuple((len(sections)-1)*N+j for j in range(N))]);mesh('Sculpted sedan body shell',verts,faces,paint,2)
# Low arched roof glazed canopy.
verts=[];sections2=[(-1.08,.76,1.04),(-.83,.73,1.22),(-.48,.67,1.53),(-.28,.66,1.59),(.45,.65,1.57),(.82,.71,1.38),(1.15,.77,1.02)]
for y,w,h in sections2:
 for x,z in [(-1,1.01),(-.99,h-.13),(-.83,h),(-.4,h+.035),(.4,h+.035),(.83,h),(.99,h-.13),(1,1.01)]:verts.append((x*w,y,z))
N=8;faces=[]
for i in range(len(sections2)-1):
 for j in range(N-1):faces.append((i*N+j,i*N+j+1,(i+1)*N+j+1,(i+1)*N+j))
mesh('Swept glazing cabin',verts,faces,glass,1)
# Roof painted panel and frame trim.
roof=cube('Floating roof panel', (0,.08,1.62),(1.16,.82,.05),paint,.07)
for sx in [-1,1]:
 curve('Chrome window sill',[(sx*.8,-1.05,1.02),(sx*.91,-.35,1.02),(sx*.91,.6,1.01),(sx*.78,1.13,1)],.014,chrome)
 curve('Front pillar',[(sx*.79,-1.07,1.05),(sx*.67,-.6,1.48),(sx*.57,-.38,1.61)],.035,paint)
 curve('Rear pillar',[(sx*.56,.47,1.59),(sx*.67,.8,1.4),(sx*.78,1.15,1.01)],.045,paint)
 curve('B pillar',[(sx*.91,.13,1.02),(sx*.72,.13,1.39),(sx*.65,.13,1.61)],.025,black)
 curve('Upper window frame',[(sx*.59,-.43,1.61),(sx*.62,-.1,1.65),(sx*.6,.48,1.61)],.025,paint)
 # door seams
 for yy in [-.8,.3,1.18]:curve('Subtle door seam',[(sx*.922,yy,1.0),(sx*.962,yy,.72),(sx*.9,yy,.39)],.004,black)
 for yy in [-.35,.75]:cube('Flush door handle',(sx*.956,yy,.96),(.02,.16,.025),silver,.012)
 uv('Aerodynamic mirror',(sx*1.02,-.76,1.1),(.16,.11,.07),paint);cube('Mirror lens',(sx*1.045,-.70,1.105),(.17,.012,.08),silver,.01)
 # rocker panel
 curve('Side rocker',[(sx*.81,-1.72,.4),(sx*.93,0,.35),(sx*.82,1.78,.4)],.028,black)
for y in [-1.41,1.39]:
 for sx in [-1,1]:
  cyl('Road tire',(sx*.94,y,.39),.365,.22,black,(0,math.pi/2,0),48)
  cyl('Five spoke wheel rim',(sx*1.058,y,.39),.273,.018,silver,(0,math.pi/2,0),48)
  cyl('Brake shadow',(sx*1.072,y,.39),.215,.02,black,(0,math.pi/2,0),40)
  for a in range(5):
   angle=a*math.tau/5;ob=cube('Machined radial spoke',(sx*1.086,y+math.cos(angle)*.135,.39+math.sin(angle)*.135),(.026,.27,.044),silver,.016);ob.rotation_euler.x=angle
  cyl('Wheel centre',(sx*1.105,y,.39),.065,.028,chrome,(0,math.pi/2,0))
  for a in range(5):
   angle=a*math.tau/5;cyl('Wheel lug',(sx*1.123,y+math.cos(angle)*.044,.39+math.sin(angle)*.044),.008,.006,black,(0,math.pi/2,0),8)
# front grille/lights/bumper
cube('Recessed grille',(0,-2.209,.61),(1.05,.045,.19),black,.055)
for x in [-.42,-.28,-.14,0,.14,.28,.42]:cube('Grille blade',(x,-2.237,.61),(.018,.018,.15),silver,.005)
for sx in [-1,1]:
 lampob=cube('Sculpted LED headlamp',(sx*.62,-2.16,.88),(.38,.07,.11),lamp,.04);lampob.rotation_euler.z=sx*.07
 curve('Daylight signature',[(sx*.44,-2.203,.9),(sx*.65,-2.192,.9),(sx*.79,-2.16,.87)],.013,lamp)
 cube('Tail lamp',(sx*.47,2.126,.84),(.29,.045,.095),red,.035)
 curve('Bumper trim',[(sx*.14,-2.23,.48),(sx*.7,-2.2,.48),(sx*.85,-2.12,.54)],.015,silver)
# A subtle cosmetic scratch rather than staged crash sculpture
for n in range(3):curve('Illustrative bumper scrape',[(.4+n*.02,-2.211,.77-n*.025),(.58,-2.209,.75-n*.025),(.72,-2.18,.77-n*.025)],.004,silver)
cube('Front blank plate',(0,-2.251,.43),(.38,.012,.09),light,.007);cube('Rear blank plate',(0,2.179,.61),(.38,.012,.09),light,.007)
curve('Wiper left',[(-.5,-.97,1.18),(-.2,-.93,1.2),(.05,-.91,1.22)],.009,black);curve('Wiper right',[(.05,-.96,1.17),(.3,-.94,1.2),(.52,-.92,1.2)],.009,black)
export('car')
# Desk - physically proportioned sit/stand worktable.
reset();oak=mat('Warm blond oak',(.61,.42,.24),0,.52);metal=mat('Powdercoat warm white',(.84,.85,.81),.25,.4);dark=mat('Graphite fittings',(.055,.07,.073),.4,.38)
cube('Solid oak desktop',(0,0,.735),(1.7,.8,.045),oak,.025)
for x in [-.62,.62]:
 cube('Telescopic desk column',(x,.09,.39),(.075,.09,.65),metal,.012);cube('Upper sliding column',(x,.09,.54),(.06,.075,.32),metal,.009);cube('Rounded stabilizing foot',(x,.03,.04),(.085,.62,.055),metal,.024)
 for y in [-.23,.29]:cube('Floor pad',(x,y,.012),(.07,.08,.02),dark,.008)
cube('Underdesk crossbar',(0,.09,.58),(1.29,.07,.07),metal,.015);cube('Cable tray',(0,.24,.64),(.74,.14,.075),dark,.015);cube('Height controller',(.65,-.37,.695),(.16,.035,.035),dark,.008)
for x in [-.52,.52]:cyl('Cable grommet',(x,.27,.762),.026,.008,dark)
export('desk')
# Ergonomic chair, curved upholstered shell with mesh back and adjustable hardware.
reset();fabric=mat('Textured charcoal upholstery',(.095,.125,.13),0,.87);frame=mat('Satin dark frame',(.035,.05,.052),.4,.38);alloy=mat('Polished chair hardware',(.4,.45,.45),.85,.25);meshmat=mat('Woven mesh support',(.13,.17,.175),0,.8)
# seat cushion & sculpted back using cross-sectional grids
cube('Contoured seat',(0,0,.46),(.49,.47,.09),fabric,.08)
vs=[];fs=[]
for j in range(7):
 z=.5+j*.075;w=.21+(math.sin(j/6*math.pi))*.025
 for i in range(9):
  u=(i-4)/4;vs.append((u*w,.21+.045*(1-u*u)+.04*math.sin(j/6*math.pi),z))
for j in range(6):
 for i in range(8):a=j*9+i;fs.append((a,a+1,a+10,a+9))
ob=mesh('Ergonomic continuous backrest',vs,fs,meshmat,2);sol=ob.modifiers.new('Backrest thickness','SOLIDIFY');sol.thickness=.027;bpy.context.view_layer.objects.active=ob;bpy.ops.object.modifier_apply(modifier=sol.name)
for sx in [-1,1]:
 curve('Back frame',[(sx*.2,.22,.52),(sx*.24,.24,.75),(sx*.21,.22,.96)],.018,frame)
 curve('Adjustable arm support',[(sx*.26,.07,.48),(sx*.29,.06,.6),(sx*.29,-.03,.65)],.019,frame);cube('Soft arm cap',(sx*.29,-.035,.655),(.07,.22,.035),fabric,.025)
cyl('Gaslift',(0,0,.25),.035,.32,alloy);cyl('Gaslift shroud',(0,0,.16),.05,.16,frame)
for k in range(5):
 a=k*math.tau/5;x=math.cos(a)*.28;y=math.sin(a)*.28
 curve('Star base arm',[(0,0,.14),(x*.5,y*.5,.1),(x,y,.07)],.025,alloy)
 for off in [-.02,.02]:cyl('Caster wheel',(x+off,y,.041),.036,.025,frame,(0,math.pi/2,0),20)
export('chair')
