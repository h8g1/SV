"""Original SV character approximations. Run: blender -b -t 2 --python tools/create_assets.py.
No third-party meshes. Smooth ring-loft surfaces, skinned armatures and authored clips.
These are NOT reference-quality premium character assets; see docs/ASSETS.md.
"""
import bpy, math, os, json
from pathlib import Path
from mathutils import Vector
from math import sin, cos, pi

OUT=str(Path(__file__).resolve().parents[1]/'public'/'models')
os.makedirs(OUT, exist_ok=True)

def mat(name,color,rough=.52,metal=0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1); bs.inputs['Roughness'].default_value=rough; bs.inputs['Metallic'].default_value=metal
    return m

def mesh(name,verts,faces,material,group='head',sub=1):
    me=bpy.data.meshes.new(name); me.from_pydata(verts,[],faces); me.update()
    ob=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(ob); ob.data.materials.append(material)
    for f in me.polygons:f.use_smooth=True
    if sub:
        mod=ob.modifiers.new('Tailored smooth surface','SUBSURF'); mod.levels=sub; mod.render_levels=sub
        bpy.context.view_layer.objects.active=ob; bpy.ops.object.modifier_apply(modifier=mod.name)
    vg=ob.vertex_groups.new(name=group); vg.add(list(range(len(ob.data.vertices))),1,'REPLACE')
    PARTS.append(ob)
    return ob

def loft(name,rings,material,group='head',segments=24,sub=1):
    # ring: z, cx, cy, rx, ry. 3D surfaces, closed ends.
    v=[]
    for z,x,y,rx,ry in rings:
        for i in range(segments):
            a=2*pi*i/segments; v.append((x+cos(a)*rx,y+sin(a)*ry,z))
    f=[]
    for j in range(len(rings)-1):
        for i in range(segments):
            a=j*segments+i;b=j*segments+(i+1)%segments;f.append((a,b,b+segments,a+segments))
    f.extend([tuple(reversed(range(segments))),tuple((len(rings)-1)*segments+i for i in range(segments))])
    return mesh(name,v,f,material,group,sub)

def oval(name,center,scale,material,group='head',segments=24):
    x,y,z=center;rx,ry,rz=scale
    rings=[]
    for j in range(13):
        a=-pi/2+pi*j/12; r=max(.003,cos(a));rings.append((z+sin(a)*rz,x,y,r*rx,r*ry))
    return loft(name,rings,material,group,segments,1)

def tube(name,points,radius,material,group='head'):
    cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=12;cu.bevel_depth=radius;cu.bevel_resolution=3
    s=cu.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
    for p,co in zip(s.bezier_points,points):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);cu.materials.append(material)
    bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.convert(target='MESH');ob.select_set(False)
    vg=ob.vertex_groups.new(name=group);vg.add(list(range(len(ob.data.vertices))),1,'REPLACE');PARTS.append(ob);return ob

def panel(name,coords,material,group='chest',thick=.003):
    ob=mesh(name,coords,[tuple(range(len(coords)))],material,group,0)
    so=ob.modifiers.new('Fabric thickness','SOLIDIFY');so.thickness=thick
    bpy.context.view_layer.objects.active=ob;bpy.ops.object.modifier_apply(modifier=so.name)
    be=ob.modifiers.new('Soft edges','BEVEL');be.width=.002;be.segments=3
    bpy.ops.object.modifier_apply(modifier=be.name);return ob

def cube(name,loc,scale,material,group='hand.R',bevel=.01):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);ob=bpy.context.object;ob.name=name;ob.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    ob.data.materials.append(material)
    be=ob.modifiers.new('Molded edges','BEVEL');be.width=bevel;be.segments=3;bpy.ops.object.modifier_apply(modifier=be.name)
    vg=ob.vertex_groups.new(name=group);vg.add(list(range(len(ob.data.vertices))),1,'REPLACE');PARTS.append(ob);ob.select_set(False);return ob

def rig_character(name):
    arm=bpy.data.armatures.new(name+' skeleton');rig=bpy.data.objects.new(name+' rig',arm);bpy.context.collection.objects.link(rig)
    bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
    defs=[('root',(0,0,0),(0,0,.2),None),('pelvis',(0,0,.87),(0,0,1.0),'root'),('spine',(0,0,1.0),(0,0,1.2),'pelvis'),('chest',(0,0,1.2),(0,0,1.42),'spine'),('neck',(0,0,1.42),(0,0,1.5),'chest'),('head',(0,0,1.5),(0,0,1.8),'neck')]
    for side,s in [('L',-1),('R',1)]:
        defs.extend([(f'upper_arm.{side}',(s*.205,0,1.4),(s*.34,-.015,1.13),'chest'),(f'forearm.{side}',(s*.34,-.015,1.13),(s*.40,-.035,.93),f'upper_arm.{side}'),(f'hand.{side}',(s*.40,-.035,.93),(s*.415,-.04,.83),f'forearm.{side}'),(f'thigh.{side}',(s*.105,0,.92),(s*.11,0,.52),'pelvis'),(f'shin.{side}',(s*.11,0,.52),(s*.11,0,.12),f'thigh.{side}'),(f'foot.{side}',(s*.11,0,.12),(s*.11,-.15,.07),f'shin.{side}')])
    for bn,h,t,parent in defs:
        b=arm.edit_bones.new(bn);b.head=h;b.tail=t
        if parent:b.parent=arm.edit_bones[parent]
    bpy.ops.object.mode_set(mode='OBJECT');rig.select_set(False)
    for ob in PARTS:
        mod=ob.modifiers.new('Skin deformation','ARMATURE');mod.object=rig;ob.parent=rig
    return rig

def animation(rig,name,length,pose_fn):
    action=bpy.data.actions.new(name);rig.animation_data_create();rig.animation_data.action=action
    for f in range(1,length+1,4):
        # Prevent previously authored strips/current action from overwriting
        # explicit poses during dependency-graph updates for wrist orientation.
        rig.animation_data.action=None
        for b in rig.pose.bones:b.rotation_mode='XYZ';b.rotation_euler=(0,0,0);b.location=(0,0,0)
        pose_fn(rig.pose.bones,(f-1)/(length-1))
        rig.animation_data.action=action
        for b in rig.pose.bones:
            b.keyframe_insert(data_path='rotation_euler',frame=f);b.keyframe_insert(data_path='location',frame=f)
    for fc in action.fcurves:
        for kp in fc.keyframe_points:kp.interpolation='BEZIER'
    track=rig.animation_data.nla_tracks.new();track.name=name;track.mute=True;strip=track.strips.new(name,1,action);strip.action_frame_end=length
    rig.animation_data.action=None
    return action

def make_character(name,woman=False):
    global PARTS
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);PARTS=[]
    skin=mat('Warm skin',(.68,.36,.22) if name=='customer' else (.75,.43,.29),.55)
    ear=mat('Ear and lip warmth',(.55,.20,.15),.62)
    dark=mat('Pupil',(.018,.012,.009),.25)
    white=mat('Warm eye white',(.94,.89,.8),.22)
    iris=mat('Brown iris',(.22,.10,.035),.24)
    hair=mat('Silver blonde hair' if woman else 'Chestnut hair',(.65,.58,.49) if woman else (.07,.029,.014),.47)
    hairlight=mat('Hair highlight',(.84,.76,.64) if woman else (.13,.058,.024),.55)
    suit=mat('Knit terracotta' if woman else 'Charcoal tailoring',(.58,.19,.13) if woman else (.035,.044,.055),.8)
    shirt=mat('Cotton',(.84,.83,.77),.86)
    trousers=mat('Denim' if name=='customer' else 'Trousers',(.11,.18,.23) if name=='customer' else (.045,.055,.067),.9)
    jacket=mat('Olive twill',(.18,.22,.13),.85) if name=='customer' else suit
    leather=mat('Brown leather' if name=='customer' else 'Leather',(.11,.065,.036) if name=='customer' else (.025,.028,.031),.42)
    red=mat('SV red tie',(.68,.013,.026),.5)
    # trousers and shoes are tailored loft surfaces, not primitive limb pieces.
    for side,s in [('L',-1),('R',1)]:
        x=s*.105
        leg=loft('Tailored trouser '+side,[(.105,x,.02,.065,.07),(.13,x,.02,.068,.075),(.29,x,.014,.075,.075),(.48,x,.005,.082,.083),(.54,x,0,.088,.09),(.75,x,0,.10,.105),(.91,x,0,.11,.11)],trousers,'thigh.'+side)
        vg=leg.vertex_groups['thigh.'+side];sv=leg.vertex_groups.new(name='shin.'+side)
        for v in leg.data.vertices:
            w=max(0,min(1,(.62-v.co.z)/.20));vg.add([v.index],1-w,'REPLACE');sv.add([v.index],w,'REPLACE')
        loft('Leather shoe '+side,[(.02,x,-.055,.069,.155),(.035,x,-.055,.075,.16),(.07,x,-.06,.073,.157),(.10,x,-.045,.067,.12),(.14,x,.01,.058,.075)],leather,'foot.'+side)
        tube('Sole welt '+side,[(x-.068,-.16,.043),(x-.069,-.04,.043),(x-.05,.085,.043),(x+.05,.085,.043),(x+.069,-.04,.043),(x+.066,-.16,.043),(x-.068,-.16,.043)],.004,hairlight,'foot.'+side)
    # torso fitted across waist, chest and natural shoulders.
    torso=loft('Tailored jacket' if name=='elias' else 'Soft knit body',[(.88,0,0,.17,.105),(.91,0,0,.182,.112),(1.04,0,0,.177,.108),(1.18,0,0,.195,.12),(1.32,0,0,.222,.115),(1.38,0,0,.22,.097),(1.42,0,0,.17,.075),(1.45,0,0,.073,.06)],jacket,'chest',32)
    sp=torso.vertex_groups.new(name='spine');ch=torso.vertex_groups['chest']
    for v in torso.data.vertices:
        w=max(0,min(1,(1.21-v.co.z)/.24));sp.add([v.index],w,'REPLACE');ch.add([v.index],1-w,'REPLACE')
    # neat shirt panel, lapels and collar.
    panel('Cotton chest insert',[(-.078,-.119,1.38),(-.055,-.122,1.12),(.055,-.122,1.12),(.078,-.119,1.38),(0,-.10,1.44)],shirt)
    for s in [-1,1]:
        panel('Shirt collar',[(0,-.104,1.44),(s*.073,-.083,1.437),(s*.081,-.127,1.375),(s*.032,-.143,1.35)],shirt)
        if name=='elias':
            panel('Jacket lapel',[(s*.076,-.11,1.42),(s*.15,-.10,1.33),(s*.12,-.129,1.29),(s*.035,-.134,1.13),(s*.057,-.137,1.34)],suit)
    if name=='elias':
        panel('Red silk tie',[(0,-.145,1.36),(-.024,-.143,1.31),(-.036,-.132,1.075),(0,-.135,1.04),(.034,-.132,1.075),(.023,-.143,1.31)],red)
        loft('Tie knot',[(1.32,0,-.144,.018,.009),(1.345,0,-.144,.026,.012),(1.369,0,-.135,.02,.009)],red,'chest')
        for z in [1.015,1.10]:oval('Jacket button',(.018,-.12,z),(.007,.004,.007),leather,'spine')
    if woman:
        panel('Cardigan edge left',[(-.08,-.12,1.42),(-.04,-.132,1.26),(-.07,-.12,.90),(-.095,-.121,.90),(-.064,-.136,1.27),(-.10,-.122,1.42)],suit)
        panel('Cardigan edge right',[(.08,-.12,1.42),(.04,-.132,1.26),(.07,-.12,.90),(.095,-.121,.90),(.064,-.136,1.27),(.10,-.122,1.42)],suit)
    # fitted arms and articulated hands, individually modeled fingers.
    for side,s in [('L',-1),('R',1)]:
        ar=loft('Sleeve '+side,[(.925,s*.397,-.035,.053,.055),(1.01,s*.378,-.03,.062,.064),(1.13,s*.335,-.016,.073,.071),(1.25,s*.285,0,.085,.078),(1.37,s*.22,0,.09,.082),(1.405,s*.19,0,.064,.06)],jacket,'upper_arm.'+side)
        fa=ar.vertex_groups.new(name='forearm.'+side);ua=ar.vertex_groups['upper_arm.'+side]
        for v in ar.data.vertices:
            w=max(0,min(1,(1.22-v.co.z)/.15));ua.add([v.index],1-w,'REPLACE');fa.add([v.index],w,'REPLACE')
        loft('Shirt cuff '+side,[(.914,s*.402,-.035,.050,.051),(.94,s*.395,-.035,.052,.052)],shirt,'forearm.'+side)
        palm=loft('Hand '+side,[(.815,s*.416,-.04,.036,.024),(.84,s*.413,-.042,.046,.027),(.88,s*.408,-.038,.047,.03),(.916,s*.402,-.035,.034,.033)],skin,'hand.'+side,20)
        if name=='customer' and side=='R':
            for j in range(4):
                z=.812+j*.021
                tube('Curled grip finger '+str(j),[(.444,-.037,z),(.468,-.047,z-.003),(.470,-.071,z-.004),(.452,-.083,z)],.008,skin,'hand.R')
            tube('Opposed grip thumb',[(.382,-.036,.887),(.371,-.049,.865),(.383,-.063,.850),(.398,-.063,.851)],.011,skin,'hand.R')
        else:
            for j in range(4):
                fx=s*.416+(j-1.5)*.020;end=.754+abs(j-1.4)*.011
                loft('Finger '+side+str(j),[(end,fx,-.047,.006,.008),(end+.006,fx,-.047,.008,.01),(.811,fx,-.047,.009,.011),(.837,fx,-.043,.010,.012)],skin,'hand.'+side,12)
            tube('Thumb '+side,[(s*.374,-.042,.89),(s*.355,-.059,.858),(s*.362,-.074,.833)],.013,skin,'hand.'+side)
    # neck and deliberately sculpted head profile.
    loft('Neck',[(1.39,0,.005,.065,.06),(1.48,0,.005,.061,.058),(1.53,0,.005,.068,.06)],skin,'neck')
    loft('Face and cranium',[(1.468,0,-.018,.036,.044),(1.485,0,-.016,.064,.070),(1.515,0,-.008,.09,.086),(1.555,0,0,.109,.096),(1.60,0,.006,.123,.106),(1.65,0,.011,.128,.111),(1.70,0,.017,.124,.112),(1.75,0,.02,.114,.106),(1.79,0,.021,.087,.086),(1.815,0,.021,.034,.038)],skin,'head',40,2)
    # ears, concha, brows, eyelids and eyes.
    for s in [-1,1]:
        oval('Ear', (s*.124,.006,1.63),(.026,.021,.046),skin)
        oval('Ear concha',(s*.139,-.010,1.631),(.012,.007,.026),ear)
        oval('Eye white',(s*.053,-.091,1.666),(.037,.020,.026),white)
        oval('Iris',(s*.053,-.109,1.666),(.015,.005,.017),iris)
        oval('Pupil',(s*.053,-.113,1.666),(.008,.003,.011),dark)
        oval('Catchlight',(s*.048,-.116,1.674),(.004,.0015,.004),white)
        tube('Upper eyelid',[(s*.020,-.101,1.672),(s*.05,-.112,1.692),(s*.084,-.093,1.678)],.004,skin)
        tube('Eyebrow',[(s*.021,-.102,1.713),(s*.052,-.112,1.718),(s*.086,-.09,1.707)],.008,hair)
    # bridge and tip on continuous triangulated nose surface.
    loft('Nose',[(1.607,0,-.105,.018,.012),(1.619,0,-.119,.026,.020),(1.635,0,-.128,.021,.026),(1.66,0,-.108,.014,.017),(1.70,0,-.097,.010,.012)],skin,'head',20,2)
    for s in [-1,1]:oval('Nostril',(s*.014,-.132,1.617),(.006,.004,.004),ear)
    tube('Friendly smile',[(-.044,-.092,1.563),(-.020,-.106,1.551),(0,-.109,1.548),(.025,-.104,1.554),(.044,-.09,1.566)],.0045,ear)
    tube('Lower lip',[(-.027,-.101,1.545),(0,-.108,1.540),(.027,-.10,1.547)],.005,skin)
    if name=='customer':
        beard=mat('Soft stubble',(.20,.12,.08),.92)
        for s in [-1,1]:
            for j in range(10):
                a=(j/9)*1.1; x=s*(.03+sin(a)*.065);z=1.515+cos(a)*.033;y=-.070+abs(x)*.23
                tube('Stubble stroke',[(x,y,z),(x+.001,y-.002,z+.007)],.0009,beard)
    # sculpted cap hair surface with asymmetric swept locks, no primitive wig.
    verts=[];faces=[];N=40;R=9
    for j in range(R):
        t=j/(R-1)
        for i in range(N):
            a=2*pi*i/N; front=max(0,-sin(a));edge=1.676+front*.080
            z=edge+(1.862-edge)*sin(t*pi/2);rad=cos(t*pi/2)
            verts.append((cos(a)*.132*rad+.02*t,sin(a)*.119*rad+.019,z+.012*sin(a+1)*sin(t*pi)))
    for j in range(R-1):
        for i in range(N):a=j*N+i;b=j*N+(i+1)%N;faces.append((a,b,b+N,a+N))
    mesh('Swept sculpted hair',verts,faces,hair,'head',2)
    for j in range(20):
        x=-.108+j*.0105
        tube('Swept hair strand',[(x,-.085,1.755+.025*(j/20)),(x+.032,-.06,1.837),(x+.045,.025,1.851),(x+.025,.09,1.79)],.0015,hairlight)
    if not woman:
        for j in range(6):
            x=-.10+j*.027
            tube('Sculpted front wave',[(x,-.09,1.754),(x+.01,-.114,1.80),(x+.06,-.080,1.856),(x+.09,.005,1.83)],.010,hair)
    if woman:
        for s in [-1,1]:
            for j in range(5):
                y=-.045+j*.026
                tube('Silver bob lock',[(s*.11,y,1.78),(s*.139,y,1.70),(s*.14,y+.016,1.60),(s*.115,y+.04,1.54)],.019,hair)
    if name=='ali' or woman:
        glass=mat('Tortoiseshell frames' if woman else 'Black acetate',(.12,.07,.04) if woman else (.015,.019,.022),.34)
        for s in [-1,1]:
            points=[]
            for j in range(17):
                a=2*pi*j/16;points.append((s*.054+.046*cos(a),-.12,1.665+.036*sin(a)))
            tube('Spectacle frame',points,.004,glass)
            tube('Spectacle arm',[(s*.10,-.119,1.68),(s*.126,-.047,1.68),(s*.131,.015,1.67)],.0035,glass)
        tube('Glasses bridge',[(-.009,-.12,1.674),(0,-.126,1.683),(.009,-.12,1.674)],.003,glass)
    # Smartphone retained as a separate named, hand-skinned prop for clips.
    if name=='customer':
        phone=mat('Phone graphite',(.025,.03,.04),.26,.5);screen=mat('Phone display',(.11,.24,.29),.32)
        cube('Smartphone body',(.42,-.071,.842),(.073,.014,.145),phone,'hand.R',.009)
        cube('Smartphone glass',(.42,-.0625,.842),(.065,.002,.132),screen,'hand.R',.006)
        oval('Phone camera',(.438,-.083,.897),(.005,.002,.005),dark,'hand.R')
    # Join authored surfaces into one skinned object. Material boundaries survive,
    # while dozens of per-feature scene nodes/draw calls are avoided.
    bpy.ops.object.select_all(action='DESELECT')
    for ob in PARTS:ob.select_set(True)
    bpy.context.view_layer.objects.active=PARTS[0]
    bpy.ops.object.join(); joined=bpy.context.object;joined.name=name+' tailored character';PARTS=[joined]
    rig=rig_character(name)
    def idle(b,t):
        b['chest'].rotation_euler.x=.013*sin(2*pi*t);b['head'].rotation_euler.z=.035*sin(2*pi*t);b['upper_arm.L'].rotation_euler.z=.03;b['upper_arm.R'].rotation_euler.z=-.03
    def seated(b,t):
        idle(b,t);b['root'].location.y=-.42
        for side in ['L','R']:
            b['thigh.'+side].rotation_euler.x=-1.35;b['shin.'+side].rotation_euler.x=1.42
            b['upper_arm.'+side].rotation_euler.x=-1.05;b['forearm.'+side].rotation_euler.x=-.50+.035*sin(2*pi*t+(0 if side=='L' else pi));b['hand.'+side].rotation_euler.x=.08*sin(4*pi*t+(0 if side=='L' else pi))
        b['head'].rotation_euler.x=.08
    def phone(b,t):
        edge=min(1,t/.20,(1-t)/.20);lift=edge*edge*(3-2*edge)
        idle(b,t);b['upper_arm.R'].rotation_euler.x=-.20-.95*lift;b['forearm.R'].rotation_euler.x=-.20-.55*lift;b['forearm.R'].rotation_euler.z=-.08*lift;b['head'].rotation_euler.x=.13*lift
        b['upper_arm.L'].rotation_euler.x=-.3;b['forearm.L'].rotation_euler.x=-.65
        # Maintain portrait orientation through the moving arm: palm and fingers
        # grip the sides, display faces the customer, rear lens faces the scene.
        bpy.context.view_layer.update()
        hand=b['hand.R']; upright=hand.bone.matrix_local.copy();upright.translation=hand.head
        hand.matrix=upright
    def walk(b,t):
        a=sin(2*pi*t)*.38;b['thigh.L'].rotation_euler.x=a;b['thigh.R'].rotation_euler.x=-a;b['shin.L'].rotation_euler.x=max(0,-a)*1.3;b['shin.R'].rotation_euler.x=max(0,a)*1.3;b['upper_arm.L'].rotation_euler.x=-a*.6;b['upper_arm.R'].rotation_euler.x=a*.6;b['root'].location.y=.012*(1-cos(4*pi*t))
    animation(rig,'idle',97,idle);animation(rig,'work',97,seated);animation(rig,'phone',97,phone);animation(rig,'walk',49,walk)
    for track in rig.animation_data.nla_tracks:track.mute=False
    # Rest reset. glTF exports NLA strips as named clips.
    for b in rig.pose.bones:b.rotation_euler=(0,0,0);b.location=(0,0,0)
    bpy.context.scene.frame_set(1)
    bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,name+'.glb'),export_format='GLB',export_animations=True,export_animation_mode='NLA_TRACKS',export_frame_range=False,export_force_sampling=True,export_skins=True,export_yup=True)
    print('EXPORTED',name,len(PARTS),'parts')

for char in ['elias','ali','customer','cancellation']:make_character(char,char=='cancellation')
