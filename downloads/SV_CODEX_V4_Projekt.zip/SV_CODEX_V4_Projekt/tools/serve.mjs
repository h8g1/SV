import http from 'node:http';
import {fileURLToPath} from 'node:url';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
const root=resolve(fileURLToPath(new URL('../dist/',import.meta.url)));
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.csv':'text/csv; charset=utf-8','.glb':'model/gltf-binary','.png':'image/png','.ttf':'font/ttf'};
const port=Number(process.env.SV_PORT||4173);
http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost');const path=resolve(root,'.'+decodeURIComponent(url.pathname));if(path!==root&&!path.startsWith(root+sep)){res.writeHead(403).end();return}const info=await stat(path);const file=info.isDirectory()?resolve(path,'index.html'):path;res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});res.end(await readFile(file))}catch{res.writeHead(404,{'Content-Type':'text/plain'}).end('Nicht gefunden')}}).listen(port,'127.0.0.1',()=>console.log(`SV Raumreise auf http://localhost:${port} — Strg+C beendet den Server.`));
